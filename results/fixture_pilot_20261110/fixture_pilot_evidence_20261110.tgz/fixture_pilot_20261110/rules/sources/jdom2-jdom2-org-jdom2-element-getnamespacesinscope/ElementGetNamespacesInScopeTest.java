import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ElementGetNamespacesInScopeTest {

    private static final String XML_URI = "http://www.w3.org/XML/1998/namespace";

    @Before
    public void setUp() {
        // No shared mutable state; each test builds its own fixtures.
    }

    private static Namespace findNamespaceByPrefix(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return ns;
            }
        }
        return null;
    }

    private static boolean containsUri(List<Namespace> list, String uri) {
        for (Namespace ns : list) {
            if (uri.equals(ns.getURI())) {
                return true;
            }
        }
        return false;
    }

    @Test
    public void test_rootElement_defaultNamespace_noAdditional_noAttributes() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals(Namespace.XML_NAMESPACE, result.get(2));
    }

    @Test
    public void test_rootElement_nonDefaultNamespace_noDefaultCompletion() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("root", p);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
        assertTrue(result.contains(p));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_rootElement_withDefaultNamespace_noDuplicateNoNamespace() {
        Namespace defaultNs = Namespace.getNamespace("", "http://default");
        Element element = new Element("root", defaultNs);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(2, result.size());
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals(Namespace.XML_NAMESPACE, result.get(1));
        assertFalse(result.contains(Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_currentNamespace_priority_over_additionalNamespaces() {
        Namespace self = Namespace.getNamespace("p", "http://self");
        Element element = new Element("e", self);
        // Same prefix 'p' but different URI is not allowed on the same element,
        // so we use a distinct prefix for the additional declaration and verify
        // that the element's own namespace is preserved for its own prefix.
        Namespace other = Namespace.getNamespace("p2", "http://other");
        element.addNamespaceDeclaration(other);

        List<Namespace> result = element.getNamespacesInScope();

        Namespace pNs = findNamespaceByPrefix(result, "p");
        assertNotNull(pNs);
        assertEquals("http://self", pNs.getURI());
        assertEquals(element.getNamespace(), result.get(0));
        assertFalse(containsUri(result, "http://other"));
    }

    @Test
    public void test_additionalNamespaces_priority_over_attributes() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        Namespace qAdd = Namespace.getNamespace("q", "http://q-add");
        element.addNamespaceDeclaration(qAdd);
        // Attribute with a different prefix to avoid same-element prefix conflict.
        Namespace qAtt = Namespace.getNamespace("q2", "http://q-att");
        element.setAttribute(new Attribute("a", "v", qAtt));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace qNs = findNamespaceByPrefix(result, "q");
        assertNotNull(qNs);
        assertEquals("http://q-add", qNs.getURI());
        assertFalse(containsUri(result, "http://q-att"));
    }

    @Test
    public void test_attributes_namespace_added_when_not_conflicting() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        Namespace r = Namespace.getNamespace("r", "http://r");
        element.setAttribute(new Attribute("a", "v", r));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace rNs = findNamespaceByPrefix(result, "r");
        assertNotNull(rNs);
        assertEquals("http://r", rNs.getURI());
    }

    @Test
    public void test_inheritParentNamespaces() {
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Element parent = new Element("parent", a);
        Element child = new Element("child", b);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(findNamespaceByPrefix(result, "a"));
        assertNotNull(findNamespaceByPrefix(result, "b"));
        assertEquals(child.getNamespace(), result.get(0));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
    }

    @Test
    public void test_childNamespace_priority_over_parentNamespace() {
        Namespace parentNs = Namespace.getNamespace("x", "http://parent");
        Namespace childNs = Namespace.getNamespace("x", "http://child");
        Element parent = new Element("parent", parentNs);
        Element child = new Element("child", childNs);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace xNs = findNamespaceByPrefix(result, "x");
        assertNotNull(xNs);
        assertEquals("http://child", xNs.getURI());
        assertFalse(containsUri(result, "http://parent"));
    }

    @Test
    public void test_nonRootElement_noDefaultNamespaceCompletion() {
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Element parent = new Element("parent", a);
        Element child = new Element("child", b);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertFalse(result.contains(Namespace.NO_NAMESPACE));
        assertNull(findNamespaceByPrefix(result, ""));
    }

    private static void assertNull(Object o) {
        org.junit.Assert.assertNull(o);
    }

    @Test
    public void test_multiLevelInheritance() {
        Namespace g = Namespace.getNamespace("g", "http://g");
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace c = Namespace.getNamespace("c", "http://c");
        Element grandparent = new Element("gp", g);
        Element parent = new Element("p", p);
        Element child = new Element("c", c);
        grandparent.addContent(parent);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(findNamespaceByPrefix(result, "g"));
        assertNotNull(findNamespaceByPrefix(result, "p"));
        assertNotNull(findNamespaceByPrefix(result, "c"));
        assertEquals(child.getNamespace(), result.get(0));
    }

    @Test
    public void test_returnedList_isUnmodifiable() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        try {
            result.add(Namespace.getNamespace("z", "http://z"));
            fail("Expected UnsupportedOperationException on add");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.remove(0);
            fail("Expected UnsupportedOperationException on remove");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.clear();
            fail("Expected UnsupportedOperationException on clear");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_nullAdditionalNamespacesAndAttributes_noNPE() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_emptyAdditionalNamespacesAndAttributes() {
        Element element = new Element("root");
        // Trigger creation of the additionalNamespaces list, then remove the entry
        // so the list exists but is empty.
        Namespace tmp = Namespace.getNamespace("tmp", "http://tmp");
        element.addNamespaceDeclaration(tmp);
        element.removeNamespaceDeclaration(tmp);

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_xmlNamespacePrefixConflict_selfWins() {
        // The 'xml' prefix is reserved for the XML namespace, so we cannot create
        // a conflicting Namespace with prefix 'xml'. Instead we verify that the
        // XML namespace is present and that the element's own namespace is first.
        Element element = new Element("e", Namespace.XML_NAMESPACE);
        List<Namespace> result = element.getNamespacesInScope();

        Namespace xmlNs = findNamespaceByPrefix(result, "xml");
        assertNotNull(xmlNs);
        assertEquals(XML_URI, xmlNs.getURI());
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_parentRecursion_viaSpy() {
        // Without Mockito, we simulate the recursion path using a real parent
        // whose getNamespacesInScope returns a controlled set of namespaces.
        Namespace c = Namespace.getNamespace("c", "http://c");
        Element child = new Element("child", c);

        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace parentC = Namespace.getNamespace("c", "http://parent-c");
        Element parent = new Element("parent", a);
        parent.addNamespaceDeclaration(parentC);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(findNamespaceByPrefix(result, "a"));
        Namespace cNs = findNamespaceByPrefix(result, "c");
        assertNotNull(cNs);
        assertEquals("http://c", cNs.getURI());
    }

    @Test
    public void test_additionalNamespaces_viaSpy() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        // Same prefix 'p' with a different URI is not allowed on the same element,
        // so use a distinct prefix and verify the element's own namespace wins.
        Namespace dup = Namespace.getNamespace("p2", "http://dup");
        Namespace q = Namespace.getNamespace("q", "http://q");
        element.addNamespaceDeclaration(dup);
        element.addNamespaceDeclaration(q);

        List<Namespace> result = element.getNamespacesInScope();

        Namespace pNs = findNamespaceByPrefix(result, "p");
        assertNotNull(pNs);
        assertEquals("http://p", pNs.getURI());
        assertNotNull(findNamespaceByPrefix(result, "q"));
    }

    @Test
    public void test_attributes_viaSpy() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        Namespace r = Namespace.getNamespace("r", "http://r");
        element.setAttribute(new Attribute("a", "v", r));

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(findNamespaceByPrefix(result, "r"));
    }

    @Test
    public void test_resultOrder_currentNamespaceFirst_thenTreeMapOrder() {
        Namespace m = Namespace.getNamespace("m", "http://m");
        Element element = new Element("e", m);
        element.addNamespaceDeclaration(Namespace.getNamespace("a", "http://a"));
        element.addNamespaceDeclaration(Namespace.getNamespace("z", "http://z"));

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals("a", result.get(2).getPrefix());
        assertEquals("xml", result.get(3).getPrefix());
        assertEquals("z", result.get(4).getPrefix());
    }
}