import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ElementGetNamespacesInScopeTest {

    private Namespace nsP;
    private Namespace nsQ;
    private Namespace nsR;
    private Namespace nsA;
    private Namespace nsB;
    private Namespace nsX;
    private Namespace nsDefault;

    @Before
    public void setUp() {
        nsP = Namespace.getNamespace("p", "http://p");
        nsQ = Namespace.getNamespace("q", "http://q");
        nsR = Namespace.getNamespace("r", "http://r");
        nsA = Namespace.getNamespace("a", "http://a");
        nsB = Namespace.getNamespace("b", "http://b");
        nsX = Namespace.getNamespace("x", "http://x");
        nsDefault = Namespace.getNamespace("", "http://default");
    }

    private static Namespace findByPrefix(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return ns;
            }
        }
        return null;
    }

    private static boolean containsUri(List<Namespace> list, String uri) {
        for (Namespace ns : list) {
            if (uri.equals(ns.getURI())) {
                return true;
            }
        }
        return false;
    }

    @Test
    public void test_rootElement_defaultNamespace_noAdditional_noAttributes() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals(Namespace.XML_NAMESPACE, result.get(2));
    }

    @Test
    public void test_rootElement_nonDefaultNamespace_noDefaultCompletion() {
        Element element = new Element("root", nsP);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
        assertTrue(result.contains(nsP));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_rootElement_withDefaultNamespace_noDuplicateNoNamespace() {
        Element element = new Element("root", nsDefault);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(2, result.size());
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals(Namespace.XML_NAMESPACE, result.get(1));
        assertFalse(result.contains(Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_currentNamespace_priority_over_additionalNamespaces() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://self"));
        element.addNamespaceDeclaration(Namespace.getNamespace("p", "http://other"));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace p = findByPrefix(result, "p");
        assertNotNull(p);
        assertEquals("http://self", p.getURI());
        assertEquals(element.getNamespace(), result.get(0));
        assertFalse(containsUri(result, "http://other"));
    }

    @Test
    public void test_additionalNamespaces_priority_over_attributes() {
        Element element = new Element("e", nsP);
        element.addNamespaceDeclaration(Namespace.getNamespace("q", "http://q-add"));
        element.setAttribute(new Attribute("a", "v", Namespace.getNamespace("q", "http://q-att")));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace q = findByPrefix(result, "q");
        assertNotNull(q);
        assertEquals("http://q-add", q.getURI());
        assertFalse(containsUri(result, "http://q-att"));
    }

    @Test
    public void test_attributes_namespace_added_when_not_conflicting() {
        Element element = new Element("e", nsP);
        element.setAttribute(new Attribute("a", "v", nsR));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace r = findByPrefix(result, "r");
        assertNotNull(r);
        assertEquals("http://r", r.getURI());
    }

    @Test
    public void test_inheritParentNamespaces() {
        Element parent = new Element("parent", nsA);
        Element child = new Element("child", nsB);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertTrue(findByPrefix(result, "a") != null);
        assertTrue(findByPrefix(result, "b") != null);
        assertEquals(child.getNamespace(), result.get(0));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
    }

    @Test
    public void test_childNamespace_priority_over_parentNamespace() {
        Element parent = new Element("parent", Namespace.getNamespace("x", "http://parent"));
        Element child = new Element("child", Namespace.getNamespace("x", "http://child"));
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace x = findByPrefix(result, "x");
        assertNotNull(x);
        assertEquals("http://child", x.getURI());
        assertFalse(containsUri(result, "http://parent"));
    }

    @Test
    public void test_nonRootElement_noDefaultNamespaceCompletion() {
        Element parent = new Element("parent", nsA);
        Element child = new Element("child", nsB);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertFalse(result.contains(Namespace.NO_NAMESPACE));
        assertFalse(findByPrefix(result, "") != null);
    }

    @Test
    public void test_multiLevelInheritance() {
        Element grandparent = new Element("gp", Namespace.getNamespace("g", "http://g"));
        Element parent = new Element("p", Namespace.getNamespace("p", "http://p"));
        Element child = new Element("c", Namespace.getNamespace("c", "http://c"));
        grandparent.addContent(parent);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertTrue(findByPrefix(result, "g") != null);
        assertTrue(findByPrefix(result, "p") != null);
        assertTrue(findByPrefix(result, "c") != null);
        assertEquals(child.getNamespace(), result.get(0));
    }

    @Test
    public void test_returnedList_isUnmodifiable() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        try {
            result.add(Namespace.getNamespace("z", "http://z"));
            fail("Expected UnsupportedOperationException on add");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.remove(0);
            fail("Expected UnsupportedOperationException on remove");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.clear();
            fail("Expected UnsupportedOperationException on clear");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_nullAdditionalNamespacesAndAttributes_noNPE() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_emptyAdditionalNamespacesAndAttributes() {
        Element element = new Element("root");
        element.addNamespaceDeclaration(Namespace.getNamespace("tmp", "http://tmp"));
        element.removeNamespaceDeclaration(Namespace.getNamespace("tmp", "http://tmp"));

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_xmlNamespacePrefixConflict_selfWins() {
        Element element = new Element("e", Namespace.getNamespace("xml", "http://custom-xml"));
        List<Namespace> result = element.getNamespacesInScope();

        Namespace xml = findByPrefix(result, "xml");
        assertNotNull(xml);
        assertEquals("http://custom-xml", xml.getURI());
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_parentRecursion_viaRealParent() {
        Element parent = new Element("parent", nsA);
        parent.addNamespaceDeclaration(Namespace.getNamespace("c", "http://parent-c"));
        Element child = new Element("child", Namespace.getNamespace("c", "http://c"));
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertTrue(findByPrefix(result, "a") != null);
        Namespace c = findByPrefix(result, "c");
        assertNotNull(c);
        assertEquals("http://c", c.getURI());
    }

    @Test
    public void test_additionalNamespaces_viaRealElement() {
        Element element = new Element("e", nsP);
        element.addNamespaceDeclaration(Namespace.getNamespace("q", "http://q"));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace p = findByPrefix(result, "p");
        assertNotNull(p);
        assertEquals("http://p", p.getURI());
        assertTrue(findByPrefix(result, "q") != null);
    }

    @Test
    public void test_attributes_viaRealElement() {
        Element element = new Element("e", nsP);
        element.setAttribute(new Attribute("a", "v", nsR));

        List<Namespace> result = element.getNamespacesInScope();

        assertTrue(findByPrefix(result, "r") != null);
    }

    @Test
    public void test_resultOrder_currentNamespaceFirst_thenTreeMapOrder() {
        Element element = new Element("e", Namespace.getNamespace("m", "http://m"));
        element.addNamespaceDeclaration(Namespace.getNamespace("a", "http://a"));
        element.addNamespaceDeclaration(Namespace.getNamespace("z", "http://z"));

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals("a", result.get(2).getPrefix());
        assertEquals("xml", result.get(3).getPrefix());
        assertEquals("z", result.get(4).getPrefix());
    }
}