package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class ExampleTest {
    @Test
    public void test_value() {
        assertEquals(1, 1);
    }
}