package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ParserProcessArgsTest {

    private static class RecordingListIterator implements ListIterator<String> {
        private final List<String> elements;
        private int cursor;
        private int nextCalls;
        private int previousCalls;

        RecordingListIterator(final List<String> elements) {
            this.elements = new ArrayList<String>(elements);
            this.cursor = 0;
        }

        public boolean hasNext() {
            return cursor < elements.size();
        }

        public String next() {
            nextCalls++;
            return elements.get(cursor++);
        }

        public boolean hasPrevious() {
            return cursor > 0;
        }

        public String previous() {
            previousCalls++;
            return elements.get(--cursor);
        }

        public int nextIndex() {
            return cursor;
        }

        public int previousIndex() {
            return cursor - 1;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public void set(final String s) {
            throw new UnsupportedOperationException();
        }

        public void add(final String s) {
            throw new UnsupportedOperationException();
        }

        int getNextCalls() {
            return nextCalls;
        }

        int getPreviousCalls() {
            return previousCalls;
        }
    }

    private static class RecordingOption extends Option {
        private static final long serialVersionUID = 1L;

        private final List<String> processedValues = new ArrayList<String>();
        private final String[] valuesToReturn;
        private final boolean optionalArg;
        private final boolean throwOnAdd;
        private int addCalls;

        RecordingOption(final String opt, final boolean hasArg, final String description,
                        final String[] valuesToReturn, final boolean optionalArg,
                        final boolean throwOnAdd) {
            super(opt, hasArg, description);
            this.valuesToReturn = valuesToReturn;
            this.optionalArg = optionalArg;
            this.throwOnAdd = throwOnAdd;
        }

        @Override
        public void addValueForProcessing(final String value) {
            addCalls++;
            if (throwOnAdd) {
                throw new RuntimeException("boom");
            }
            processedValues.add(value);
        }

        @Override
        public String[] getValues() {
            return valuesToReturn;
        }

        @Override
        public boolean hasOptionalArg() {
            return optionalArg;
        }

        int getAddCalls() {
            return addCalls;
        }

        List<String> getProcessedValues() {
            return processedValues;
        }
    }

    private static class StubOptions extends Options {
        private static final long serialVersionUID = 1L;

        private final List<String> knownOptions = new ArrayList<String>();

        void register(final String token) {
            knownOptions.add(token);
        }

        @Override
        public boolean hasOption(final String opt) {
            return knownOptions.contains(opt);
        }
    }

    private static class TestParser extends Parser {
        private final Options options;

        TestParser(final Options options) {
            this.options = options;
        }

        @Override
        protected Options getOptions() {
            return options;
        }

        @Override
        public CommandLine parse(final Options opts, final String[] arguments) throws ParseException {
            throw new UnsupportedOperationException();
        }

        @Override
        public CommandLine parse(final Options opts, final String[] arguments, final boolean stopAtNonOption)
                throws ParseException {
            throw new UnsupportedOperationException();
        }

        @Override
        public CommandLine parse(final Options opts, final Properties properties, final String[] arguments,
                                 final boolean stopAtNonOption) throws ParseException {
            throw new UnsupportedOperationException();
        }
    }

    private TestParser parser;
    private StubOptions options;

    @Before
    public void setUp() {
        options = new StubOptions();
        parser = new TestParser(options);
    }

    @Test
    public void test_collectMultipleValuesUntilNextOption() throws Exception {
        RecordingOption opt = new RecordingOption("a", true, "desc", null, false, false);
        RecordingListIterator iter = new RecordingListIterator(java.util.Arrays.asList("v1", "v2", "-b"));
        options.register("-b");

        parser.processArgs(opt, iter);

        assertEquals(2, opt.getAddCalls());
        assertEquals(2, opt.getProcessedValues().size());
        assertEquals("v1", opt.getProcessedValues().get(0));
        assertEquals("v2", opt.getProcessedValues().get(1));
        assertEquals(1, iter.getPreviousCalls());
        assertEquals(3, iter.getNextCalls());
    }

    @Test
    public void test_stripQuotesFromValue() throws Exception {
        RecordingOption opt = new RecordingOption("a", true, "desc", null, false, false);
        RecordingListIterator iter = new RecordingListIterator(java.util.Arrays.asList("\"quoted value\""));

        parser.processArgs(opt, iter);

        assertEquals(1, opt.getAddCalls());
        assertEquals(1, opt.getProcessedValues().size());
        assertEquals("quoted value", opt.getProcessedValues().get(0));
    }

    @Test
    public void test_addValueThrowsRuntimeException_rollbackAndBreak() throws Exception {
        RecordingOption opt = new RecordingOption("a", true, "desc", new String[]{"existing"}, false, true);
        RecordingListIterator iter = new RecordingListIterator(java.util.Arrays.asList("bad"));

        parser.processArgs(opt, iter);

        assertEquals(1, iter.getPreviousCalls());
        assertEquals(1, iter.getNextCalls());
        assertEquals(1, opt.getAddCalls());
    }

    @Test
    public void test_addValueThrowsRuntimeException_noValues_throwsMissingArgument() throws Exception {
        RecordingOption opt = new RecordingOption("a", true, "desc", null, false, true);
        RecordingListIterator iter = new RecordingListIterator(java.util.Arrays.asList("bad"));

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (MissingArgumentException e) {
            assertSame(opt, e.getOption());
        }

        assertEquals(1, iter.getPreviousCalls());
    }

    @Test
    public void test_noValues_notOptional_throwsMissingArgument() throws Exception {
        RecordingOption opt = new RecordingOption("a", true, "desc", null, false, false);
        RecordingListIterator iter = new RecordingListIterator(new ArrayList<String>());

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (MissingArgumentException e) {
            assertSame(opt, e.getOption());
        }

        assertEquals(0, iter.getNextCalls());
    }

    @Test
    public void test_noValues_optionalArg_noException() throws Exception {
        RecordingOption opt = new RecordingOption("o", false, "desc", null, true, false);
        RecordingListIterator iter = new RecordingListIterator(new ArrayList<String>());

        parser.processArgs(opt, iter);

        assertEquals(0, opt.getAddCalls());
        assertEquals(0, iter.getNextCalls());
    }

    @Test
    public void test_hasOptionTrueButNoDashPrefix_treatedAsValue() throws Exception {
        RecordingOption opt = new RecordingOption("a", true, "desc", null, false, false);
        RecordingListIterator iter = new RecordingListIterator(java.util.Arrays.asList("plain"));
        options.register("plain");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.getAddCalls());
        assertEquals(1, opt.getProcessedValues().size());
        assertEquals("plain", opt.getProcessedValues().get(0));
        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_emptyIterator_noValues_throwsMissingArgument() throws Exception {
        RecordingOption opt = new RecordingOption("a", true, "desc", null, false, false);
        RecordingListIterator iter = new RecordingListIterator(new ArrayList<String>());

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (MissingArgumentException e) {
            assertNotNull(e.getOption());
            assertSame(opt, e.getOption());
        }

        assertEquals(0, iter.getNextCalls());
        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_valueWithDashPrefixButNotRegisteredOption_treatedAsValue() throws Exception {
        RecordingOption opt = new RecordingOption("a", true, "desc", null, false, false);
        RecordingListIterator iter = new RecordingListIterator(java.util.Arrays.asList("-unknown"));

        parser.processArgs(opt, iter);

        assertEquals(1, opt.getAddCalls());
        assertEquals(1, opt.getProcessedValues().size());
        assertEquals("-unknown", opt.getProcessedValues().get(0));
        assertEquals(0, iter.getPreviousCalls());
    }
}