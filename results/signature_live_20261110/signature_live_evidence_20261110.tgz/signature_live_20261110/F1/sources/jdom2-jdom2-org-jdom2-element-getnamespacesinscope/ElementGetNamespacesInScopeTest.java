import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.junit.Before;
import org.junit.Test;

public class ElementGetNamespacesInScopeTest {

    private Namespace nsA;
    private Namespace nsB;
    private Namespace nsDefault;
    private Namespace nsConflict;
    private Namespace nsXmlConflict;

    @Before
    public void setUp() {
        nsA = Namespace.getNamespace("a", "http://a");
        nsB = Namespace.getNamespace("b", "http://b");
        nsDefault = Namespace.getNamespace("http://default");
        nsConflict = Namespace.getNamespace("a", "http://a-conflict");
        nsXmlConflict = Namespace.getNamespace("xml", "http://xml-conflict");
    }

    private static Namespace findByPrefix(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return ns;
            }
        }
        return null;
    }

    private static int countByPrefix(List<Namespace> list, String prefix) {
        int count = 0;
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                count++;
            }
        }
        return count;
    }

    @Test
    public void test_rootElement_noDefaultNamespace_injectsNoNamespace() {
        Element element = new Element("root", nsA);
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(nsA, result.get(0));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
        assertEquals(3, result.size());
        assertEquals(Namespace.NO_NAMESPACE, findByPrefix(result, ""));
    }

    @Test
    public void test_rootElement_withDefaultNamespace_noNoNamespaceInjection() {
        Element element = new Element("root", nsDefault);
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(nsDefault, result.get(0));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertEquals(2, result.size());
        assertEquals(1, countByPrefix(result, ""));
        assertEquals(nsDefault, findByPrefix(result, ""));
    }

    @Test
    public void test_additionalNamespaces_collectedAndDeduplicated() {
        Element element = new Element("root", nsA);
        element.addNamespaceDeclaration(nsB);
        element.addNamespaceDeclaration(nsConflict);
        element.addNamespaceDeclaration(nsXmlConflict);

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(nsA, result.get(0));
        assertTrue(result.contains(nsB));
        assertEquals(nsA, findByPrefix(result, "a"));
        assertEquals(Namespace.XML_NAMESPACE, findByPrefix(result, "xml"));
        assertEquals(4, result.size());
    }

    @Test
    public void test_attributeNamespaces_collectedAndDeduplicated() {
        Element element = new Element("root", nsA);
        element.setAttribute(new Attribute("attrB", "v", nsB));
        element.setAttribute(new Attribute("attrConflict", "v", nsConflict));

        List<Namespace> result = element.getNamespacesInScope();

        assertTrue(result.contains(nsB));
        assertEquals(nsA, findByPrefix(result, "a"));
        assertEquals(4, result.size());
    }

    @Test
    public void test_parentNamespaces_inherited_childPrefixWins() {
        Element parent = new Element("parent");
        parent.addNamespaceDeclaration(nsB);
        parent.addNamespaceDeclaration(nsConflict);

        Element child = new Element("child", nsA);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertEquals(nsA, result.get(0));
        assertEquals(nsA, findByPrefix(result, "a"));
        assertTrue(result.contains(nsB));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertFalse(result.contains(Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_parentNamespaces_stubbedRecursion_mergeAndDedup() {
        final Element parent = new Element("parent") {
            private static final long serialVersionUID = 1L;
            private int callCount = 0;

            @Override
            public List<Namespace> getNamespacesInScope() {
                callCount++;
                return Arrays.asList(nsConflict, nsB, Namespace.XML_NAMESPACE);
            }

            public int getCallCount() {
                return callCount;
            }
        };

        Element child = new Element("child", nsA) {
            private static final long serialVersionUID = 1L;

            @Override
            public Element getParentElement() {
                return parent;
            }
        };

        List<Namespace> result = child.getNamespacesInScope();

        assertEquals(nsA, result.get(0));
        assertEquals(nsA, findByPrefix(result, "a"));
        assertTrue(result.contains(nsB));
        assertEquals(4, result.size());
        assertEquals(1, parent.getCallCount());
    }

    @Test
    public void test_nullAdditionalNamespacesAndAttributes_branch() {
        Element element = new Element("root", nsA) {
            private static final long serialVersionUID = 1L;

            @Override
            public List<Namespace> getAdditionalNamespaces() {
                return null;
            }

            @Override
            public List<Attribute> getAttributes() {
                return null;
            }

            @Override
            public Element getParentElement() {
                return null;
            }
        };

        List<Namespace> result;
        try {
            result = element.getNamespacesInScope();
        } catch (RuntimeException e) {
            fail("getNamespacesInScope should not throw, but threw: " + e);
            return;
        }

        assertEquals(nsA, result.get(0));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
        assertEquals(3, result.size());
    }

    @Test
    public void test_emptyAdditionalNamespacesAndAttributes_branch() {
        Element element = new Element("root", nsA) {
            private static final long serialVersionUID = 1L;

            @Override
            public List<Namespace> getAdditionalNamespaces() {
                return Collections.emptyList();
            }

            @Override
            public List<Attribute> getAttributes() {
                return new ArrayList<Attribute>();
            }

            @Override
            public Element getParentElement() {
                return null;
            }
        };

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertEquals(nsA, result.get(0));
    }

    @Test
    public void test_returnedList_isUnmodifiable() {
        Element element = new Element("root", nsA);
        List<Namespace> result = element.getNamespacesInScope();

        try {
            result.add(nsB);
            fail("Expected UnsupportedOperationException on add");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.remove(0);
            fail("Expected UnsupportedOperationException on remove");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.clear();
            fail("Expected UnsupportedOperationException on clear");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_resultOrder_selfFirstThenSortedByPrefix() {
        Namespace nsZ = Namespace.getNamespace("z", "http://z");
        Namespace nsM = Namespace.getNamespace("m", "http://m");

        Element element = new Element("root", nsZ);
        element.addNamespaceDeclaration(nsA);
        element.addNamespaceDeclaration(nsM);

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(nsZ, result.get(0));
        assertEquals("a", result.get(1).getPrefix());
        assertEquals("m", result.get(2).getPrefix());
        assertEquals("xml", result.get(3).getPrefix());
        assertEquals("", result.get(4).getPrefix());
    }

    @Test
    public void test_selfNamespacePrefixEqualsEmpty_removeLogic() {
        Element element = new Element("root", nsDefault);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(nsDefault, result.get(0));
        assertEquals(1, countByPrefix(result, ""));
        assertEquals(2, result.size());
    }

    @Test
    public void test_deepParentChain_inheritsAllAncestorNamespaces() {
        Namespace nsC = Namespace.getNamespace("c", "http://c");

        Element grandParent = new Element("gp");
        grandParent.addNamespaceDeclaration(nsB);

        Element parent = new Element("p");
        parent.addNamespaceDeclaration(nsC);

        Element child = new Element("c", nsA);

        grandParent.addContent(parent);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertEquals(nsA, result.get(0));
        assertTrue(result.contains(nsB));
        assertNotNull(findByPrefix(result, "c"));
        assertEquals(nsC, findByPrefix(result, "c"));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertFalse(result.contains(Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_attributeWithNoNamespace_ignored() {
        Element element = new Element("root", nsA);
        element.setAttribute(new Attribute("attr", "v"));

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertEquals(Namespace.NO_NAMESPACE, findByPrefix(result, ""));
    }

    @Test
    public void test_xmlPrefixConflictFromAdditionalNamespace_ignored() {
        Element element = new Element("root", nsA);
        element.addNamespaceDeclaration(nsXmlConflict);

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(Namespace.XML_NAMESPACE, findByPrefix(result, "xml"));
        assertFalse(result.contains(nsXmlConflict));
    }
}