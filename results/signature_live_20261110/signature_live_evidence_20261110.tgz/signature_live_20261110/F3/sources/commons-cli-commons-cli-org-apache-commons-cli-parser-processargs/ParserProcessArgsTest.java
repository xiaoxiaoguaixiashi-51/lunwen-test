package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ParserProcessArgsTest {

    private RecordingOption option;
    private RecordingOptions options;
    private TestParser parser;

    @Before
    public void setUp() {
        option = new RecordingOption();
        options = new RecordingOptions();
        parser = new TestParser(options);
    }

    private static ListIterator<String> iteratorOf(String... tokens) {
        List<String> list = new ArrayList<String>();
        for (String token : tokens) {
            list.add(token);
        }
        return list.listIterator();
    }

    @Test
    public void test_processArgs_collectsMultipleValuesUntilNextOption() throws Exception {
        option.values = new String[] { "value1", "value2" };
        options.registerOption("-o");
        ListIterator<String> iter = iteratorOf("value1", "value2", "-o");

        parser.processArgs(option, iter);

        assertEquals(2, option.addedValues.size());
        assertEquals("value1", option.addedValues.get(0));
        assertEquals("value2", option.addedValues.get(1));
        assertEquals(1, option.addValueCalls);
        assertEquals(2, option.addedValues.size());
        assertFalse(option.addedValues.contains("-o"));
        assertEquals(1, options.hasOptionCallsFor("-o"));
        assertEquals(1, options.hasOptionCallsFor("value1"));
        assertEquals(1, options.hasOptionCallsFor("value2"));
    }

    @Test
    public void test_processArgs_emptyIterator_noValues_notOptional_throwsMissingArgumentException() throws Exception {
        option.values = null;
        option.optionalArg = false;
        ListIterator<String> iter = iteratorOf();

        try {
            parser.processArgs(option, iter);
            fail("Expected MissingArgumentException");
        } catch (MissingArgumentException e) {
            assertSame(option, e.getOption());
        }

        assertEquals(0, option.addValueCalls);
        assertEquals(0, option.addedValues.size());
    }

    @Test
    public void test_processArgs_addValueThrowsRuntimeException_rollbackAndBreak() throws Exception {
        option.values = new String[] { "existing" };
        option.throwOnAddValue = true;
        ListIterator<String> iter = iteratorOf("badValue");

        parser.processArgs(option, iter);

        assertEquals(1, option.addValueCalls);
        assertEquals(0, option.addedValues.size());
        assertNotNull(option.values);
        assertEquals(1, options.hasOptionCallsFor("badValue"));
    }

    @Test
    public void test_processArgs_addValueThrowsRuntimeException_thenMissingArgument() throws Exception {
        option.values = null;
        option.optionalArg = false;
        option.throwOnAddValue = true;
        ListIterator<String> iter = iteratorOf("badValue");

        try {
            parser.processArgs(option, iter);
            fail("Expected MissingArgumentException");
        } catch (MissingArgumentException e) {
            assertSame(option, e.getOption());
        }

        assertEquals(1, option.addValueCalls);
        assertEquals(0, option.addedValues.size());
    }

    @Test
    public void test_processArgs_optionalArg_noValues_returnsNormally() throws Exception {
        option.values = null;
        option.optionalArg = true;
        ListIterator<String> iter = iteratorOf();

        parser.processArgs(option, iter);

        assertEquals(0, option.addValueCalls);
        assertEquals(0, option.addedValues.size());
    }

    @Test
    public void test_processArgs_quotedValue_strippedBeforeProcessing() throws Exception {
        option.values = new String[] { "quoted" };
        ListIterator<String> iter = iteratorOf("\"quoted\"");

        parser.processArgs(option, iter);

        assertEquals(1, option.addValueCalls);
        assertEquals(1, option.addedValues.size());
        assertEquals("quoted", option.addedValues.get(0));
        assertFalse(option.addedValues.contains("\"quoted\""));
        assertEquals(1, options.hasOptionCallsFor("\"quoted\""));
    }

    @Test
    public void test_processArgs_tokenStartsWithDashButNotOption_treatedAsValue() throws Exception {
        option.values = new String[] { "-unknown" };
        ListIterator<String> iter = iteratorOf("-unknown");

        parser.processArgs(option, iter);

        assertEquals(1, option.addValueCalls);
        assertEquals(1, option.addedValues.size());
        assertEquals("-unknown", option.addedValues.get(0));
        assertEquals(1, options.hasOptionCallsFor("-unknown"));
    }

    @Test
    public void test_processArgs_tokenIsOptionButNoDashPrefix_treatedAsValue() throws Exception {
        option.values = new String[] { "value" };
        options.registerOption("value");
        ListIterator<String> iter = iteratorOf("value");

        parser.processArgs(option, iter);

        assertEquals(1, option.addValueCalls);
        assertEquals(1, option.addedValues.size());
        assertEquals("value", option.addedValues.get(0));
        assertEquals(1, options.hasOptionCallsFor("value"));
    }

    @Test
    public void test_processArgs_multipleValuesThenExhausted_noException() throws Exception {
        option.values = new String[] { "a", "b", "c" };
        ListIterator<String> iter = iteratorOf("a", "b", "c");

        parser.processArgs(option, iter);

        assertEquals(3, option.addValueCalls);
        assertEquals(3, option.addedValues.size());
        assertEquals("a", option.addedValues.get(0));
        assertEquals("b", option.addedValues.get(1));
        assertEquals("c", option.addedValues.get(2));
        assertEquals(1, options.hasOptionCallsFor("a"));
        assertEquals(1, options.hasOptionCallsFor("b"));
        assertEquals(1, options.hasOptionCallsFor("c"));
    }

    private static final class TestParser extends Parser {
        private final Options options;

        TestParser(Options options) {
            this.options = options;
        }

        @Override
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
            return arguments;
        }

        @Override
        protected Options getOptions() {
            return options;
        }
    }

    private static final class RecordingOptions extends Options {
        private final List<String> registered = new ArrayList<String>();
        private final List<String> hasOptionCalls = new ArrayList<String>();

        void registerOption(String name) {
            registered.add(name);
        }

        int hasOptionCallsFor(String name) {
            int count = 0;
            for (String call : hasOptionCalls) {
                if (call.equals(name)) {
                    count++;
                }
            }
            return count;
        }

        @Override
        public boolean hasOption(String opt) {
            hasOptionCalls.add(opt);
            return registered.contains(opt);
        }
    }

    private static final class RecordingOption extends Option {
        private String[] values;
        private boolean optionalArg;
        private boolean throwOnAddValue;
        private int addValueCalls;
        private final List<String> addedValues = new ArrayList<String>();

        RecordingOption() {
            super("t", "test option");
        }

        @Override
        public String[] getValues() {
            return values;
        }

        @Override
        public boolean hasOptionalArg() {
            return optionalArg;
        }

        @Override
        void addValueForProcessing(String value) {
            addValueCalls++;
            if (throwOnAddValue) {
                throw new RuntimeException("too many values");
            }
            addedValues.add(value);
        }
    }
}