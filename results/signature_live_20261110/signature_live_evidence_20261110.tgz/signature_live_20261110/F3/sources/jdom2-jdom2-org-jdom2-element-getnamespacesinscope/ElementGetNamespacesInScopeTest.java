import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.junit.Test;

public class ElementGetNamespacesInScopeTest {

    private static Namespace findNamespaceByPrefix(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return ns;
            }
        }
        return null;
    }

    private static boolean containsNamespace(List<Namespace> list, Namespace ns) {
        for (Namespace candidate : list) {
            if (candidate.equals(ns)) {
                return true;
            }
        }
        return false;
    }

    private static boolean containsUri(List<Namespace> list, String uri) {
        for (Namespace ns : list) {
            if (uri.equals(ns.getURI())) {
                return true;
            }
        }
        return false;
    }

    @Test
    public void test_rootElement_defaultNamespace_noAdditional_noAttributes() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals(Namespace.XML_NAMESPACE, result.get(2));
    }

    @Test
    public void test_rootElement_nonDefaultNamespace_noDefaultCompletion() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("root", p);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertTrue(containsNamespace(result, p));
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_rootElement_withDefaultNamespace_noDuplicateNoNamespace() {
        Namespace def = Namespace.getNamespace("", "http://default");
        Element element = new Element("root", def);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(2, result.size());
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals(Namespace.XML_NAMESPACE, result.get(1));
        assertFalse(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_currentNamespace_priority_over_additionalNamespaces() {
        Namespace self = Namespace.getNamespace("p", "http://self");
        Element element = new Element("e", self);
        element.addNamespaceDeclaration(Namespace.getNamespace("p", "http://other"));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace p = findNamespaceByPrefix(result, "p");
        assertNotNull(p);
        assertEquals("http://self", p.getURI());
        assertEquals(element.getNamespace(), result.get(0));
        assertFalse(containsUri(result, "http://other"));
    }

    @Test
    public void test_additionalNamespaces_priority_over_attributes() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://p"));
        element.addNamespaceDeclaration(Namespace.getNamespace("q", "http://q-add"));
        element.setAttribute(new Attribute("a", "v", Namespace.getNamespace("q", "http://q-att")));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace q = findNamespaceByPrefix(result, "q");
        assertNotNull(q);
        assertEquals("http://q-add", q.getURI());
        assertFalse(containsUri(result, "http://q-att"));
    }

    @Test
    public void test_attributes_namespace_added_when_not_conflicting() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://p"));
        element.setAttribute(new Attribute("a", "v", Namespace.getNamespace("r", "http://r")));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace r = findNamespaceByPrefix(result, "r");
        assertNotNull(r);
        assertEquals("http://r", r.getURI());
    }

    @Test
    public void test_inheritParentNamespaces() {
        Element parent = new Element("parent", Namespace.getNamespace("a", "http://a"));
        Element child = new Element("child", Namespace.getNamespace("b", "http://b"));
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(findNamespaceByPrefix(result, "a"));
        assertNotNull(findNamespaceByPrefix(result, "b"));
        assertEquals(child.getNamespace(), result.get(0));
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
    }

    @Test
    public void test_childNamespace_priority_over_parentNamespace() {
        Element parent = new Element("parent", Namespace.getNamespace("x", "http://parent"));
        Element child = new Element("child", Namespace.getNamespace("x", "http://child"));
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace x = findNamespaceByPrefix(result, "x");
        assertNotNull(x);
        assertEquals("http://child", x.getURI());
        assertFalse(containsUri(result, "http://parent"));
    }

    @Test
    public void test_nonRootElement_noDefaultNamespaceCompletion() {
        Element parent = new Element("parent", Namespace.getNamespace("a", "http://a"));
        Element child = new Element("child", Namespace.getNamespace("b", "http://b"));
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertFalse(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertNull(findNamespaceByPrefix(result, ""));
    }

    private static void assertNull(Object o) {
        org.junit.Assert.assertNull(o);
    }

    @Test
    public void test_multiLevelInheritance() {
        Element grandparent = new Element("gp", Namespace.getNamespace("g", "http://g"));
        Element parent = new Element("p", Namespace.getNamespace("p", "http://p"));
        Element child = new Element("c", Namespace.getNamespace("c", "http://c"));
        grandparent.addContent(parent);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(findNamespaceByPrefix(result, "g"));
        assertNotNull(findNamespaceByPrefix(result, "p"));
        assertNotNull(findNamespaceByPrefix(result, "c"));
        assertEquals(child.getNamespace(), result.get(0));
    }

    @Test
    public void test_returnedList_isUnmodifiable() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        try {
            result.add(Namespace.getNamespace("z", "http://z"));
            fail("Expected UnsupportedOperationException on add");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.remove(0);
            fail("Expected UnsupportedOperationException on remove");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.clear();
            fail("Expected UnsupportedOperationException on clear");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_nullAdditionalNamespacesAndAttributes_noNPE() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_emptyAdditionalNamespacesAndAttributes() {
        Element element = new Element("root");
        element.addNamespaceDeclaration(Namespace.getNamespace("tmp", "http://tmp"));
        element.removeNamespaceDeclaration(Namespace.getNamespace("tmp", "http://tmp"));

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_xmlNamespacePrefixConflict_selfWins() {
        Namespace customXml = Namespace.getNamespace("xml", "http://custom-xml");
        Element element = new Element("e", customXml);

        List<Namespace> result = element.getNamespacesInScope();

        Namespace xml = findNamespaceByPrefix(result, "xml");
        assertNotNull(xml);
        assertEquals("http://custom-xml", xml.getURI());
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_parentRecursion_viaSpy() {
        Element parent = new Element("parent", Namespace.getNamespace("a", "http://a"));
        Element child = new Element("child", Namespace.getNamespace("c", "http://c"));
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(findNamespaceByPrefix(result, "a"));
        Namespace c = findNamespaceByPrefix(result, "c");
        assertNotNull(c);
        assertEquals("http://c", c.getURI());
    }

    @Test
    public void test_additionalNamespaces_viaSpy() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://p"));
        element.addNamespaceDeclaration(Namespace.getNamespace("p", "http://dup"));
        element.addNamespaceDeclaration(Namespace.getNamespace("q", "http://q"));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace p = findNamespaceByPrefix(result, "p");
        assertNotNull(p);
        assertEquals("http://p", p.getURI());
        assertNotNull(findNamespaceByPrefix(result, "q"));
    }

    @Test
    public void test_attributes_viaSpy() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://p"));
        element.setAttribute(new Attribute("a", "v", Namespace.getNamespace("r", "http://r")));

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(findNamespaceByPrefix(result, "r"));
    }

    @Test
    public void test_resultOrder_currentNamespaceFirst_thenTreeMapOrder() {
        Element element = new Element("e", Namespace.getNamespace("m", "http://m"));
        element.addNamespaceDeclaration(Namespace.getNamespace("a", "http://a"));
        element.addNamespaceDeclaration(Namespace.getNamespace("z", "http://z"));

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals("a", result.get(2).getPrefix());
        assertEquals("xml", result.get(3).getPrefix());
        assertEquals("z", result.get(4).getPrefix());
    }
}