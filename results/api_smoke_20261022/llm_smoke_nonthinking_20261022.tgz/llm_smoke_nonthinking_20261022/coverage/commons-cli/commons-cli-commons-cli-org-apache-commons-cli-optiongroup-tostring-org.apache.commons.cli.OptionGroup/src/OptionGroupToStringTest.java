package org.apache.commons.cli;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

/**
 * JUnit 4 tests for {@link OptionGroup#toString()}.
 *
 * <p>Uses real {@link Option} instances and lightweight fake subclasses instead of Mockito,
 * so the tests are self-contained and compile with plain JUnit 4.</p>
 */
public class OptionGroupToStringTest {

    private OptionGroup group;

    @Before
    public void setUp() {
        group = new OptionGroup();
    }

    /**
     * A lightweight fake {@link Option} that allows precise control over the getters used by
     * {@link OptionGroup#toString()} without relying on Mockito.
     */
    private static final class FakeOption extends Option {
        private static final long serialVersionUID = 1L;

        private final String opt;
        private final String longOpt;
        private final String description;

        FakeOption(final String opt, final String longOpt, final String description) {
            super(opt == null ? "placeholder" : opt, false, description);
            this.opt = opt;
            this.longOpt = longOpt;
            this.description = description;
        }

        @Override
        public String getOpt() {
            return opt;
        }

        @Override
        public String getLongOpt() {
            return longOpt;
        }

        @Override
        public String getDescription() {
            return description;
        }

        @Override
        public String getKey() {
            if (opt != null) {
                return opt;
            }
            return longOpt;
        }
    }

    /**
     * A lightweight fake {@link OptionGroup} that overrides {@link #getOptions()} to return a
     * fixed collection and counts how many times it was invoked.
     */
    private static final class FakeOptionsGroup extends OptionGroup {
        private static final long serialVersionUID = 1L;

        private final Collection<Option> options;
        private int getOptionsCallCount;

        FakeOptionsGroup(final Collection<Option> options) {
            this.options = options;
        }

        @Override
        public Collection<Option> getOptions() {
            getOptionsCallCount++;
            return options;
        }

        int getGetOptionsCallCount() {
            return getOptionsCallCount;
        }
    }

    @Test
    public void test_toString_emptyGroup_returnsEmptyBrackets() {
        assertEquals("[]", group.toString());
    }

    @Test
    public void test_toString_singleShortOption_noDescription() {
        group.addOption(new Option("a", false, null));
        assertEquals("[-a]", group.toString());
    }

    @Test
    public void test_toString_singleLongOption_withDescription() {
        group.addOption(new Option(null, "verbose", false, "verbose mode"));
        assertEquals("[--verbose verbose mode]", group.toString());
    }

    @Test
    public void test_toString_shortOptionWithDescription() {
        group.addOption(new Option("a", false, "desc"));
        assertEquals("[-a desc]", group.toString());
    }

    @Test
    public void test_toString_multipleOptions_mixedOrderAndSeparator() {
        group.addOption(new Option("a", false, "desc a"));
        group.addOption(new Option(null, "verbose", false, null));
        group.addOption(new Option("c", false, null));
        assertEquals("[-a desc a, --verbose, -c]", group.toString());
    }

    @Test
    public void test_toString_shortAndLongOptPresent_prefersShortOpt() {
        group.addOption(new Option("x", "extra", false, null));
        final String result = group.toString();
        assertEquals("[-x]", result);
        assertFalse("Output should not contain the long option form", result.contains("--extra"));
    }

    @Test
    public void test_toString_mockedOption_bothOptAndLongOptNull() {
        group.addOption(new FakeOption(null, null, null));
        assertEquals("[--null]", group.toString());
    }

    @Test
    public void test_toString_mockedOption_emptyDescription() {
        group.addOption(new FakeOption("a", null, ""));
        assertEquals("[-a ]", group.toString());
    }

    @Test
    public void test_toString_mockedOption_emptyOptString() {
        group.addOption(new FakeOption("", "long", null));
        assertEquals("[-]", group.toString());
    }

    @Test
    public void test_toString_spyEmptyOptionsCollection() {
        final FakeOptionsGroup fakeGroup = new FakeOptionsGroup(Collections.<Option>emptyList());
        assertEquals("[]", fakeGroup.toString());
        assertEquals("getOptions() should be invoked exactly once", 1, fakeGroup.getGetOptionsCallCount());
    }

    @Test
    public void test_toString_duplicateKeyOption_overwrittenByAddOption() {
        group.addOption(new Option("a", false, "first"));
        group.addOption(new Option("a", false, "second"));
        assertEquals("[-a second]", group.toString());
    }

    @Test
    public void test_toString_iteratorOrderPreserved() {
        final List<Option> options = new ArrayList<Option>();
        options.add(new Option("a", false, null));
        options.add(new Option("b", false, null));
        options.add(new Option("c", false, null));
        final FakeOptionsGroup fakeGroup = new FakeOptionsGroup(options);
        final String result = fakeGroup.toString();
        assertEquals("[-a, -b, -c]", result);
        final Iterator<Option> iter = fakeGroup.getOptions().iterator();
        assertTrue(iter.hasNext());
        assertNotNull(iter.next());
    }
}