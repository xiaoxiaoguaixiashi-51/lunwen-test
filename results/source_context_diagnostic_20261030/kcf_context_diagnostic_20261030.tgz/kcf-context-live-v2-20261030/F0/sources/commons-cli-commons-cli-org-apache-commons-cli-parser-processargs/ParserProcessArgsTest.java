package org.apache.commons.cli;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@link Parser#processArgs(Option, ListIterator)}.
 *
 * <p>Uses real objects and lightweight fakes instead of Mockito.</p>
 */
@SuppressWarnings("deprecation")
public class ParserProcessArgsTest {

    /**
     * Concrete Parser subclass used to instantiate the abstract Parser.
     */
    private static class TestParser extends Parser {
        @Override
        protected String[] flatten(final Options opts, final String[] arguments, final boolean stopAtNonOption) {
            return new String[0];
        }
    }

    /**
     * Lightweight fake ListIterator that records interactions and can be scripted.
     */
    private static class FakeListIterator implements ListIterator<String> {
        private final List<String> values;
        private int cursor;
        private int nextCalls;
        private int previousCalls;
        private int hasNextCalls;

        FakeListIterator(final List<String> values) {
            this.values = new ArrayList<String>(values);
            this.cursor = 0;
        }

        @Override
        public boolean hasNext() {
            hasNextCalls++;
            return cursor < values.size();
        }

        @Override
        public String next() {
            nextCalls++;
            final String v = values.get(cursor);
            cursor++;
            return v;
        }

        @Override
        public boolean hasPrevious() {
            return cursor > 0;
        }

        @Override
        public String previous() {
            previousCalls++;
            cursor--;
            return values.get(cursor);
        }

        @Override
        public int nextIndex() {
            return cursor;
        }

        @Override
        public int previousIndex() {
            return cursor - 1;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void set(final String s) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void add(final String s) {
            throw new UnsupportedOperationException();
        }

        int getNextCalls() {
            return nextCalls;
        }

        int getPreviousCalls() {
            return previousCalls;
        }

        int getHasNextCalls() {
            return hasNextCalls;
        }
    }

    /**
     * Lightweight fake Option that records addValueForProcessing calls and can be scripted
     * to throw on specific values.
     */
    private static class FakeOption extends Option {
        private static final long serialVersionUID = 1L;

        private final List<String> addedValues = new ArrayList<String>();
        private String[] values;
        private boolean optionalArg;
        private String throwOnValue;

        FakeOption(final String opt) {
            super(opt, false, "fake option");
        }

        @Override
        public void addValueForProcessing(final String value) {
            if (throwOnValue != null && throwOnValue.equals(value)) {
                throw new RuntimeException("boom");
            }
            addedValues.add(value);
        }

        @Override
        public String[] getValues() {
            return values;
        }

        @Override
        public boolean hasOptionalArg() {
            return optionalArg;
        }

        List<String> getAddedValues() {
            return addedValues;
        }

        void setValues(final String[] values) {
            this.values = values;
        }

        void setOptionalArg(final boolean optionalArg) {
            this.optionalArg = optionalArg;
        }

        void setThrowOnValue(final String throwOnValue) {
            this.throwOnValue = throwOnValue;
        }
    }

    /**
     * Lightweight fake Options that returns scripted hasOption results.
     */
    private static class FakeOptions extends Options {
        private static final long serialVersionUID = 1L;

        private final List<String> knownOptions = new ArrayList<String>();

        void registerOption(final String opt) {
            knownOptions.add(opt);
        }

        @Override
        public boolean hasOption(final String opt) {
            return knownOptions.contains(opt);
        }
    }

    private TestParser parser;

    @Before
    public void setUp() {
        parser = new TestParser();
    }

    private void injectOptions(final Options options) {
        parser.setOptions(options);
    }

    @Test
    public void test_processArgs_multipleValues_thenOption_stopsLoop() throws Exception {
        final FakeOptions options = new FakeOptions();
        options.registerOption("-x");
        injectOptions(options);

        final FakeOption opt = new FakeOption("-f");
        opt.setValues(new String[] { "value1", "value2" });
        opt.setOptionalArg(false);

        final FakeListIterator iter = new FakeListIterator(Arrays.asList("value1", "value2", "-x"));

        parser.processArgs(opt, iter);

        assertEquals(Arrays.asList("value1", "value2"), opt.getAddedValues());
        assertEquals(2, opt.getAddedValues().size());
        assertEquals(1, iter.getPreviousCalls());
        assertEquals(3, iter.getNextCalls());
    }

    @Test
    public void test_processArgs_addValueThrowsRuntimeException_rollbackAndBreak() throws Exception {
        final FakeOptions options = new FakeOptions();
        injectOptions(options);

        final FakeOption opt = new FakeOption("-f");
        opt.setValues(new String[] { "value1" });
        opt.setOptionalArg(false);
        opt.setThrowOnValue("value2");

        final FakeListIterator iter = new FakeListIterator(Arrays.asList("value1", "value2"));

        parser.processArgs(opt, iter);

        assertEquals(Arrays.asList("value1"), opt.getAddedValues());
        assertEquals(1, iter.getPreviousCalls());
        assertEquals(2, iter.getNextCalls());
    }

    @Test
    public void test_processArgs_noValuesAndNotOptional_throwsMissingArgumentException() throws Exception {
        final FakeOptions options = new FakeOptions();
        options.registerOption("-x");
        injectOptions(options);

        final FakeOption opt = new FakeOption("-f");
        opt.setValues(null);
        opt.setOptionalArg(false);

        final FakeListIterator iter = new FakeListIterator(Arrays.asList("-x"));

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (final MissingArgumentException e) {
            assertNotNull(e.getOption());
            assertEquals("-f", e.getOption().getOpt());
        }

        assertEquals(1, iter.getPreviousCalls());
        assertTrue(opt.getAddedValues().isEmpty());
    }

    @Test
    public void test_processArgs_emptyIterator_optionalArg_noException() throws Exception {
        final FakeOptions options = new FakeOptions();
        injectOptions(options);

        final FakeOption opt = new FakeOption("-f");
        opt.setValues(null);
        opt.setOptionalArg(true);

        final FakeListIterator iter = new FakeListIterator(new ArrayList<String>());

        parser.processArgs(opt, iter);

        assertEquals(0, iter.getNextCalls());
        assertTrue(opt.getAddedValues().isEmpty());
    }

    @Test
    public void test_processArgs_emptyIterator_notOptional_throwsMissingArgumentException() throws Exception {
        final FakeOptions options = new FakeOptions();
        injectOptions(options);

        final FakeOption opt = new FakeOption("-f");
        opt.setValues(null);
        opt.setOptionalArg(false);

        final FakeListIterator iter = new FakeListIterator(new ArrayList<String>());

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (final MissingArgumentException e) {
            assertNotNull(e.getOption());
            assertEquals("-f", e.getOption().getOpt());
        }

        assertEquals(0, iter.getNextCalls());
    }

    @Test
    public void test_processArgs_quotedValue_strippedBeforeAdd() throws Exception {
        final FakeOptions options = new FakeOptions();
        injectOptions(options);

        final FakeOption opt = new FakeOption("-f");
        opt.setValues(new String[] { "quoted value" });
        opt.setOptionalArg(false);

        final FakeListIterator iter = new FakeListIterator(Arrays.asList("\"quoted value\""));

        parser.processArgs(opt, iter);

        assertEquals(1, opt.getAddedValues().size());
        assertEquals("quoted value", opt.getAddedValues().get(0));
        assertFalse(opt.getAddedValues().get(0).startsWith("\""));
    }

    @Test
    public void test_processArgs_nonOptionStringWithoutDash_treatedAsValue() throws Exception {
        final FakeOptions options = new FakeOptions();
        options.registerOption("value");
        injectOptions(options);

        final FakeOption opt = new FakeOption("-f");
        opt.setValues(new String[] { "value" });
        opt.setOptionalArg(false);

        final FakeListIterator iter = new FakeListIterator(Arrays.asList("value"));

        parser.processArgs(opt, iter);

        assertEquals(Arrays.asList("value"), opt.getAddedValues());
        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_processArgs_realListIterator_previousSemantics() throws Exception {
        final FakeOptions options = new FakeOptions();
        options.registerOption("-x");
        injectOptions(options);

        final FakeOption opt = new FakeOption("-f");
        opt.setValues(new String[] { "v1" });
        opt.setOptionalArg(false);

        final List<String> tokens = new ArrayList<String>(Arrays.asList("v1", "-x"));
        final ListIterator<String> iter = tokens.listIterator();

        parser.processArgs(opt, iter);

        assertEquals(Arrays.asList("v1"), opt.getAddedValues());
        assertTrue(iter.hasNext());
        assertEquals("-x", iter.next());
    }
}