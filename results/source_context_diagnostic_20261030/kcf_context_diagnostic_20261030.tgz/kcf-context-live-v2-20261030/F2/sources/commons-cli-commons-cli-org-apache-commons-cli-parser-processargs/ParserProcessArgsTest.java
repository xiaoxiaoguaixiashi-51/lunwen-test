package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ParserProcessArgsTest {

    private TestableParser parser;

    @Before
    public void setUp() {
        parser = new TestableParser();
    }

    private static ListIterator<String> iteratorOf(final String... values) {
        final List<String> list = new ArrayList<String>();
        for (final String v : values) {
            list.add(v);
        }
        return list.listIterator();
    }

    private static Options optionsWith(final String... opts) {
        final Options options = new Options();
        for (final String o : opts) {
            options.addOption(new Option(o, false, "desc-" + o));
        }
        return options;
    }

    @Test
    public void test_processArgs_collectsMultipleValuesUntilNextOption() throws Exception {
        final Options options = optionsWith("b");
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", true, "desc");
        opt.setValues(new ArrayList<String>());

        final ListIterator<String> iter = iteratorOf("value1", "value2", "-b");

        parser.processArgs(opt, iter);

        assertEquals(2, opt.addedValues.size());
        assertEquals("value1", opt.addedValues.get(0));
        assertEquals("value2", opt.addedValues.get(1));
        assertEquals(2, opt.addValueForProcessingCount);

        assertEquals("-b", iter.next());
    }

    @Test
    public void test_processArgs_stripsQuotesFromValue() throws Exception {
        final Options options = new Options();
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", true, "desc");
        opt.setValues(new ArrayList<String>());

        final ListIterator<String> iter = iteratorOf("\"quoted\"");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.addValueForProcessingCount);
        assertEquals(1, opt.addedValues.size());
        assertEquals("quoted", opt.addedValues.get(0));
        assertFalse(opt.addedValues.contains("\"quoted\""));
    }

    @Test
    public void test_processArgs_runtimeExceptionFromAddValue_rollsBackAndStops() throws Exception {
        final Options options = new Options();
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", true, "desc");
        opt.setValues(new ArrayList<String>());
        opt.throwOnAddValue = true;

        final ListIterator<String> iter = iteratorOf("v1", "v2", "v3");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.addValueForProcessingCount);
        assertEquals("v1", iter.next());
    }

    @Test
    public void test_processArgs_noValuesAndNotOptional_throwsMissingArgumentException() throws Exception {
        final Options options = new Options();
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", false, "desc");
        opt.setValues(null);

        final ListIterator<String> iter = iteratorOf();

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (final MissingArgumentException e) {
            assertSame(opt, e.getOption());
        }

        assertEquals(0, opt.addValueForProcessingCount);
    }

    @Test
    public void test_processArgs_noValuesButOptional_doesNotThrow() throws Exception {
        final Options options = new Options();
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", true, "desc");
        opt.setValues(null);

        final ListIterator<String> iter = iteratorOf();

        parser.processArgs(opt, iter);

        assertEquals(0, opt.addValueForProcessingCount);
    }

    @Test
    public void test_processArgs_iteratorExhausted_endsNormally() throws Exception {
        final Options options = new Options();
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", true, "desc");
        opt.setValues(new ArrayList<String>());

        final ListIterator<String> iter = iteratorOf("v1", "v2");

        parser.processArgs(opt, iter);

        assertEquals(2, opt.addValueForProcessingCount);
        assertEquals(2, opt.addedValues.size());
        assertEquals("v1", opt.addedValues.get(0));
        assertEquals("v2", opt.addedValues.get(1));
        assertFalse(iter.hasPrevious());
    }

    @Test
    public void test_processArgs_firstElementIsOption_rollsBackImmediately() throws Exception {
        final Options options = optionsWith("b");
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", true, "desc");
        opt.setValues(new ArrayList<String>());

        final ListIterator<String> iter = iteratorOf("-b", "value");

        parser.processArgs(opt, iter);

        assertEquals(0, opt.addValueForProcessingCount);
        assertEquals("-b", iter.next());
    }

    @Test
    public void test_processArgs_dashPrefixedValueNotInOptions_treatedAsValue() throws Exception {
        final Options options = new Options();
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", true, "desc");
        opt.setValues(new ArrayList<String>());

        final ListIterator<String> iter = iteratorOf("-unknown");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.addValueForProcessingCount);
        assertEquals(1, opt.addedValues.size());
        assertEquals("-unknown", opt.addedValues.get(0));
        assertFalse(iter.hasPrevious());
    }

    @Test
    public void test_processArgs_optionInOptionsButNoDashPrefix_treatedAsValue() throws Exception {
        final Options options = optionsWith("b");
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", true, "desc");
        opt.setValues(new ArrayList<String>());

        final ListIterator<String> iter = iteratorOf("b");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.addValueForProcessingCount);
        assertEquals(1, opt.addedValues.size());
        assertEquals("b", opt.addedValues.get(0));
        assertFalse(iter.hasPrevious());
    }

    @Test
    public void test_processArgs_emptyIteratorAndHasValues_doesNotThrow() throws Exception {
        final Options options = new Options();
        parser.setOptions(options);

        final RecordingOption opt = new RecordingOption("a", false, "desc");
        opt.setValues(new ArrayList<String>());

        final ListIterator<String> iter = iteratorOf();

        parser.processArgs(opt, iter);

        assertEquals(0, opt.addValueForProcessingCount);
    }

    static class TestableParser extends Parser {
        private Options injectedOptions;

        void setOptions(final Options options) {
            this.injectedOptions = options;
        }

        @Override
        protected Options getOptions() {
            return injectedOptions;
        }

        @Override
        public CommandLine parse(final Options opts, final String[] arguments) throws ParseException {
            throw new UnsupportedOperationException("not used in tests");
        }

        @Override
        public CommandLine parse(final Options opts, final String[] arguments, final boolean stopAtNonOption)
                throws ParseException {
            throw new UnsupportedOperationException("not used in tests");
        }

        @Override
        public CommandLine parse(final Options opts, final String[] arguments, final Properties properties)
                throws ParseException {
            throw new UnsupportedOperationException("not used in tests");
        }

        @Override
        public CommandLine parse(final Options opts, final String[] arguments, final Properties properties,
                final boolean stopAtNonOption) throws ParseException {
            throw new UnsupportedOperationException("not used in tests");
        }
    }

    static class RecordingOption extends Option {
        private static final long serialVersionUID = 1L;

        final List<String> addedValues = new ArrayList<String>();
        int addValueForProcessingCount;
        boolean throwOnAddValue;

        RecordingOption(final String opt, final boolean hasArg, final String description) {
            super(opt, hasArg, description);
        }

        @Override
        public void addValueForProcessing(final String value) {
            addValueForProcessingCount++;
            if (throwOnAddValue) {
                throw new RuntimeException("boom");
            }
            addedValues.add(value);
        }
    }
}