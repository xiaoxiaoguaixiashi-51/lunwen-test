import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.junit.Before;
import org.junit.Test;

public class ElementGetNamespacesInScopeTest {

    private Namespace xmlNamespace;
    private Namespace noNamespace;

    @Before
    public void setUp() {
        xmlNamespace = Namespace.XML_NAMESPACE;
        noNamespace = Namespace.NO_NAMESPACE;
    }

    private static void assertContainsPrefix(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return;
            }
        }
        fail("Expected list to contain prefix '" + prefix + "' but it did not: " + list);
    }

    private static void assertNotContainsPrefix(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                fail("Expected list NOT to contain prefix '" + prefix + "' but it did: " + list);
            }
        }
    }

    private static void assertPrefixMapsTo(List<Namespace> list, String prefix, String uri) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                assertEquals("URI for prefix '" + prefix + "'", uri, ns.getURI());
                return;
            }
        }
        fail("Expected list to contain prefix '" + prefix + "' but it did not: " + list);
    }

    private static int countPrefix(List<Namespace> list, String prefix) {
        int count = 0;
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                count++;
            }
        }
        return count;
    }

    @Test
    public void test_rootElement_noAdditionalNamespaces_noAttributes() {
        Element element = new Element("root");

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertSame(element.getNamespace(), result.get(0));
        assertContainsPrefix(result, "xml");
        assertPrefixMapsTo(result, "xml", Namespace.XML_NAMESPACE.getURI());
        assertEquals(1, countPrefix(result, ""));
        assertEquals(2, result.size());
    }

    @Test
    public void test_rootElement_withNonDefaultNamespace_injectsNoNamespace() {
        Element element = new Element("root", Namespace.getNamespace("p", "http://p"));

        List<Namespace> result = element.getNamespacesInScope();

        assertSame(element.getNamespace(), result.get(0));
        assertContainsPrefix(result, "xml");
        assertPrefixMapsTo(result, "xml", Namespace.XML_NAMESPACE.getURI());
        assertContainsPrefix(result, "");
        assertPrefixMapsTo(result, "", Namespace.NO_NAMESPACE.getURI());
        assertEquals(3, result.size());
    }

    @Test
    public void test_rootElement_emptyCollections_noNPE() {
        Element element = new Element("root", Namespace.getNamespace("p", "http://p"));

        List<Namespace> result;
        try {
            result = element.getNamespacesInScope();
        } catch (RuntimeException e) {
            fail("getNamespacesInScope() should not throw, but threw: " + e);
            return;
        }

        try {
            result.add(Namespace.getNamespace("x", "http://x"));
            fail("Expected UnsupportedOperationException on add");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.remove(0);
            fail("Expected UnsupportedOperationException on remove");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.clear();
            fail("Expected UnsupportedOperationException on clear");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_multiLevelParentChain_inheritanceAndDedup() {
        Element grandparent = new Element("gp", Namespace.getNamespace("gp", "http://gp"));
        grandparent.addNamespace(Namespace.getNamespace("a", "http://a-gp"));

        Element parent = new Element("p", Namespace.getNamespace("p", "http://p"));
        parent.addNamespace(Namespace.getNamespace("b", "http://b-p"));

        Element child = new Element("c", Namespace.getNamespace("a", "http://a-child"));

        grandparent.addContent(parent);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertSame(child.getNamespace(), result.get(0));
        assertPrefixMapsTo(result, "a", "http://a-child");
        assertPrefixMapsTo(result, "b", "http://b-p");
        assertPrefixMapsTo(result, "gp", "http://gp");
        assertPrefixMapsTo(result, "p", "http://p");
        assertContainsPrefix(result, "xml");
        assertPrefixMapsTo(result, "xml", Namespace.XML_NAMESPACE.getURI());
        assertEquals(5, result.size());
    }

    @Test
    public void test_attributeNamespaces_collected() {
        Element element = new Element("e", Namespace.getNamespace("e", "http://e"));
        element.setAttribute(new Attribute("a", "v", Namespace.getNamespace("att", "http://att")));

        List<Namespace> result = element.getNamespacesInScope();

        assertPrefixMapsTo(result, "att", "http://att");
        assertPrefixMapsTo(result, "e", "http://e");
        assertContainsPrefix(result, "xml");
        assertPrefixMapsTo(result, "xml", Namespace.XML_NAMESPACE.getURI());
        assertEquals(3, result.size());
    }

    @Test
    public void test_attributeNamespace_conflictWithElementPrefix_dedup() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://element-p"));
        element.setAttribute(new Attribute("a", "v", Namespace.getNamespace("p", "http://attr-p")));

        List<Namespace> result = element.getNamespacesInScope();

        assertPrefixMapsTo(result, "p", "http://element-p");
        assertEquals(1, countPrefix(result, "p"));
        assertEquals(2, result.size());
    }

    @Test
    public void test_additionalNamespace_conflictWithElementPrefix_dedup() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://element-p"));
        element.addNamespace(Namespace.getNamespace("p", "http://additional-p"));

        List<Namespace> result = element.getNamespacesInScope();

        assertPrefixMapsTo(result, "p", "http://element-p");
        assertEquals(1, countPrefix(result, "p"));
        assertEquals(2, result.size());
    }

    @Test
    public void test_additionalNamespaces_multiplePrefixes_orderAndContent() {
        Element element = new Element("e", Namespace.getNamespace("m", "http://m"));
        element.addNamespace(Namespace.getNamespace("z", "http://z"));
        element.addNamespace(Namespace.getNamespace("a", "http://a"));
        element.addNamespace(Namespace.getNamespace("k", "http://k"));

        List<Namespace> result = element.getNamespacesInScope();

        assertSame(element.getNamespace(), result.get(0));
        assertEquals("a", result.get(1).getPrefix());
        assertEquals("k", result.get(2).getPrefix());
        assertEquals("xml", result.get(3).getPrefix());
        assertEquals("z", result.get(4).getPrefix());
        assertEquals(1, countPrefix(result, "m"));
        assertEquals(5, result.size());
    }

    @Test
    public void test_parentChainWithDefaultNamespace_noNoNamespaceInjection() {
        Element parent = new Element("p");
        Element child = new Element("c", Namespace.getNamespace("c", "http://c"));
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertPrefixMapsTo(result, "", Namespace.NO_NAMESPACE.getURI());
        assertPrefixMapsTo(result, "c", "http://c");
        assertContainsPrefix(result, "xml");
        assertPrefixMapsTo(result, "xml", Namespace.XML_NAMESPACE.getURI());
        assertEquals(3, result.size());
    }

    @Test
    public void test_xmlPrefixConflict_doesNotOverrideXmlNamespace() {
        Element element = new Element("e", Namespace.getNamespace("e", "http://e"));
        element.addNamespace(Namespace.getNamespace("xml", "http://fake-xml"));

        List<Namespace> result = element.getNamespacesInScope();

        assertPrefixMapsTo(result, "xml", Namespace.XML_NAMESPACE.getURI());
        assertEquals(1, countPrefix(result, "xml"));
    }

    @Test
    public void test_returnedList_isUnmodifiable() {
        Element element = new Element("e", Namespace.getNamespace("e", "http://e"));

        List<Namespace> result = element.getNamespacesInScope();

        try {
            result.add(Namespace.getNamespace("x", "http://x"));
            fail("Expected UnsupportedOperationException on add");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.set(0, Namespace.NO_NAMESPACE);
            fail("Expected UnsupportedOperationException on set");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.remove(0);
            fail("Expected UnsupportedOperationException on remove");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.clear();
            fail("Expected UnsupportedOperationException on clear");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_deepParentChain_recursionTerminates() {
        Element e0 = new Element("e0", Namespace.getNamespace("ns0", "http://ns0"));
        Element e1 = new Element("e1", Namespace.getNamespace("ns1", "http://ns1"));
        Element e2 = new Element("e2", Namespace.getNamespace("ns2", "http://ns2"));
        Element e3 = new Element("e3", Namespace.getNamespace("ns3", "http://ns3"));
        Element leaf = new Element("leaf", Namespace.getNamespace("leaf", "http://leaf"));

        e0.addContent(e1);
        e1.addContent(e2);
        e2.addContent(e3);
        e3.addContent(leaf);

        List<Namespace> result = leaf.getNamespacesInScope();

        assertSame(leaf.getNamespace(), result.get(0));
        assertContainsPrefix(result, "ns0");
        assertContainsPrefix(result, "ns1");
        assertContainsPrefix(result, "ns2");
        assertContainsPrefix(result, "ns3");
        assertContainsPrefix(result, "ns4");
        assertContainsPrefix(result, "xml");
        assertPrefixMapsTo(result, "xml", Namespace.XML_NAMESPACE.getURI());
        assertEquals(7, result.size());

        for (int i = 0; i < result.size(); i++) {
            for (int j = i + 1; j < result.size(); j++) {
                assertTrue("Duplicate prefix found: " + result.get(i).getPrefix(),
                        !result.get(i).getPrefix().equals(result.get(j).getPrefix()));
            }
        }
    }
}