import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.junit.Before;
import org.junit.Test;

public class ElementGetNamespacesInScopeTest {

    private Namespace nsA;
    private Namespace nsB;
    private Namespace nsDefault;
    private Namespace nsConflict;

    @Before
    public void setUp() {
        nsA = Namespace.getNamespace("a", "http://a");
        nsB = Namespace.getNamespace("b", "http://b");
        nsDefault = Namespace.getNamespace("http://default");
        nsConflict = Namespace.getNamespace("a", "http://a-conflict");
    }

    private static Element newElement(String name, Namespace ns) {
        return new Element(name, ns);
    }

    private static void assertContains(List<Namespace> list, Namespace ns) {
        assertTrue("Expected list to contain namespace " + ns, list.contains(ns));
    }

    private static void assertNotContains(List<Namespace> list, Namespace ns) {
        assertFalse("Expected list NOT to contain namespace " + ns, list.contains(ns));
    }

    private static Namespace findByPrefix(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return ns;
            }
        }
        return null;
    }

    @Test
    public void test_rootElement_noDefaultNamespace_injectsNoNamespace() {
        Element element = newElement("root", nsA);

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals(nsA, result.get(0));
        assertContains(result, Namespace.XML_NAMESPACE);
        assertContains(result, Namespace.NO_NAMESPACE);
        assertEquals(Namespace.NO_NAMESPACE, result.get(1));
        assertEquals(Namespace.XML_NAMESPACE, result.get(2));
    }

    @Test
    public void test_rootElement_withDefaultNamespace_noNoNamespaceInjection() {
        Element element = newElement("root", nsDefault);

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(nsDefault, result.get(0));
        assertContains(result, Namespace.XML_NAMESPACE);
        assertNotContains(result, Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_additionalNamespaces_collectedAndDeduplicated() {
        Element element = newElement("root", nsA);
        Namespace fakeXml = Namespace.getNamespace("xml", "http://fake-xml");
        element.addNamespaceDeclaration(nsB);
        element.addNamespaceDeclaration(nsConflict);
        element.addNamespaceDeclaration(fakeXml);
        element.addNamespaceDeclaration(nsB);

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(nsA, result.get(0));
        assertContains(result, nsB);
        assertNotContains(result, nsConflict);
        Namespace xmlNs = findByPrefix(result, "xml");
        assertNotNull(xmlNs);
        assertEquals(Namespace.XML_NAMESPACE, xmlNs);
        assertEquals("", result.get(1).getPrefix());
        assertEquals("b", result.get(2).getPrefix());
        assertEquals("xml", result.get(3).getPrefix());
    }

    @Test
    public void test_attributes_namespacesCollected() {
        Element element = newElement("root", nsA);
        Attribute attWithNs = new Attribute("attr", "v", nsB);
        Attribute attNoNs = new Attribute("attr", "v");
        element.setAttribute(attWithNs);
        element.setAttribute(attNoNs);

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(nsA, result.get(0));
        assertContains(result, nsB);
        assertContains(result, Namespace.NO_NAMESPACE);
        assertEquals(4, result.size());
    }

    @Test
    public void test_multiLevelInheritance_childOverridesParent() {
        Namespace nsG = Namespace.getNamespace("g", "http://g");
        Namespace nsP = Namespace.getNamespace("p", "http://p");
        Namespace nsC = Namespace.getNamespace("c", "http://c");

        Element grandParent = newElement("gp", nsG);
        Element parent = newElement("p", nsP);
        Element child = newElement("c", nsC);
        parent.addContent(child);
        grandParent.addContent(parent);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(nsC, result.get(0));
        assertNotNull(findByPrefix(result, "p"));
        assertNotNull(findByPrefix(result, "g"));
        assertContains(result, Namespace.XML_NAMESPACE);
        assertNotContains(result, Namespace.NO_NAMESPACE);
        assertEquals(4, result.size());
    }

    @Test
    public void test_parentNamespaceConflict_childWins() {
        Element parent = newElement("p", nsConflict);
        Element child = newElement("c", nsA);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(nsA, result.get(0));
        assertNotContains(result, nsConflict);
        Namespace aNs = findByPrefix(result, "a");
        assertNotNull(aNs);
        assertEquals("http://a", aNs.getURI());
    }

    @Test
    public void test_returnedListIsUnmodifiable() {
        Element element = newElement("root", nsA);

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        try {
            result.add(nsB);
            fail("Expected UnsupportedOperationException on add");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
        try {
            result.remove(0);
            fail("Expected UnsupportedOperationException on remove");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
        try {
            result.clear();
            fail("Expected UnsupportedOperationException on clear");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_nullAdditionalNamespacesAndAttributes_branchesSkipped() {
        Element element = newElement("root", nsA);

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals(nsA, result.get(0));
        assertContains(result, Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_emptyPrefixOnNonRootElement_noNoNamespaceInjection() {
        Element parent = newElement("p", nsA);
        Element child = newElement("c", nsDefault);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(nsDefault, result.get(0));
        assertNotContains(result, Namespace.NO_NAMESPACE);
        assertContains(result, nsA);
        assertContains(result, Namespace.XML_NAMESPACE);
        assertEquals(3, result.size());
    }

    @Test
    public void test_selfNamespaceSameAsXmlPrefix_noDuplicate() {
        Element element = newElement("root", Namespace.XML_NAMESPACE);

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(Namespace.XML_NAMESPACE, result.get(0));
        int xmlCount = 0;
        for (Namespace ns : result) {
            if ("xml".equals(ns.getPrefix())) {
                xmlCount++;
            }
        }
        assertEquals(1, xmlCount);
        assertContains(result, Namespace.NO_NAMESPACE);
        assertEquals(2, result.size());
    }

    @Test
    public void test_orderIsSelfFirstThenLexicographic() {
        Namespace nsZ = Namespace.getNamespace("z", "http://z");
        Namespace nsM = Namespace.getNamespace("m", "http://m");
        Namespace nsA2 = Namespace.getNamespace("a", "http://a");
        Element element = newElement("root", nsZ);
        element.addNamespaceDeclaration(nsM);
        element.addNamespaceDeclaration(nsA2);

        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(5, result.size());
        assertEquals("z", result.get(0).getPrefix());
        assertEquals("", result.get(1).getPrefix());
        assertEquals("a", result.get(2).getPrefix());
        assertEquals("m", result.get(3).getPrefix());
        assertEquals("xml", result.get(4).getPrefix());
    }
}