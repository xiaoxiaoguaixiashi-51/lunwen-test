package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ParserProcessArgsTest {

    private TestParser parser;

    @Before
    public void setUp() {
        parser = new TestParser();
    }

    private static class TestParser extends Parser {
        private Options options;

        TestParser() {
            this.options = new Options();
        }

        void setOptions(Options options) {
            this.options = options;
        }

        @Override
        protected Options getOptions() {
            return options;
        }

        @Override
        public CommandLine parse(Options opts, String[] arguments) throws ParseException {
            throw new UnsupportedOperationException("not used in tests");
        }

        @Override
        public CommandLine parse(Options opts, String[] arguments, Properties properties) throws ParseException {
            throw new UnsupportedOperationException("not used in tests");
        }

        @Override
        public CommandLine parse(Options opts, String[] arguments, Properties properties, boolean stopAtNonOption) throws ParseException {
            throw new UnsupportedOperationException("not used in tests");
        }
    }

    private static class RecordingListIterator implements ListIterator<String> {
        private final List<String> backing;
        private int cursor;
        private int previousCalls;
        private int nextCalls;

        RecordingListIterator(List<String> backing) {
            this.backing = new ArrayList<String>(backing);
            this.cursor = 0;
        }

        @Override
        public boolean hasNext() {
            return cursor < backing.size();
        }

        @Override
        public String next() {
            nextCalls++;
            return backing.get(cursor++);
        }

        @Override
        public boolean hasPrevious() {
            return cursor > 0;
        }

        @Override
        public String previous() {
            previousCalls++;
            return backing.get(--cursor);
        }

        @Override
        public int nextIndex() {
            return cursor;
        }

        @Override
        public int previousIndex() {
            return cursor - 1;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void set(String s) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void add(String s) {
            throw new UnsupportedOperationException();
        }

        int getPreviousCalls() {
            return previousCalls;
        }

        int getNextCalls() {
            return nextCalls;
        }
    }

    private static class ThrowingOption extends Option {
        private final String[] values;
        private final boolean optionalArg;
        private final String throwOnValue;
        private int addValueCalls;

        ThrowingOption(String opt, String longOpt, boolean hasArg, String[] values, boolean optionalArg, String throwOnValue) {
            super(opt, longOpt, hasArg);
            this.values = values;
            this.optionalArg = optionalArg;
            this.throwOnValue = throwOnValue;
        }

        @Override
        public void addValueForProcessing(String value) {
            addValueCalls++;
            if (throwOnValue != null && throwOnValue.equals(value)) {
                throw new RuntimeException("invalid");
            }
            super.addValueForProcessing(value);
        }

        @Override
        public String[] getValues() {
            return values;
        }

        @Override
        public boolean hasOptionalArg() {
            return optionalArg;
        }

        int getAddValueCalls() {
            return addValueCalls;
        }
    }

    private static class FixedValuesOption extends Option {
        private final String[] values;
        private final boolean optionalArg;
        private int addValueCalls;

        FixedValuesOption(String opt, String longOpt, boolean hasArg, String[] values, boolean optionalArg) {
            super(opt, longOpt, hasArg);
            this.values = values;
            this.optionalArg = optionalArg;
        }

        @Override
        public void addValueForProcessing(String value) {
            addValueCalls++;
            super.addValueForProcessing(value);
        }

        @Override
        public String[] getValues() {
            return values;
        }

        @Override
        public boolean hasOptionalArg() {
            return optionalArg;
        }

        int getAddValueCalls() {
            return addValueCalls;
        }
    }

    private static class EmptyListIterator implements ListIterator<String> {
        private int previousCalls;

        @Override
        public boolean hasNext() {
            return false;
        }

        @Override
        public String next() {
            throw new java.util.NoSuchElementException();
        }

        @Override
        public boolean hasPrevious() {
            return false;
        }

        @Override
        public String previous() {
            previousCalls++;
            throw new java.util.NoSuchElementException();
        }

        @Override
        public int nextIndex() {
            return 0;
        }

        @Override
        public int previousIndex() {
            return -1;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void set(String s) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void add(String s) {
            throw new UnsupportedOperationException();
        }

        int getPreviousCalls() {
            return previousCalls;
        }
    }

    @Test
    public void test_collectMultipleValuesUntilNewOption() throws Exception {
        Options options = new Options();
        options.addOption(new Option("x", "xlong", false, "an option"));
        parser.setOptions(options);

        Option opt = new Option("o", "opt", true, "an option with arg");
        RecordingListIterator iter = new RecordingListIterator(Arrays.asList("a", "b", "-x"));

        parser.processArgs(opt, iter);

        assertArrayEquals(new String[]{"a", "b"}, opt.getValues());
        assertEquals("-x", iter.next());
        assertEquals(1, iter.getPreviousCalls());
    }

    @Test
    public void test_stripQuotesBeforeCollecting() throws Exception {
        Options options = new Options();
        parser.setOptions(options);

        Option opt = new Option("o", "opt", true, "an option with arg");
        RecordingListIterator iter = new RecordingListIterator(Arrays.asList("\"quoted\""));

        parser.processArgs(opt, iter);

        assertArrayEquals(new String[]{"quoted"}, opt.getValues());
        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_addValueThrowsRuntimeException_rollbackAndStop() throws Exception {
        Options options = new Options();
        parser.setOptions(options);

        ThrowingOption opt = new ThrowingOption("o", "opt", true, new String[]{"existing"}, false, "bad");
        RecordingListIterator iter = new RecordingListIterator(Arrays.asList("bad"));

        parser.processArgs(opt, iter);

        assertEquals(1, iter.getPreviousCalls());
        assertEquals(1, opt.getAddValueCalls());
        assertArrayEquals(new String[]{"existing"}, opt.getValues());
    }

    @Test
    public void test_addValueThrowsRuntimeException_thenMissingArgument() throws Exception {
        Options options = new Options();
        parser.setOptions(options);

        ThrowingOption opt = new ThrowingOption("o", "opt", true, null, false, "bad");
        RecordingListIterator iter = new RecordingListIterator(Arrays.asList("bad"));

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (MissingArgumentException e) {
            assertNotNull(e);
        }

        assertEquals(1, iter.getPreviousCalls());
        assertEquals(1, opt.getAddValueCalls());
    }

    @Test
    public void test_emptyIterator_nonOptional_throwsMissingArgument() throws Exception {
        Options options = new Options();
        parser.setOptions(options);

        FixedValuesOption opt = new FixedValuesOption("o", "opt", true, null, false);
        EmptyListIterator iter = new EmptyListIterator();

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (MissingArgumentException e) {
            assertNotNull(e);
            assertNotNull(e.getMessage());
            assertTrue(e.getMessage().contains("o"));
        }

        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_emptyIterator_optionalArg_noException() throws Exception {
        Options options = new Options();
        parser.setOptions(options);

        FixedValuesOption opt = new FixedValuesOption("o", "opt", true, null, true);
        EmptyListIterator iter = new EmptyListIterator();

        parser.processArgs(opt, iter);

        assertNull(opt.getValues());
        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_dashPrefixedButNotOption_collectedAsValue() throws Exception {
        Options options = new Options();
        parser.setOptions(options);

        Option opt = new Option("o", "opt", true, "an option with arg");
        RecordingListIterator iter = new RecordingListIterator(Arrays.asList("-unknown"));

        parser.processArgs(opt, iter);

        assertArrayEquals(new String[]{"-unknown"}, opt.getValues());
        assertFalse(iter.hasNext());
        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_hasOptionTrueButNoDashPrefix_collectedAsValue() throws Exception {
        Options options = new Options();
        options.addOption(new Option("plain", "plain", false, "plain option"));
        parser.setOptions(options);

        Option opt = new Option("o", "opt", true, "an option with arg");
        RecordingListIterator iter = new RecordingListIterator(Arrays.asList("plain"));

        parser.processArgs(opt, iter);

        assertArrayEquals(new String[]{"plain"}, opt.getValues());
        assertFalse(iter.hasNext());
        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_singleValueThenEnd_collected() throws Exception {
        Options options = new Options();
        parser.setOptions(options);

        Option opt = new Option("o", "opt", true, "an option with arg");
        RecordingListIterator iter = new RecordingListIterator(Arrays.asList("only"));

        parser.processArgs(opt, iter);

        assertArrayEquals(new String[]{"only"}, opt.getValues());
        assertEquals(0, iter.getPreviousCalls());
    }

    @Test
    public void test_optionAtFirstPosition_immediateRollback() throws Exception {
        Options options = new Options();
        options.addOption(new Option("x", "xlong", false, "an option"));
        parser.setOptions(options);

        FixedValuesOption opt = new FixedValuesOption("o", "opt", true, null, true);
        RecordingListIterator iter = new RecordingListIterator(Arrays.asList("-x", "a"));

        parser.processArgs(opt, iter);

        assertEquals("-x", iter.next());
        assertEquals(0, opt.getAddValueCalls());
        assertEquals(1, iter.getPreviousCalls());
    }

    @Test
    public void test_getValuesNonNull_nonOptional_noException() throws Exception {
        Options options = new Options();
        parser.setOptions(options);

        FixedValuesOption opt = new FixedValuesOption("o", "opt", true, new String[]{"v"}, false);
        EmptyListIterator iter = new EmptyListIterator();

        parser.processArgs(opt, iter);

        assertArrayEquals(new String[]{"v"}, opt.getValues());
        assertEquals(0, iter.getPreviousCalls());
    }
}