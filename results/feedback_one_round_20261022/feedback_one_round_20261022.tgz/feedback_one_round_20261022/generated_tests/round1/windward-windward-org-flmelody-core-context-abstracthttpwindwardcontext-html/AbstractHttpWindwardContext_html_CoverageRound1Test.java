package org.flmelody.core.context;

import java.util.HashMap;
import java.util.Map;
import org.flmelody.core.Windward;
import org.flmelody.core.WindwardRequest;
import org.flmelody.core.WindwardResponse;
import org.flmelody.core.exception.WindwardException;
import org.flmelody.core.plugin.PluginSlot;
import org.flmelody.core.plugin.json.JsonPlugin;
import org.flmelody.core.plugin.view.AbstractViewPlugin;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class AbstractHttpWindwardContext_html_CoverageRound1Test {

  private static class TestContext extends AbstractHttpWindwardContext {
    TestContext(WindwardRequest request, WindwardResponse response) {
      super(request, response);
    }
  }

  private static class SimpleJsonPlugin implements JsonPlugin {
    @Override
    public <I> String toJson(I data) {
      return "{}";
    }

    @Override
    public <O> O toObject(String json, Class<O> clazz) {
      try {
        return clazz.newInstance();
      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <I, O> O toObject(I data, java.lang.reflect.Type type) {
      try {
        return (O) ((Class<?>) type).newInstance();
      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    }
  }

  private static class TestViewPlugin extends AbstractViewPlugin {
    private final String extension;
    private final boolean throwOnRender;

    TestViewPlugin(String extension, boolean throwOnRender) {
      super("", extension);
      this.extension = extension;
      this.throwOnRender = throwOnRender;
    }

    @Override
    public boolean supportedExtension(String extension) {
      return this.extension.equals(extension);
    }

    @Override
    public String render(String viewUrl, Map<String, Object> model) throws Exception {
      if (throwOnRender) {
        throw new Exception("boom");
      }
      return "<html>rendered:" + viewUrl + "</html>";
    }
  }

  private TestContext newContext() {
    WindwardRequest request = WindwardRequest.newBuild().build();
    WindwardResponse response = WindwardResponse.newBuilder().build();
    return new TestContext(request, response);
  }

  private void registerJsonPlugin() {
    Windward.setup().registerPlugin(PluginSlot.JSON, new SimpleJsonPlugin());
  }

  @Test
  public void html_nullViewUrl_throwsWindwardException() {
    TestContext ctx = newContext();
    try {
      ctx.html(null, new HashMap<String, Object>());
      fail("Expected WindwardException");
    } catch (WindwardException e) {
      assertNotNull(e.getMessage());
      assertTrue(e.getMessage().contains("empty"));
    }
  }

  @Test
  public void html_emptyViewUrl_throwsWindwardException() {
    TestContext ctx = newContext();
    try {
      ctx.html("", new HashMap<String, Object>());
      fail("Expected WindwardException");
    } catch (WindwardException e) {
      assertNotNull(e.getMessage());
      assertTrue(e.getMessage().contains("empty"));
    }
  }

  @Test
  public void html_noExtension_throwsWindwardException() {
    TestContext ctx = newContext();
    try {
      ctx.html("viewWithoutExtension", new HashMap<String, Object>());
      fail("Expected WindwardException");
    } catch (WindwardException e) {
      assertNotNull(e.getMessage());
      assertTrue(e.getMessage().contains("extension"));
    }
  }

  @Test
  public void html_leadingDotOnly_throwsWindwardException() {
    TestContext ctx = newContext();
    try {
      ctx.html(".html", new HashMap<String, Object>());
      fail("Expected WindwardException");
    } catch (WindwardException e) {
      assertNotNull(e.getMessage());
      assertTrue(e.getMessage().contains("extension"));
    }
  }

  @Test
  public void html_unsupportedExtension_throwsWindwardException() {
    TestContext ctx = newContext();
    try {
      ctx.html("view.unknown", new HashMap<String, Object>());
      fail("Expected WindwardException");
    } catch (WindwardException e) {
      assertNotNull(e.getMessage());
      assertTrue(e.getMessage().contains("Unsupported"));
    }
  }

  @Test
  public void html_supportedExtension_rendersView() {
    registerJsonPlugin();
    Windward.setup().registerPlugin(PluginSlot.VIEW, new TestViewPlugin("html", false));
    TestContext ctx = newContext();
    Map<String, Object> model = new HashMap<String, Object>();
    model.put("key", "value");
    ctx.html("index.html", model);
  }

  @Test
  public void html_resolveViewThrows_wrapsInRuntimeException() {
    registerJsonPlugin();
    Windward.setup().registerPlugin(PluginSlot.VIEW, new TestViewPlugin("boom", true));
    TestContext ctx = newContext();
    try {
      ctx.html("index.boom", new HashMap<String, Object>());
      fail("Expected RuntimeException");
    } catch (RuntimeException e) {
      assertNotNull(e.getCause());
    }
  }
}
