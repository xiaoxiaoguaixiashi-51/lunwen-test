package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.Test;

public class CSVPrinter_printComment_CoverageRound1Test {

    private static final char COMMENT_MARKER = '#';

    private CSVFormat formatWithComments() {
        return CSVFormat.DEFAULT.builder().setCommentMarker(COMMENT_MARKER).build();
    }

    @Test
    public void testNullCommentDoesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.printComment(null);
        assertEquals("", sw.toString());
    }

    @Test
    public void testCommentMarkerNotSetDoesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("ignored");
        assertEquals("", sw.toString());
    }

    @Test
    public void testSimpleComment() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.printComment("hello");
        assertEquals("# hello" + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
    }

    @Test
    public void testCommentAfterRecordStartsNewLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.print("value");
        printer.printComment("note");
        final String out = sw.toString();
        assertTrue(out.contains("value"));
        assertTrue(out.contains("# note"));
    }

    @Test
    public void testCommentWithLf() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.printComment("line1\nline2");
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# line2" + rs, sw.toString());
    }

    @Test
    public void testCommentWithCrLf() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.printComment("line1\r\nline2");
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# line2" + rs, sw.toString());
    }

    @Test
    public void testCommentWithStandaloneCr() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.printComment("line1\rline2");
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# line2" + rs, sw.toString());
    }

    @Test
    public void testCommentWithTrailingCr() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.printComment("line1\r");
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# " + rs, sw.toString());
    }

    @Test
    public void testCommentWithMultipleLineBreaks() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.printComment("a\nb\r\nc\rd");
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# a" + rs + "# b" + rs + "# c" + rs + "# d" + rs, sw.toString());
    }

    @Test
    public void testEmptyComment() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithComments());
        printer.printComment("");
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# " + rs, sw.toString());
    }

    @Test
    public void testCommentWithCustomMarker() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('!').build();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hi");
        assertEquals("! hi" + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
    }
}
