package org.apache.commons.collections4.functors;

import org.apache.commons.collections4.FunctorException;
import org.apache.commons.collections4.Transformer;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class InvokerTransformer_transform_CoverageRound1Test {

    public static class Sample {
        public String greet() {
            return "hello";
        }

        public String concat(final String a, final String b) {
            return a + b;
        }

        public String boom() {
            throw new IllegalStateException("boom");
        }

        public int add(final int a, final int b) {
            return a + b;
        }
    }

    @Test
    public void testNullInputReturnsNull() {
        final Transformer<Object, Object> t = InvokerTransformer.invokerTransformer("toString");
        assertNull(t.transform(null));
    }

    @Test
    public void testNoArgMethodInvocation() {
        final Transformer<Sample, String> t = InvokerTransformer.invokerTransformer("greet");
        assertEquals("hello", t.transform(new Sample()));
    }

    @Test
    public void testMethodWithArgs() {
        final Transformer<Sample, String> t = InvokerTransformer.invokerTransformer(
                "concat", new Class<?>[]{String.class, String.class}, new Object[]{"a", "b"});
        assertEquals("ab", t.transform(new Sample()));
    }

    @Test
    public void testPrimitiveArgs() {
        final Transformer<Sample, Integer> t = InvokerTransformer.invokerTransformer(
                "add", new Class<?>[]{int.class, int.class}, new Object[]{Integer.valueOf(2), Integer.valueOf(3)});
        assertEquals(Integer.valueOf(5), t.transform(new Sample()));
    }

    @Test
    public void testNoSuchMethodThrowsFunctorException() {
        final Transformer<Sample, Object> t = InvokerTransformer.invokerTransformer("doesNotExist");
        try {
            t.transform(new Sample());
            fail("Expected FunctorException");
        } catch (final FunctorException ex) {
            assertTrue(ex.getMessage().contains("doesNotExist"));
            assertTrue(ex.getMessage().contains("does not exist"));
        }
    }

    @Test
    public void testInvocationTargetExceptionWrapped() {
        final Transformer<Sample, Object> t = InvokerTransformer.invokerTransformer("boom");
        try {
            t.transform(new Sample());
            fail("Expected FunctorException");
        } catch (final FunctorException ex) {
            assertTrue(ex.getMessage().contains("threw an exception"));
            assertTrue(ex.getCause() instanceof java.lang.reflect.InvocationTargetException);
        }
    }

    @Test
    public void testIllegalAccessExceptionWrapped() {
        final Transformer<Object, Object> t = new InvokerTransformer<>(
                "privateMethod", null, null);
        try {
            t.transform(new PrivateHolder());
            fail("Expected FunctorException");
        } catch (final FunctorException ex) {
            assertTrue(ex.getMessage().contains("cannot be accessed")
                    || ex.getMessage().contains("does not exist"));
        }
    }

    public static class PrivateHolder {
        private String privateMethod() {
            return "secret";
        }
    }

    @Test
    public void testTransformReturnsSameResultType() {
        final Transformer<String, Integer> t = InvokerTransformer.invokerTransformer("length");
        final Integer len = t.transform("abcdef");
        assertEquals(Integer.valueOf(6), len);
    }

    @Test
    public void testTransformOnStringSubstring() {
        final Transformer<String, String> t = InvokerTransformer.invokerTransformer(
                "substring", new Class<?>[]{int.class}, new Object[]{Integer.valueOf(2)});
        assertEquals("cdef", t.transform("abcdef"));
    }

    @Test
    public void testTransformIdentity() {
        final Transformer<Object, Object> t = InvokerTransformer.invokerTransformer("toString");
        final Object o = new Object();
        assertEquals(o.toString(), t.transform(o));
    }
}
