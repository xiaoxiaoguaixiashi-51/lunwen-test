package org.apache.commons.codec.language;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class ColognePhonetic_colognePhonetic_CoverageRound1Test {

    private final ColognePhonetic cp = new ColognePhonetic();

    @Test
    public void testNull() {
        assertNull(cp.colognePhonetic(null));
    }

    @Test
    public void testEmpty() {
        assertEquals("", cp.colognePhonetic(""));
    }

    @Test
    public void testVowels() {
        assertEquals("0", cp.colognePhonetic("A"));
        assertEquals("0", cp.colognePhonetic("E"));
        assertEquals("0", cp.colognePhonetic("I"));
        assertEquals("0", cp.colognePhonetic("J"));
        assertEquals("0", cp.colognePhonetic("O"));
        assertEquals("0", cp.colognePhonetic("U"));
        assertEquals("0", cp.colognePhonetic("Y"));
    }

    @Test
    public void testBAndP() {
        assertEquals("1", cp.colognePhonetic("B"));
        assertEquals("1", cp.colognePhonetic("P"));
        // P before H -> code 3
        assertEquals("3", cp.colognePhonetic("PH"));
    }

    @Test
    public void testDAndT() {
        assertEquals("2", cp.colognePhonetic("D"));
        assertEquals("2", cp.colognePhonetic("T"));
        // D/T before C, S, Z -> code 8
        assertEquals("8", cp.colognePhonetic("DC"));
        assertEquals("8", cp.colognePhonetic("TS"));
        assertEquals("8", cp.colognePhonetic("TZ"));
    }

    @Test
    public void testFpvW() {
        assertEquals("3", cp.colognePhonetic("F"));
        assertEquals("3", cp.colognePhonetic("V"));
        assertEquals("3", cp.colognePhonetic("W"));
    }

    @Test
    public void testGkq() {
        assertEquals("4", cp.colognePhonetic("G"));
        assertEquals("4", cp.colognePhonetic("K"));
        assertEquals("4", cp.colognePhonetic("Q"));
    }

    @Test
    public void testXNotAfterCkq() {
        assertEquals("48", cp.colognePhonetic("X"));
        assertEquals("048", cp.colognePhonetic("AX"));
    }

    @Test
    public void testXAfterCkq() {
        // X after C, K, Q -> code 8
        assertEquals("48", cp.colognePhonetic("KX"));
        assertEquals("48", cp.colognePhonetic("CX"));
        assertEquals("48", cp.colognePhonetic("QX"));
    }

    @Test
    public void testSAndZ() {
        assertEquals("8", cp.colognePhonetic("S"));
        assertEquals("8", cp.colognePhonetic("Z"));
    }

    @Test
    public void testCAtOnsetBeforeAhkloqrux() {
        assertEquals("4", cp.colognePhonetic("CA"));
        assertEquals("4", cp.colognePhonetic("CH"));
        assertEquals("4", cp.colognePhonetic("CK"));
        assertEquals("45", cp.colognePhonetic("CL"));
        assertEquals("4", cp.colognePhonetic("CO"));
        assertEquals("4", cp.colognePhonetic("CQ"));
        assertEquals("47", cp.colognePhonetic("CR"));
        assertEquals("4", cp.colognePhonetic("CU"));
        assertEquals("48", cp.colognePhonetic("CX"));
    }

    @Test
    public void testCAtOnsetOther() {
        assertEquals("81", cp.colognePhonetic("CB"));
        assertEquals("82", cp.colognePhonetic("CD"));
        assertEquals("8", cp.colognePhonetic("CE"));
        assertEquals("83", cp.colognePhonetic("CF"));
        assertEquals("84", cp.colognePhonetic("CG"));
        assertEquals("8", cp.colognePhonetic("CI"));
        assertEquals("8", cp.colognePhonetic("CJ"));
        assertEquals("86", cp.colognePhonetic("CM"));
        assertEquals("86", cp.colognePhonetic("CN"));
        assertEquals("81", cp.colognePhonetic("CP"));
        assertEquals("88", cp.colognePhonetic("CS"));
        assertEquals("82", cp.colognePhonetic("CT"));
        assertEquals("83", cp.colognePhonetic("CV"));
        assertEquals("83", cp.colognePhonetic("CW"));
        assertEquals("8", cp.colognePhonetic("CY"));
        assertEquals("88", cp.colognePhonetic("CZ"));
    }

    @Test
    public void testCAfterSZ() {
        // C after S or Z -> 8
        assertEquals("8", cp.colognePhonetic("SC"));
        assertEquals("8", cp.colognePhonetic("ZC"));
    }

    @Test
    public void testCNotAtOnsetBeforeAhkoqux() {
        // C not at onset, before A/H/K/O/Q/U/X -> 4
        assertEquals("04", cp.colognePhonetic("ACA"));
        assertEquals("04", cp.colognePhonetic("ACH"));
        assertEquals("04", cp.colognePhonetic("ACK"));
        assertEquals("04", cp.colognePhonetic("ACO"));
        assertEquals("04", cp.colognePhonetic("ACQ"));
        assertEquals("04", cp.colognePhonetic("ACU"));
        assertEquals("048", cp.colognePhonetic("ACX"));
    }

    @Test
    public void testCNotAtOnsetOther() {
        // C not at onset, not before A/H/K/O/Q/U/X -> 8
        assertEquals("081", cp.colognePhonetic("ACB"));
        assertEquals("08", cp.colognePhonetic("ACE"));
        assertEquals("083", cp.colognePhonetic("ACF"));
        assertEquals("084", cp.colognePhonetic("ACG"));
        assertEquals("08", cp.colognePhonetic("ACI"));
        assertEquals("08", cp.colognePhonetic("ACJ"));
        assertEquals("085", cp.colognePhonetic("ACL"));
        assertEquals("086", cp.colognePhonetic("ACM"));
        assertEquals("086", cp.colognePhonetic("ACN"));
        assertEquals("081", cp.colognePhonetic("ACP"));
        assertEquals("087", cp.colognePhonetic("ACR"));
        assertEquals("082", cp.colognePhonetic("ACT"));
        assertEquals("083", cp.colognePhonetic("ACV"));
        assertEquals("083", cp.colognePhonetic("ACW"));
        assertEquals("08", cp.colognePhonetic("ACY"));
    }

    @Test
    public void testDtxFallback() {
        // D/T before C,S,Z handled; X after C,K,Q handled; but D/T before other -> 2
        // The DTX branch is reached when chr is D or T but next is C/S/Z (already handled above)
        // Actually DTX branch is for D/T/X that fell through. X after C/K/Q falls here.
        assertEquals("48", cp.colognePhonetic("KX"));
    }

    @Test
    public void testR() {
        assertEquals("7", cp.colognePhonetic("R"));
    }

    @Test
    public void testL() {
        assertEquals("5", cp.colognePhonetic("L"));
    }

    @Test
    public void testMAndN() {
        assertEquals("6", cp.colognePhonetic("M"));
        assertEquals("6", cp.colognePhonetic("N"));
    }

    @Test
    public void testH() {
        // H is ignored
        assertEquals("0", cp.colognePhonetic("AH"));
        assertEquals("", cp.colognePhonetic("H"));
    }

    @Test
    public void testDefaultSwitch() {
        // Characters that fall through to default (e.g. 'A' handled earlier, but 'W' etc.)
        // 'W' is handled by FPVW. Try a char not in any list: none really, but 'A'..'Z' all covered.
        // Use a character that is not A-Z to hit the continue branch.
        assertEquals("", cp.colognePhonetic("123"));
        assertEquals("", cp.colognePhonetic("!@#"));
    }

    @Test
    public void testIgnoreUnwantedCharacters() {
        assertEquals("0", cp.colognePhonetic("A1"));
        assertEquals("0", cp.colognePhonetic("1A"));
        assertEquals("01", cp.colognePhonetic("A B"));
    }

    @Test
    public void testMullerLudenscheidt() {
        assertEquals("65752682", cp.colognePhonetic("M\u00fcller-L\u00fcdenscheidt"));
    }

    @Test
    public void testWikipediaExamples() {
        assertEquals("65752682", cp.colognePhonetic("M\u00fcller-L\u00fcdenscheidt"));
        assertEquals("65752682", cp.colognePhonetic("muller-ludenscheidt"));
        assertEquals("65752682", cp.colognePhonetic("MUELLER-LUEDENSCHEIDT"));
    }

    @Test
    public void testUmlauts() {
        assertEquals("0", cp.colognePhonetic("\u00c4"));
        assertEquals("0", cp.colognePhonetic("\u00dc"));
        assertEquals("0", cp.colognePhonetic("\u00d6"));
    }

    @Test
    public void testEszett() {
        // ß -> SS
        assertEquals("8", cp.colognePhonetic("\u00df"));
    }

    @Test
    public void testEncodeString() {
        assertEquals("65752682", cp.encode("M\u00fcller-L\u00fcdenscheidt"));
    }

    @Test
    public void testIsEncodeEqual() {
        assertEquals(true, cp.isEncodeEqual("M\u00fcller", "Mueller"));
        assertEquals(false, cp.isEncodeEqual("M\u00fcller", "Schmidt"));
    }

    @Test
    public void testMultipleConsecutiveCodes() {
        assertEquals("6", cp.colognePhonetic("MM"));
        assertEquals("6", cp.colognePhonetic("MN"));
        assertEquals("8", cp.colognePhonetic("SS"));
        assertEquals("8", cp.colognePhonetic("SZ"));
    }

    @Test
    public void testZeroRemoval() {
        // 0 only kept at beginning
        assertEquals("0", cp.colognePhonetic("A"));
        assertEquals("0", cp.colognePhonetic("AA"));
        assertEquals("02", cp.colognePhonetic("AD"));
        assertEquals("2", cp.colognePhonetic("DA"));
    }

    @Test
    public void testComplexWords() {
        assertEquals("65752682", cp.colognePhonetic("M\u00fcller-L\u00fcdenscheidt"));
        assertEquals("8", cp.colognePhonetic("C"));
        assertEquals("8", cp.colognePhonetic("C"));
    }

    @Test
    public void testSingleC() {
        // C at onset, no next char -> nextChar is CHAR_IGNORE, not in AHKLOQRUX -> 8
        assertEquals("8", cp.colognePhonetic("C"));
    }

    @Test
    public void testSingleP() {
        // P with no next char -> nextChar is CHAR_IGNORE != 'H' -> 1
        assertEquals("1", cp.colognePhonetic("P"));
    }

    @Test
    public void testSingleD() {
        // D with no next char -> nextChar is CHAR_IGNORE, not in CSZ -> 2
        assertEquals("2", cp.colognePhonetic("D"));
    }

    @Test
    public void testSingleT() {
        assertEquals("2", cp.colognePhonetic("T"));
    }

    @Test
    public void testSingleX() {
        // X with no next char, lastChar is CHAR_IGNORE, not in CKQ -> 48
        assertEquals("48", cp.colognePhonetic("X"));
    }

    @Test
    public void testXAfterC() {
        // X after C -> 8
        assertEquals("48", cp.colognePhonetic("CX"));
    }

    @Test
    public void testXAfterK() {
        assertEquals("48", cp.colognePhonetic("KX"));
    }

    @Test
    public void testXAfterQ() {
        assertEquals("48", cp.colognePhonetic("QX"));
    }

    @Test
    public void testXAfterOther() {
        assertEquals("048", cp.colognePhonetic("AX"));
    }

    @Test
    public void testLowercaseInput() {
        assertEquals("65752682", cp.colognePhonetic("m\u00fcller-l\u00fcdenscheidt"));
    }

    @Test
    public void testWhitespaceAndPunctuation() {
        assertEquals("65752682", cp.colognePhonetic("M\u00fcller - L\u00fcdenscheidt"));
        assertEquals("65752682", cp.colognePhonetic("M\u00fcller, L\u00fcdenscheidt!"));
    }
}
