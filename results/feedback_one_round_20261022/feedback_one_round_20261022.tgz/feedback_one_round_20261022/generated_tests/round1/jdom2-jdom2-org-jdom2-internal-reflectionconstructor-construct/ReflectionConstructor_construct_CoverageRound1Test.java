package org.jdom2.internal;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ReflectionConstructor_construct_CoverageRound1Test {

    public static class PublicNoArg {
        public PublicNoArg() {
        }
    }

    public static class PublicWithArgOnly {
        public PublicWithArgOnly(String s) {
        }
    }

    public static class ThrowingConstructor {
        public ThrowingConstructor() {
            throw new RuntimeException("boom");
        }
    }

    public static class PrivateConstructor {
        private PrivateConstructor() {
        }
    }

    public static class AbstractClass {
        public AbstractClass() {
        }
    }

    public interface SomeInterface {
    }

    public static class SubType extends PublicNoArg {
    }

    @Test
    public void testConstructSuccess() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructSuccessWithSuperTypeTarget() {
        PublicNoArg result = ReflectionConstructor.construct(
                SubType.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof SubType);
    }

    @Test
    public void testConstructSuccessWithObjectTarget() {
        Object result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), Object.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructClassNotFound() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.DoesNotExistClassXYZ", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void testConstructNotAssignable() {
        try {
            ReflectionConstructor.construct(
                    PublicNoArg.class.getName(), String.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    @Test
    public void testConstructNoNoArgConstructor() {
        try {
            ReflectionConstructor.construct(
                    PublicWithArgOnly.class.getName(), PublicWithArgOnly.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructPrivateConstructor() {
        try {
            ReflectionConstructor.construct(
                    PrivateConstructor.class.getName(), PrivateConstructor.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructAbstractClass() {
        try {
            ReflectionConstructor.construct(
                    AbstractClass.class.getName(), AbstractClass.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    @Test
    public void testConstructInterface() {
        try {
            ReflectionConstructor.construct(
                    SomeInterface.class.getName(), SomeInterface.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructThrowingConstructor() {
        try {
            ReflectionConstructor.construct(
                    ThrowingConstructor.class.getName(), ThrowingConstructor.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof java.lang.reflect.InvocationTargetException);
        }
    }

    @Test
    public void testConstructJdkClass() {
        StringBuilder sb = ReflectionConstructor.construct(
                StringBuilder.class.getName(), StringBuilder.class);
        assertNotNull(sb);
        assertEquals(0, sb.length());
    }

    @Test
    public void testConstructReturnsSameInstanceType() {
        PublicNoArg a = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        PublicNoArg b = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(a);
        assertNotNull(b);
        assertTrue(a != b);
        assertSame(PublicNoArg.class, a.getClass());
    }
}
