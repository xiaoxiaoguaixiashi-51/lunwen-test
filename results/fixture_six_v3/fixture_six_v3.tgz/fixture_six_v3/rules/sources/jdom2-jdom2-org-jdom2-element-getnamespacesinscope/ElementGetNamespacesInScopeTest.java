import org.junit.Test;

import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ElementGetNamespacesInScopeTest {

    private static Namespace find(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return ns;
            }
        }
        return null;
    }

    @Test
    public void s1_elementVersusAddedDeclaration() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://self"));
        element.addNamespaceDeclaration(Namespace.getNamespace("p", "http://other"));
        List<Namespace> result = element.getNamespacesInScope();
        Namespace p = find(result, "p");
        assertNotNull(p);
        assertEquals("http://self", p.getURI());
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void s2_addedDeclarationVersusAttribute() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://p"));
        element.addNamespaceDeclaration(Namespace.getNamespace("q", "http://q-add"));
        element.setAttribute(new Attribute("a", "v", Namespace.getNamespace("q", "http://q-att")));
        List<Namespace> result = element.getNamespacesInScope();
        Namespace q = find(result, "q");
        assertNotNull(q);
        assertEquals("http://q-add", q.getURI());
        assertFalse(result.contains(Namespace.getNamespace("q", "http://q-att")));
    }

    @Test
    public void s3_reservedXmlNamespace() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://p"));
        List<Namespace> result = element.getNamespacesInScope();
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        Namespace xml = find(result, "xml");
        assertNotNull(xml);
        assertEquals(Namespace.XML_NAMESPACE.getURI(), xml.getURI());
    }

    @Test
    public void s4_childShadowsParent() {
        Element parent = new Element("parent", Namespace.getNamespace("x", "http://parent"));
        Element child = new Element("child", Namespace.getNamespace("x", "http://child"));
        parent.addContent(child);
        List<Namespace> result = child.getNamespacesInScope();
        Namespace x = find(result, "x");
        assertNotNull(x);
        assertEquals("http://child", x.getURI());
        assertFalse(result.contains(Namespace.getNamespace("x", "http://parent")));
    }

    @Test
    public void s5_parentNamespaceInheritance() {
        Element parent = new Element("parent", Namespace.getNamespace("a", "http://a"));
        Element child = new Element("child", Namespace.getNamespace("b", "http://b"));
        parent.addContent(child);
        List<Namespace> result = child.getNamespacesInScope();
        Namespace a = find(result, "a");
        Namespace b = find(result, "b");
        assertNotNull(a);
        assertEquals("http://a", a.getURI());
        assertNotNull(b);
        assertEquals("http://b", b.getURI());
    }

    @Test
    public void s6_rootDefaultNamespace() {
        Element root = new Element("root");
        List<Namespace> result = root.getNamespacesInScope();
        assertEquals(3, result.size());
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
    }
}