import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ElementGetNamespacesInScopeTest {

    private static Namespace find(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return ns;
            }
        }
        return null;
    }

    @Test
    public void s1_elementVersusAddedDeclaration() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://self"));
        element.addNamespaceDeclaration(Namespace.getNamespace("q", "http://q"));
        List<Namespace> result = element.getNamespacesInScope();
        assertEquals("http://self", find(result, "p").getURI());
        assertEquals("http://q", find(result, "q").getURI());
    }

    @Test
    public void s2_addedDeclarationVersusAttribute() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://p"));
        element.addNamespaceDeclaration(Namespace.getNamespace("q", "http://q-add"));
        element.setAttribute(new Attribute("a", "v", Namespace.getNamespace("r", "http://r-att")));
        List<Namespace> result = element.getNamespacesInScope();
        assertEquals("http://q-add", find(result, "q").getURI());
        assertEquals("http://r-att", find(result, "r").getURI());
    }

    @Test
    public void s3_reservedXmlNamespace() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertEquals(Namespace.XML_NAMESPACE, find(result, "xml"));
    }

    @Test
    public void s4_childShadowsParent() {
        Element parent = new Element("parent", Namespace.getNamespace("x", "http://parent"));
        Element child = new Element("child", Namespace.getNamespace("x", "http://child"));
        parent.addContent(child);
        List<Namespace> result = child.getNamespacesInScope();
        assertEquals("http://child", find(result, "x").getURI());
        assertFalse(result.contains(Namespace.getNamespace("x", "http://parent")));
    }

    @Test
    public void s5_parentNamespaceInheritance() {
        Element parent = new Element("parent", Namespace.getNamespace("a", "http://a"));
        Element child = new Element("child", Namespace.getNamespace("b", "http://b"));
        parent.addContent(child);
        List<Namespace> result = child.getNamespacesInScope();
        assertNotNull(find(result, "a"));
        assertEquals(child.getNamespace(), result.get(0));
    }

    @Test
    public void s6_rootDefaultNamespace() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();
        assertEquals(3, result.size());
        assertEquals(Namespace.NO_NAMESPACE, result.get(0));
        assertTrue(result.contains(Namespace.XML_NAMESPACE));
    }
}