package org.apache.commons.codec.language;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.apache.commons.codec.EncoderException;
import org.junit.Before;
import org.junit.Test;

public class ColognePhoneticTest {

    private ColognePhonetic colognePhonetic;

    @Before
    public void setUp() {
        colognePhonetic = new ColognePhonetic();
    }

    @Test
    public void test_null_input_returns_null() {
        assertNull(colognePhonetic.colognePhonetic(null));
    }

    @Test
    public void test_empty_string_returns_empty() {
        assertEquals("", colognePhonetic.colognePhonetic(""));
    }

    @Test
    public void test_non_alphabetic_only_returns_empty() {
        assertEquals("", colognePhonetic.colognePhonetic("123!@#   "));
    }

    @Test
    public void test_document_example_muller_ludenscheidt() {
        assertEquals("65752682", colognePhonetic.colognePhonetic("Müller-Lüdenscheidt"));
    }

    @Test
    public void test_umlaut_preprocessing_equivalence() {
        assertEquals(colognePhonetic.colognePhonetic("Mueller"), colognePhonetic.colognePhonetic("Müller"));
        assertEquals(colognePhonetic.colognePhonetic("A"), colognePhonetic.colognePhonetic("Ä"));
        assertEquals(colognePhonetic.colognePhonetic("O"), colognePhonetic.colognePhonetic("Ö"));
        assertEquals(colognePhonetic.colognePhonetic("U"), colognePhonetic.colognePhonetic("Ü"));
        assertEquals(colognePhonetic.colognePhonetic("SS"), colognePhonetic.colognePhonetic("ß"));
    }

    @Test
    public void test_vowels_encode_to_zero() {
        assertEquals("0", colognePhonetic.colognePhonetic("AEIJOUY"));
    }

    @Test
    public void test_h_ignored_char() {
        assertEquals("", colognePhonetic.colognePhonetic("H"));
    }

    @Test
    public void test_b_and_p_codes() {
        assertEquals("1", colognePhonetic.colognePhonetic("B"));
        assertEquals("1", colognePhonetic.colognePhonetic("P"));
        assertEquals("3", colognePhonetic.colognePhonetic("PH"));
    }

    @Test
    public void test_d_and_t_codes() {
        assertEquals("2", colognePhonetic.colognePhonetic("D"));
        assertEquals("2", colognePhonetic.colognePhonetic("T"));
        assertEquals("8", colognePhonetic.colognePhonetic("DC"));
        assertEquals("8", colognePhonetic.colognePhonetic("TS"));
        assertEquals("8", colognePhonetic.colognePhonetic("TZ"));
    }

    @Test
    public void test_fpv_w_codes() {
        assertEquals("3", colognePhonetic.colognePhonetic("FVW"));
    }

    @Test
    public void test_gkq_codes() {
        assertEquals("4", colognePhonetic.colognePhonetic("GKQ"));
    }

    @Test
    public void test_x_not_after_ckq_codes_48() {
        assertEquals("48", colognePhonetic.colognePhonetic("X"));
        assertEquals("048", colognePhonetic.colognePhonetic("AX"));
    }

    @Test
    public void test_x_after_ckq_codes_8() {
        assertEquals("8", colognePhonetic.colognePhonetic("CX"));
        assertEquals("48", colognePhonetic.colognePhonetic("KX"));
        assertEquals("48", colognePhonetic.colognePhonetic("QX"));
    }

    @Test
    public void test_s_and_z_codes() {
        assertEquals("8", colognePhonetic.colognePhonetic("SZ"));
    }

    @Test
    public void test_c_at_onset_before_ahkloqrux_codes_4() {
        assertEquals("40", colognePhonetic.colognePhonetic("CA"));
        assertEquals("4", colognePhonetic.colognePhonetic("CH"));
        assertEquals("4", colognePhonetic.colognePhonetic("CK"));
        assertEquals("45", colognePhonetic.colognePhonetic("CL"));
        assertEquals("40", colognePhonetic.colognePhonetic("CO"));
        assertEquals("4", colognePhonetic.colognePhonetic("CQ"));
        assertEquals("47", colognePhonetic.colognePhonetic("CR"));
        assertEquals("40", colognePhonetic.colognePhonetic("CU"));
        assertEquals("48", colognePhonetic.colognePhonetic("CX"));
    }

    @Test
    public void test_c_at_onset_before_other_codes_8() {
        assertEquals("8", colognePhonetic.colognePhonetic("CE"));
        assertEquals("8", colognePhonetic.colognePhonetic("CI"));
    }

    @Test
    public void test_c_after_sz_codes_8() {
        assertEquals("8", colognePhonetic.colognePhonetic("SC"));
        assertEquals("8", colognePhonetic.colognePhonetic("ZC"));
    }

    @Test
    public void test_c_middle_before_ahkoqux_codes_4() {
        assertEquals("04", colognePhonetic.colognePhonetic("ACH"));
        assertEquals("048", colognePhonetic.colognePhonetic("ACX"));
    }

    @Test
    public void test_c_middle_before_other_codes_8() {
        assertEquals("08", colognePhonetic.colognePhonetic("ACE"));
    }

    @Test
    public void test_r_l_m_n_codes() {
        assertEquals("7", colognePhonetic.colognePhonetic("R"));
        assertEquals("5", colognePhonetic.colognePhonetic("L"));
        assertEquals("6", colognePhonetic.colognePhonetic("M"));
        assertEquals("6", colognePhonetic.colognePhonetic("N"));
    }

    @Test
    public void test_consecutive_code_collapse() {
        assertEquals("0", colognePhonetic.colognePhonetic("AA"));
        assertEquals("1", colognePhonetic.colognePhonetic("BB"));
    }

    @Test
    public void test_zero_only_kept_at_first_position() {
        assertEquals("11", colognePhonetic.colognePhonetic("BAB"));
    }

    @Test
    public void test_zero_after_removal_can_duplicate() {
        assertEquals("11", colognePhonetic.colognePhonetic("BAB"));
    }

    @Test
    public void test_encode_string_delegates_to_cologne_phonetic() {
        String text = "Müller-Lüdenscheidt";
        assertEquals(colognePhonetic.colognePhonetic(text), colognePhonetic.encode(text));
        assertEquals("65752682", colognePhonetic.encode(text));
    }

    @Test
    public void test_encode_object_with_string_returns_encoding() throws EncoderException {
        Object object = "Müller";
        assertEquals(colognePhonetic.colognePhonetic("Müller"), colognePhonetic.encode(object));
    }

    @Test
    public void test_encode_object_with_non_string_throws_encoder_exception() {
        try {
            colognePhonetic.encode(Integer.valueOf(42));
            fail("Expected EncoderException to be thrown");
        } catch (EncoderException expected) {
            assertTrue(expected.getMessage() != null);
        }
    }

    @Test
    public void test_is_encode_equal_true_for_equivalent_encodings() {
        assertTrue(colognePhonetic.isEncodeEqual("Müller", "Mueller"));
    }

    @Test
    public void test_is_encode_equal_false_for_different_encodings() {
        assertFalse(colognePhonetic.isEncodeEqual("Müller", "Schmidt"));
    }

    @Test
    public void test_lowercase_input_uppercased() {
        assertEquals(colognePhonetic.colognePhonetic("MULLER"), colognePhonetic.colognePhonetic("muller"));
    }

    @Test
    public void test_single_letter_boundary() {
        assertEquals("1", colognePhonetic.colognePhonetic("P"));
    }

    @Test
    public void test_hyphen_and_special_chars_ignored() {
        assertEquals(colognePhonetic.colognePhonetic("Müller"), colognePhonetic.colognePhonetic("Mül-ler"));
    }
}
