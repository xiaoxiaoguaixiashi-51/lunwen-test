package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;

import org.junit.Test;

/**
 * Tests for {@link CSVPrinter#printComment(String)}.
 *
 * <p>Uses real {@link CSVFormat} instances and lightweight fake {@link Appendable}
 * implementations instead of Mockito, so the tests are self-contained.</p>
 */
public class CSVPrinterPrintCommentTest {

    private static final char COMMENT_MARKER = '#';

    private static final String CRLF = "\r\n";

    private static final String LF = "\n";

    private static final String CR = "\r";

    private static final String SP = " ";

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private static CSVFormat defaultWithComment() {
        return CSVFormat.DEFAULT.withCommentMarker(COMMENT_MARKER);
    }

    private static CSVFormat defaultNoComment() {
        return CSVFormat.DEFAULT;
    }

    private static CSVFormat customRecordSeparator() {
        return CSVFormat.DEFAULT.withCommentMarker(COMMENT_MARKER).withRecordSeparator(LF);
    }

    private static CSVPrinter newPrinter(final Appendable appendable, final CSVFormat format) throws IOException {
        return new CSVPrinter(appendable, format);
    }

    private static int countOccurrences(final String haystack, final String needle) {
        if (needle.isEmpty()) {
            return 0;
        }
        int count = 0;
        int idx = 0;
        while ((idx = haystack.indexOf(needle, idx)) >= 0) {
            count++;
            idx += needle.length();
        }
        return count;
    }

    /**
     * A lightweight fake {@link Appendable} that records every append call and can be
     * configured to throw an {@link IOException} on a specific call index.
     */
    private static final class RecordingAppendable implements Appendable {

        private final StringBuilder content = new StringBuilder();

        private final StringBuilder calls = new StringBuilder();

        private int appendCount;

        private int throwOnAppendIndex = -1;

        private String throwMessage = "boom";

        void throwOnAppend(final int index, final String message) {
            this.throwOnAppendIndex = index;
            this.throwMessage = message;
        }

        int getAppendCount() {
            return appendCount;
        }

        String getContent() {
            return content.toString();
        }

        String getCalls() {
            return calls.toString();
        }

        private void beforeAppend() throws IOException {
            final int current = appendCount;
            appendCount++;
            if (throwOnAppendIndex >= 0 && current == throwOnAppendIndex) {
                throw new IOException(throwMessage);
            }
        }

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            beforeAppend();
            calls.append("CS:").append(csq).append('|');
            content.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            beforeAppend();
            final CharSequence sub = csq.subSequence(start, end);
            calls.append("CSS:").append(sub).append('|');
            content.append(sub);
            return this;
        }

        @Override
        public Appendable append(final char c) throws IOException {
            beforeAppend();
            calls.append("C:").append(c).append('|');
            content.append(c);
            return this;
        }
    }

    // ------------------------------------------------------------------
    // Tests
    // ------------------------------------------------------------------

    @Test
    public void test_printComment_commentMarkerNotSet_returnsSilently() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultNoComment());

        printer.printComment("hello");

        assertEquals(0, appendable.getAppendCount());
        assertEquals("", appendable.getContent());
    }

    @Test
    public void test_printComment_nullComment_returnsSilently() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment(null);

        assertEquals(0, appendable.getAppendCount());
        assertEquals("", appendable.getContent());
    }

    @Test
    public void test_printComment_singleLine_newRecordTrue_writesMarkerSpaceAndRecordSeparator() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("hello");

        final String expected = "# hello" + CRLF;
        assertEquals(expected, appendable.getContent());
        assertEquals(1, countOccurrences(appendable.getContent(), CRLF));

        final String calls = appendable.getCalls();
        assertEquals(1, countOccurrences(calls, "C:#|"));
        assertEquals(1, countOccurrences(calls, "C: |"));
        assertEquals(1, countOccurrences(calls, "C:h|"));
        assertEquals(1, countOccurrences(calls, "C:e|"));
        assertEquals(1, countOccurrences(calls, "C:l|"));
        assertEquals(1, countOccurrences(calls, "C:o|"));
        // record separator written exactly once via format.println
        assertEquals(1, countOccurrences(calls, "CS:" + CRLF + "|"));
    }

    @Test
    public void test_printComment_newRecordFalse_printsNewlineBeforeComment() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.print("x");
        printer.printComment("hi");

        final String content = appendable.getContent();
        assertTrue(content.endsWith("x" + CRLF + "# hi" + CRLF));
        assertEquals(2, countOccurrences(content, CRLF));
    }

    @Test
    public void test_printComment_commentWithLF_rewritesMarkerOnEachLine() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("line1\nline2");

        final String expected = "# line1" + CRLF + "# line2" + CRLF;
        assertEquals(expected, appendable.getContent());
        assertEquals(2, countOccurrences(appendable.getContent(), CRLF));

        final String calls = appendable.getCalls();
        assertEquals(2, countOccurrences(calls, "C:#|"));
        assertEquals(2, countOccurrences(calls, "C: |"));
    }

    @Test
    public void test_printComment_commentWithCRLF_skipsLFAfterCR() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("line1\r\nline2");

        final String expected = "# line1" + CRLF + "# line2" + CRLF;
        assertEquals(expected, appendable.getContent());
        assertEquals(2, countOccurrences(appendable.getContent(), CRLF));
        assertFalse(appendable.getContent().contains(CRLF + CRLF));

        final String calls = appendable.getCalls();
        assertEquals(2, countOccurrences(calls, "C:#|"));
    }

    @Test
    public void test_printComment_commentWithStandaloneCR_treatedAsLineBreak() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("line1\rline2");

        final String expected = "# line1" + CRLF + "# line2" + CRLF;
        assertEquals(expected, appendable.getContent());
        assertEquals(2, countOccurrences(appendable.getContent(), CRLF));

        final String calls = appendable.getCalls();
        assertEquals(2, countOccurrences(calls, "C:#|"));
        assertEquals(2, countOccurrences(calls, "C: |"));
    }

    @Test
    public void test_printComment_commentEndingWithCR_handlesBoundaryWithoutException() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        try {
            printer.printComment("line1\r");
        } catch (final StringIndexOutOfBoundsException e) {
            fail("Should not throw StringIndexOutOfBoundsException: " + e.getMessage());
        }

        final String expected = "# line1" + CRLF + "# " + CRLF;
        assertEquals(expected, appendable.getContent());
        assertEquals(2, countOccurrences(appendable.getContent(), CRLF));
    }

    @Test
    public void test_printComment_commentEndingWithLF_handlesBoundary() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("line1\n");

        final String expected = "# line1" + CRLF + "# " + CRLF;
        assertEquals(expected, appendable.getContent());
        assertEquals(2, countOccurrences(appendable.getContent(), CRLF));
    }

    @Test
    public void test_printComment_emptyComment_writesMarkerSpaceAndNewline() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("");

        final String expected = "# " + CRLF;
        assertEquals(expected, appendable.getContent());

        final String calls = appendable.getCalls();
        assertEquals(1, countOccurrences(calls, "C:#|"));
        assertEquals(1, countOccurrences(calls, "C: |"));
    }

    @Test
    public void test_printComment_commentWithOnlyNewlines_producesEmptyCommentLines() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("\n\n");

        final String expected = "# " + CRLF + "# " + CRLF + "# " + CRLF;
        assertEquals(expected, appendable.getContent());
        assertEquals(3, countOccurrences(appendable.getContent(), CRLF));

        final String calls = appendable.getCalls();
        assertEquals(3, countOccurrences(calls, "C:#|"));
    }

    @Test
    public void test_printComment_customRecordSeparator_usesFormatSeparator() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, customRecordSeparator());

        printer.printComment("a\nb");

        final String expected = "# a\n# b\n";
        assertEquals(expected, appendable.getContent());
        assertFalse(appendable.getContent().contains(CR));
    }

    @Test
    public void test_printComment_appendableThrowsIOException_propagates() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        appendable.throwOnAppend(0, "boom");
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        try {
            printer.printComment("hello");
            fail("Expected IOException to be thrown");
        } catch (final IOException e) {
            assertEquals("boom", e.getMessage());
        }

        assertTrue(appendable.getAppendCount() >= 1);
    }

    @Test
    public void test_printComment_printlnThrowsIOException_propagates() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        // The first append calls are: '#' (0), ' ' (1), 'h' (2), 'e' (3), 'l' (4), 'l' (5), 'o' (6),
        // then println() writes the record separator as the 8th append (index 7).
        appendable.throwOnAppend(7, "rs-fail");
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        try {
            printer.printComment("hello");
            fail("Expected IOException to be thrown");
        } catch (final IOException e) {
            assertEquals("rs-fail", e.getMessage());
        }
    }

    @Test
    public void test_printComment_verifyAppendCallSequence() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("ab");

        final String calls = appendable.getCalls();
        final String expectedSequence = "C:#|" + "C: |" + "C:a|" + "C:b|" + "CS:" + CRLF + "|";
        assertEquals(expectedSequence, calls);
    }

    @Test
    public void test_printComment_afterPrintComment_newRecordResetToTrue() throws Exception {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = newPrinter(appendable, defaultWithComment());

        printer.printComment("c1");
        final String afterComment = appendable.getContent();
        assertTrue(afterComment.endsWith(CRLF));

        final int lengthBeforePrint = appendable.getContent().length();
        printer.print("v");
        final String afterPrint = appendable.getContent();

        // print("v") must not prepend a record separator because newRecord was reset to true.
        assertEquals(afterComment + "v", afterPrint);
        assertEquals(lengthBeforePrint + 1, afterPrint.length());
        assertNotNull(afterPrint);
    }
}
