import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import static org.junit.Assert.assertEquals;

public class SAXHandlerTest {

    @Test
    public void testFocal() throws Exception {
        SAXHandler handler = new SAXHandler();
        handler.startDocument();
        handler.startPrefixMapping("p", "urn:test:ns");

        
    }
}
