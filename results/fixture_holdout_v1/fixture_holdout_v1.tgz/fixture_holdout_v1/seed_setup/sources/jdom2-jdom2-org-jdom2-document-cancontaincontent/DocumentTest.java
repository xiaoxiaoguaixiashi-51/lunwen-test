package org.jdom2;

import static org.junit.Assert.fail;

import org.junit.Test;

public class DocumentTest {

    @Test
    public void testFocal() {
        Document doc = new Document(new Element("root"));
        Element candidate = new Element("second");

        
    }
}
