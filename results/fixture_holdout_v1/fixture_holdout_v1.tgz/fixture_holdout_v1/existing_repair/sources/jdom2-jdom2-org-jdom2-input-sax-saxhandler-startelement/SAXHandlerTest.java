package org.jdom2.input.sax;

import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;
import org.jdom2.input.sax.SAXHandler;

import static org.junit.Assert.assertEquals;

public class SAXHandlerTest {

    @Test
    public void testFocal() throws Exception {
        SAXHandler handler = new SAXHandler();
        handler.startDocument();
        handler.startPrefixMapping("p", "urn:test:ns");

        // KCF_FOCAL
        handler.startElement("urn:test:ns", "root", "p:root", new AttributesImpl());

        assertEquals("root", handler.getCurrentElement().getName());
        assertEquals("urn:test:ns", handler.getCurrentElement().getNamespaceURI());
    }
}
