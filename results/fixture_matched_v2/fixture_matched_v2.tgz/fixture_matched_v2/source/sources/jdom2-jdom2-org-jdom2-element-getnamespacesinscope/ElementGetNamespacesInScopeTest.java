import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ElementGetNamespacesInScopeTest {

    private static final String XML_PREFIX = "xml";
    private static final String XML_URI = "http://www.w3.org/XML/1998/namespace";

    @Before
    public void setUp() {
        // No shared mutable state; each test builds its own fixtures.
    }

    private static Namespace findNamespaceByPrefix(List<Namespace> list, String prefix) {
        for (Namespace ns : list) {
            if (prefix.equals(ns.getPrefix())) {
                return ns;
            }
        }
        return null;
    }

    private static boolean containsUri(List<Namespace> list, String uri) {
        for (Namespace ns : list) {
            if (uri.equals(ns.getURI())) {
                return true;
            }
        }
        return false;
    }

    private static boolean containsNamespace(List<Namespace> list, Namespace target) {
        for (Namespace ns : list) {
            if (ns.equals(target)) {
                return true;
            }
        }
        return false;
    }

    @Test
    public void test_rootElement_defaultNamespace_noAdditional_noAttributes() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals(Namespace.XML_NAMESPACE, result.get(2));
    }

    @Test
    public void test_rootElement_nonDefaultNamespace_noDefaultCompletion() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("root", p);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertTrue(containsNamespace(result, p));
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_rootElement_withDefaultNamespace_noDuplicateNoNamespace() {
        Namespace def = Namespace.getNamespace("", "http://default");
        Element element = new Element("root", def);
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(2, result.size());
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals(Namespace.XML_NAMESPACE, result.get(1));
        assertFalse(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_currentNamespace_priority_over_additionalNamespaces() {
        Namespace self = Namespace.getNamespace("p", "http://self");
        Element element = new Element("e", self);
        // Note: addNamespaceDeclaration with same prefix but different URI would
        // be rejected by Verifier.checkNamespaceCollision. So we exercise the
        // priority via a legal scenario: additional namespace with a distinct
        // prefix, and verify the element's own namespace is first and present.
        Namespace other = Namespace.getNamespace("o", "http://other");
        element.addNamespaceDeclaration(other);

        List<Namespace> result = element.getNamespacesInScope();

        Namespace pNs = findNamespaceByPrefix(result, "p");
        assertNotNull(pNs);
        assertEquals("http://self", pNs.getURI());
        assertEquals(element.getNamespace(), result.get(0));
        assertFalse(containsUri(result, "http://other") && findNamespaceByPrefix(result, "p") != null
                && "http://other".equals(findNamespaceByPrefix(result, "p").getURI()));
        assertTrue(containsNamespace(result, other));
    }

    @Test
    public void test_additionalNamespaces_priority_over_attributes() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        Namespace qAdd = Namespace.getNamespace("q", "http://q-add");
        element.addNamespaceDeclaration(qAdd);
        // Attribute with a different prefix to avoid collision rejection.
        Namespace qAtt = Namespace.getNamespace("qa", "http://q-att");
        element.setAttribute(new Attribute("a", "v", qAtt));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace q = findNamespaceByPrefix(result, "q");
        assertNotNull(q);
        assertEquals("http://q-add", q.getURI());
        assertFalse(containsUri(result, "http://q-att") && findNamespaceByPrefix(result, "q") != null
                && "http://q-att".equals(findNamespaceByPrefix(result, "q").getURI()));
        assertTrue(containsNamespace(result, qAtt));
    }

    @Test
    public void test_attributes_namespace_added_when_not_conflicting() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        Namespace r = Namespace.getNamespace("r", "http://r");
        element.setAttribute(new Attribute("a", "v", r));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace found = findNamespaceByPrefix(result, "r");
        assertNotNull(found);
        assertEquals("http://r", found.getURI());
    }

    @Test
    public void test_inheritParentNamespaces() {
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Element parent = new Element("parent", a);
        Element child = new Element("child", b);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertTrue(containsNamespace(result, a));
        assertTrue(containsNamespace(result, b));
        assertEquals(child.getNamespace(), result.get(0));
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
    }

    @Test
    public void test_childNamespace_priority_over_parentNamespace() {
        Namespace parentNs = Namespace.getNamespace("x", "http://parent");
        Namespace childNs = Namespace.getNamespace("x", "http://child");
        Element parent = new Element("parent", parentNs);
        Element child = new Element("child", childNs);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace x = findNamespaceByPrefix(result, "x");
        assertNotNull(x);
        assertEquals("http://child", x.getURI());
        assertFalse(containsUri(result, "http://parent"));
    }

    @Test
    public void test_nonRootElement_noDefaultNamespaceCompletion() {
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Element parent = new Element("parent", a);
        Element child = new Element("child", b);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertFalse(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertFalse(findNamespaceByPrefix(result, "") != null);
    }

    @Test
    public void test_multiLevelInheritance() {
        Namespace g = Namespace.getNamespace("g", "http://g");
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace c = Namespace.getNamespace("c", "http://c");
        Element grandparent = new Element("gp", g);
        Element parent = new Element("p", p);
        Element child = new Element("c", c);
        grandparent.addContent(parent);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertTrue(containsNamespace(result, g));
        assertTrue(containsNamespace(result, p));
        assertTrue(containsNamespace(result, c));
        assertEquals(child.getNamespace(), result.get(0));
    }

    @Test
    public void test_returnedList_isUnmodifiable() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        try {
            result.add(Namespace.getNamespace("z", "http://z"));
            fail("Expected UnsupportedOperationException on add");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.remove(0);
            fail("Expected UnsupportedOperationException on remove");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            result.clear();
            fail("Expected UnsupportedOperationException on clear");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_nullAdditionalNamespacesAndAttributes_noNPE() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertNotNull(result);
        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_emptyAdditionalNamespacesAndAttributes() {
        Element element = new Element("root");
        // Add then remove a namespace declaration to exercise the non-null
        // additionalNamespaces list path with an empty collection.
        Namespace temp = Namespace.getNamespace("t", "http://t");
        element.addNamespaceDeclaration(temp);
        element.removeNamespaceDeclaration(temp);

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_xmlNamespacePrefixConflict_selfWins() {
        // Namespace.getNamespace("xml", customUri) is rejected by JDOM's
        // validation, so we cannot construct a conflicting 'xml' prefix.
        // Instead, verify that the XML_NAMESPACE is always present and that
        // the element's own namespace (with a non-xml prefix) is first.
        Namespace custom = Namespace.getNamespace("cx", "http://custom-xml");
        Element element = new Element("e", custom);

        List<Namespace> result = element.getNamespacesInScope();

        Namespace xmlNs = findNamespaceByPrefix(result, XML_PREFIX);
        assertNotNull(xmlNs);
        assertEquals(XML_URI, xmlNs.getURI());
        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("cx", result.get(0).getPrefix());
    }

    @Test
    public void test_parentRecursion_viaRealParent() {
        // Real parent/child structure exercising the recursive merge path.
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace cParent = Namespace.getNamespace("c", "http://parent-c");
        Namespace cChild = Namespace.getNamespace("c", "http://c");

        Element parent = new Element("parent", a);
        parent.addNamespaceDeclaration(cParent);
        Element child = new Element("child", cChild);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertTrue(containsNamespace(result, a));
        Namespace c = findNamespaceByPrefix(result, "c");
        assertNotNull(c);
        assertEquals("http://c", c.getURI());
        assertFalse(containsUri(result, "http://parent-c"));
    }

    @Test
    public void test_additionalNamespaces_priority_over_parent() {
        // Child declares 'p' via additional namespace; parent declares 'p'
        // with a different URI. Child's additional namespace should win.
        Namespace pChild = Namespace.getNamespace("p", "http://child-p");
        Namespace pParent = Namespace.getNamespace("p", "http://parent-p");
        Namespace childOwn = Namespace.getNamespace("c", "http://c");

        Element parent = new Element("parent", pParent);
        Element child = new Element("child", childOwn);
        child.addNamespaceDeclaration(pChild);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace p = findNamespaceByPrefix(result, "p");
        assertNotNull(p);
        assertEquals("http://child-p", p.getURI());
        assertFalse(containsUri(result, "http://parent-p"));
    }

    @Test
    public void test_attributes_namespace_priority_over_parent() {
        // Child has an attribute namespace 'r'; parent declares 'r' with a
        // different URI. Child's attribute namespace should win.
        Namespace rChild = Namespace.getNamespace("r", "http://child-r");
        Namespace rParent = Namespace.getNamespace("r", "http://parent-r");
        Namespace childOwn = Namespace.getNamespace("c", "http://c");

        Element parent = new Element("parent", rParent);
        Element child = new Element("child", childOwn);
        child.setAttribute(new Attribute("a", "v", rChild));
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace r = findNamespaceByPrefix(result, "r");
        assertNotNull(r);
        assertEquals("http://child-r", r.getURI());
        assertFalse(containsUri(result, "http://parent-r"));
    }

    @Test
    public void test_resultOrder_currentNamespaceFirst_thenTreeMapOrder() {
        Namespace m = Namespace.getNamespace("m", "http://m");
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace z = Namespace.getNamespace("z", "http://z");
        Element element = new Element("e", m);
        element.addNamespaceDeclaration(a);
        element.addNamespaceDeclaration(z);

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals("a", result.get(2).getPrefix());
        assertEquals("m", result.get(3).getPrefix());
        assertEquals("xml", result.get(4).getPrefix());
        assertEquals("z", result.get(5).getPrefix());
    }

    @Test
    public void test_multipleAdditionalNamespaces_allIncluded() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Namespace c = Namespace.getNamespace("c", "http://c");
        element.addNamespaceDeclaration(a);
        element.addNamespaceDeclaration(b);
        element.addNamespaceDeclaration(c);

        List<Namespace> result = element.getNamespacesInScope();

        assertTrue(containsNamespace(result, a));
        assertTrue(containsNamespace(result, b));
        assertTrue(containsNamespace(result, c));
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_multipleAttributes_namespaces_allIncluded() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        Namespace r = Namespace.getNamespace("r", "http://r");
        Namespace s = Namespace.getNamespace("s", "http://s");
        element.setAttribute(new Attribute("a", "v", r));
        element.setAttribute(new Attribute("b", "v", s));

        List<Namespace> result = element.getNamespacesInScope();

        assertTrue(containsNamespace(result, r));
        assertTrue(containsNamespace(result, s));
    }

    @Test
    public void test_rootElement_withAdditionalNamespace_noDefaultCompletion() {
        // Root element with a non-default namespace and an additional
        // namespace; NO_NAMESPACE should still be added since prefix "" is
        // absent.
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace q = Namespace.getNamespace("q", "http://q");
        Element element = new Element("root", p);
        element.addNamespaceDeclaration(q);

        List<Namespace> result = element.getNamespacesInScope();

        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertTrue(containsNamespace(result, p));
        assertTrue(containsNamespace(result, q));
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_detachedChild_afterRemoval_noParentInheritance() {
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Element parent = new Element("parent", a);
        Element child = new Element("child", b);
        parent.addContent(child);
        child.detach();

        List<Namespace> result = child.getNamespacesInScope();

        assertFalse(containsNamespace(result, a));
        assertTrue(containsNamespace(result, b));
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_duplicateAdditionalNamespace_notDuplicated() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        Namespace q = Namespace.getNamespace("q", "http://q");
        element.addNamespaceDeclaration(q);
        // Adding the same namespace again should be a no-op (or at least not
        // produce duplicates in the result).
        element.addNamespaceDeclaration(q);

        List<Namespace> result = element.getNamespacesInScope();

        int qCount = 0;
        for (Namespace ns : result) {
            if ("q".equals(ns.getPrefix())) {
                qCount++;
            }
        }
        assertEquals(1, qCount);
    }

    @Test
    public void test_returnsNewListEachCall() {
        Element element = new Element("root");
        List<Namespace> first = element.getNamespacesInScope();
        List<Namespace> second = element.getNamespacesInScope();

        assertNotNull(first);
        assertNotNull(second);
        assertEquals(first.size(), second.size());
        assertEquals(first, second);
        assertTrue(first != second);
    }

    @Test
    public void test_parentWithDefaultNamespace_childInheritsDefault() {
        Namespace def = Namespace.getNamespace("", "http://default");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Element parent = new Element("parent", def);
        Element child = new Element("child", b);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace inherited = findNamespaceByPrefix(result, "");
        assertNotNull(inherited);
        assertEquals("http://default", inherited.getURI());
        assertFalse(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_attributeWithNoNamespace_ignored() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        element.setAttribute(new Attribute("a", "v"));

        List<Namespace> result = element.getNamespacesInScope();

        // The attribute has no namespace; it should not add a new entry.
        assertEquals(3, result.size());
        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertTrue(containsNamespace(result, Namespace.XML_NAMESPACE));
        assertTrue(containsNamespace(result, p));
    }

    @Test
    public void test_resultContainsNoDuplicatePrefixes() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace a = Namespace.getNamespace("a", "http://a");
        Element element = new Element("e", p);
        element.addNamespaceDeclaration(a);
        element.setAttribute(new Attribute("x", "v", Namespace.getNamespace("b", "http://b")));

        List<Namespace> result = element.getNamespacesInScope();

        List<String> prefixes = new ArrayList<String>();
        for (Namespace ns : result) {
            assertFalse("Duplicate prefix: " + ns.getPrefix(), prefixes.contains(ns.getPrefix()));
            prefixes.add(ns.getPrefix());
        }
    }

    @Test
    public void test_parentChainWithSamePrefix_childWins() {
        Namespace xParent = Namespace.getNamespace("x", "http://parent");
        Namespace xChild = Namespace.getNamespace("x", "http://child");
        Namespace y = Namespace.getNamespace("y", "http://y");

        Element grandparent = new Element("gp", xParent);
        Element parent = new Element("p", y);
        Element child = new Element("c", xChild);
        grandparent.addContent(parent);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace x = findNamespaceByPrefix(result, "x");
        assertNotNull(x);
        assertEquals("http://child", x.getURI());
        assertFalse(containsUri(result, "http://parent"));
        assertTrue(containsNamespace(result, y));
    }

    @Test
    public void test_rootElementWithAttributeNamespace_noDefaultCompletion() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace r = Namespace.getNamespace("r", "http://r");
        Element element = new Element("root", p);
        element.setAttribute(new Attribute("a", "v", r));

        List<Namespace> result = element.getNamespacesInScope();

        assertTrue(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertTrue(containsNamespace(result, r));
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_unmodifiableList_containsAllExpectedNamespaces() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        List<Namespace> result = element.getNamespacesInScope();

        assertTrue(result.contains(Namespace.XML_NAMESPACE));
        assertTrue(result.contains(Namespace.NO_NAMESPACE));
        assertTrue(result.contains(p));
        assertEquals(3, result.size());
    }

    @Test
    public void test_deepInheritance_allAncestorNamespacesMerged() {
        Namespace g = Namespace.getNamespace("g", "http://g");
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace c = Namespace.getNamespace("c", "http://c");
        Namespace d = Namespace.getNamespace("d", "http://d");

        Element level1 = new Element("l1", g);
        Element level2 = new Element("l2", p);
        Element level3 = new Element("l3", c);
        Element level4 = new Element("l4", d);
        level1.addContent(level2);
        level2.addContent(level3);
        level3.addContent(level4);

        List<Namespace> result = level4.getNamespacesInScope();

        assertTrue(containsNamespace(result, g));
        assertTrue(containsNamespace(result, p));
        assertTrue(containsNamespace(result, c));
        assertTrue(containsNamespace(result, d));
        assertEquals(level4.getNamespace(), result.get(0));
    }

    @Test
    public void test_additionalNamespaceWithDefaultPrefix_onRoot() {
        // Root element with non-default namespace plus an additional
        // namespace that uses the default prefix. The additional default
        // namespace should be included and NO_NAMESPACE should not be added.
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace def = Namespace.getNamespace("", "http://default");
        Element element = new Element("root", p);
        element.addNamespaceDeclaration(def);

        List<Namespace> result = element.getNamespacesInScope();

        Namespace found = findNamespaceByPrefix(result, "");
        assertNotNull(found);
        assertEquals("http://default", found.getURI());
        assertFalse(containsNamespace(result, Namespace.NO_NAMESPACE));
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_attributeNamespaceWithDefaultPrefix_onRoot() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace def = Namespace.getNamespace("", "http://default");
        Element element = new Element("root", p);
        element.setAttribute(new Attribute("a", "v", def));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace found = findNamespaceByPrefix(result, "");
        assertNotNull(found);
        assertEquals("http://default", found.getURI());
        assertFalse(containsNamespace(result, Namespace.NO_NAMESPACE));
    }

    @Test
    public void test_parentDefaultNamespace_doesNotOverrideChildDefault() {
        Namespace parentDef = Namespace.getNamespace("", "http://parent-default");
        Namespace childDef = Namespace.getNamespace("", "http://child-default");
        Element parent = new Element("parent", parentDef);
        Element child = new Element("child", childDef);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        Namespace def = findNamespaceByPrefix(result, "");
        assertNotNull(def);
        assertEquals("http://child-default", def.getURI());
        assertFalse(containsUri(result, "http://parent-default"));
    }

    @Test
    public void test_resultSize_matchesUniquePrefixCount() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Element element = new Element("e", p);
        element.addNamespaceDeclaration(a);
        element.addNamespaceDeclaration(b);
        element.setAttribute(new Attribute("x", "v", Namespace.getNamespace("r", "http://r")));

        List<Namespace> result = element.getNamespacesInScope();

        // prefixes: p (self), a, b, r, xml, "" (NO_NAMESPACE) => 6
        assertEquals(6, result.size());
    }

    @Test
    public void test_firstElementIsAlwaysElementNamespace() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        element.addNamespaceDeclaration(Namespace.getNamespace("a", "http://a"));

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("p", result.get(0).getPrefix());
        assertEquals("http://p", result.get(0).getURI());
    }

    @Test
    public void test_noNamespaceElement_firstElementIsNoNamespace() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(Namespace.NO_NAMESPACE, result.get(0));
        assertEquals("", result.get(0).getPrefix());
    }

    @Test
    public void test_parentWithAdditionalNamespaces_inherited() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace parentAdd = Namespace.getNamespace("pa", "http://pa");
        Namespace childNs = Namespace.getNamespace("c", "http://c");

        Element parent = new Element("parent", p);
        parent.addNamespaceDeclaration(parentAdd);
        Element child = new Element("child", childNs);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertTrue(containsNamespace(result, parentAdd));
        assertTrue(containsNamespace(result, p));
        assertTrue(containsNamespace(result, childNs));
    }

    @Test
    public void test_parentWithAttributeNamespaces_inherited() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace parentAtt = Namespace.getNamespace("pat", "http://pat");
        Namespace childNs = Namespace.getNamespace("c", "http://c");

        Element parent = new Element("parent", p);
        parent.setAttribute(new Attribute("a", "v", parentAtt));
        Element child = new Element("child", childNs);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertTrue(containsNamespace(result, parentAtt));
        assertTrue(containsNamespace(result, childNs));
    }

    @Test
    public void test_removedAdditionalNamespace_notInResult() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace q = Namespace.getNamespace("q", "http://q");
        Element element = new Element("e", p);
        element.addNamespaceDeclaration(q);
        element.removeNamespaceDeclaration(q);

        List<Namespace> result = element.getNamespacesInScope();

        assertFalse(containsNamespace(result, q));
        assertFalse(findNamespaceByPrefix(result, "q") != null);
    }

    @Test
    public void test_removedAttribute_namespaceNotInResult() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace r = Namespace.getNamespace("r", "http://r");
        Element element = new Element("e", p);
        Attribute att = new Attribute("a", "v", r);
        element.setAttribute(att);
        element.removeAttribute(att);

        List<Namespace> result = element.getNamespacesInScope();

        assertFalse(containsNamespace(result, r));
        assertFalse(findNamespaceByPrefix(result, "r") != null);
    }

    @Test
    public void test_resultIsUnmodifiable_afterMultipleCalls() {
        Element element = new Element("root");
        List<Namespace> first = element.getNamespacesInScope();
        List<Namespace> second = element.getNamespacesInScope();

        try {
            first.add(Namespace.getNamespace("z", "http://z"));
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }

        try {
            second.remove(0);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void test_xmlNamespaceAlwaysPresent() {
        Element element = new Element("e", Namespace.getNamespace("p", "http://p"));
        element.addNamespaceDeclaration(Namespace.getNamespace("a", "http://a"));
        element.setAttribute(new Attribute("x", "v", Namespace.getNamespace("r", "http://r")));

        List<Namespace> result = element.getNamespacesInScope();

        Namespace xml = findNamespaceByPrefix(result, XML_PREFIX);
        assertNotNull(xml);
        assertEquals(XML_URI, xml.getURI());
        assertEquals(Namespace.XML_NAMESPACE, xml);
    }

    @Test
    public void test_noNamespaceAlwaysPresentForRoot() {
        Element element = new Element("root");
        List<Namespace> result = element.getNamespacesInScope();

        Namespace def = findNamespaceByPrefix(result, "");
        assertNotNull(def);
        assertEquals(Namespace.NO_NAMESPACE, def);
    }

    @Test
    public void test_childWithDefaultNamespace_noNoNamespace() {
        Namespace parentNs = Namespace.getNamespace("p", "http://p");
        Namespace childDef = Namespace.getNamespace("", "http://child-default");
        Element parent = new Element("parent", parentNs);
        Element child = new Element("child", childDef);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertFalse(containsNamespace(result, Namespace.NO_NAMESPACE));
        Namespace def = findNamespaceByPrefix(result, "");
        assertNotNull(def);
        assertEquals("http://child-default", def.getURI());
    }

    @Test
    public void test_multipleCallsConsistentResults() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Namespace a = Namespace.getNamespace("a", "http://a");
        Element element = new Element("e", p);
        element.addNamespaceDeclaration(a);

        List<Namespace> first = element.getNamespacesInScope();
        List<Namespace> second = element.getNamespacesInScope();
        List<Namespace> third = element.getNamespacesInScope();

        assertEquals(first, second);
        assertEquals(second, third);
        assertEquals(first.size(), third.size());
    }

    @Test
    public void test_attributeNamespaceSameAsElementNamespace_notDuplicated() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        element.setAttribute(new Attribute("a", "v", p));

        List<Namespace> result = element.getNamespacesInScope();

        int pCount = 0;
        for (Namespace ns : result) {
            if ("p".equals(ns.getPrefix())) {
                pCount++;
            }
        }
        assertEquals(1, pCount);
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_additionalNamespaceSameAsElementNamespace_notDuplicated() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element element = new Element("e", p);
        element.addNamespaceDeclaration(p);

        List<Namespace> result = element.getNamespacesInScope();

        int pCount = 0;
        for (Namespace ns : result) {
            if ("p".equals(ns.getPrefix())) {
                pCount++;
            }
        }
        assertEquals(1, pCount);
        assertEquals(element.getNamespace(), result.get(0));
    }

    @Test
    public void test_parentNamespaceSameAsChild_notDuplicated() {
        Namespace p = Namespace.getNamespace("p", "http://p");
        Element parent = new Element("parent", p);
        Element child = new Element("child", p);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        int pCount = 0;
        for (Namespace ns : result) {
            if ("p".equals(ns.getPrefix())) {
                pCount++;
            }
        }
        assertEquals(1, pCount);
        assertEquals(child.getNamespace(), result.get(0));
    }

    @Test
    public void test_resultOrderingWithMultipleAdditionalNamespaces() {
        Namespace m = Namespace.getNamespace("m", "http://m");
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace b = Namespace.getNamespace("b", "http://b");
        Namespace z = Namespace.getNamespace("z", "http://z");
        Element element = new Element("e", m);
        element.addNamespaceDeclaration(z);
        element.addNamespaceDeclaration(a);
        element.addNamespaceDeclaration(b);

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals("a", result.get(2).getPrefix());
        assertEquals("b", result.get(3).getPrefix());
        assertEquals("m", result.get(4).getPrefix());
        assertEquals("xml", result.get(5).getPrefix());
        assertEquals("z", result.get(6).getPrefix());
    }

    @Test
    public void test_resultOrderingWithAttributes() {
        Namespace m = Namespace.getNamespace("m", "http://m");
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace z = Namespace.getNamespace("z", "http://z");
        Element element = new Element("e", m);
        element.setAttribute(new Attribute("x", "v", z));
        element.setAttribute(new Attribute("y", "v", a));

        List<Namespace> result = element.getNamespacesInScope();

        assertEquals(element.getNamespace(), result.get(0));
        assertEquals("", result.get(1).getPrefix());
        assertEquals("a", result.get(2).getPrefix());
        assertEquals("m", result.get(3).getPrefix());
        assertEquals("xml", result.get(4).getPrefix());
        assertEquals("z", result.get(5).getPrefix());
    }

    @Test
    public void test_resultOrderingWithParentInheritance() {
        Namespace m = Namespace.getNamespace("m", "http://m");
        Namespace a = Namespace.getNamespace("a", "http://a");
        Namespace z = Namespace.getNamespace("z", "http://z");
        Element parent = new Element("parent", a);
        Element child = new Element("child", m);
        child.addNamespaceDeclaration(z);
        parent.addContent(child);

        List<Namespace> result = child.getNamespacesInScope();

        assertEquals(child.getNamespace(), result