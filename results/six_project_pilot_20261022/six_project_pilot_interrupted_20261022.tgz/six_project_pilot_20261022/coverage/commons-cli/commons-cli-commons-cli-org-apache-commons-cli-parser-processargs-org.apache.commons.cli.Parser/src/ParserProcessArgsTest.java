package org.apache.commons.cli;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class ParserProcessArgsTest {

    private TestParser parser;

    @Before
    public void setUp() {
        parser = new TestParser();
    }

    private static final class TestParser extends Parser {
        @Override
        protected String[] flatten(final Options opts, final String[] arguments, final boolean stopAtNonOption) {
            return new String[0];
        }
    }

    private static final class StubOptions extends Options {
        private static final long serialVersionUID = 1L;
        private final Map<String, Boolean> hasOptionMap = new HashMap<String, Boolean>();

        void setHasOption(final String token, final boolean result) {
            hasOptionMap.put(token, Boolean.valueOf(result));
        }

        @Override
        public boolean hasOption(final String opt) {
            final Boolean result = hasOptionMap.get(opt);
            return result != null && result.booleanValue();
        }
    }

    private static final class StubOption extends Option {
        private static final long serialVersionUID = 1L;

        private final List<String> addedValues = new ArrayList<String>();
        private String[] values;
        private boolean optionalArg;
        private String throwOnValue;
        private int addValueCalls;
        private int hasOptionalArgCalls;

        StubOption() {
            super("o", false, "test option");
        }

        @Override
        public void addValueForProcessing(final String value) {
            addValueCalls++;
            if (throwOnValue != null && throwOnValue.equals(value)) {
                throw new RuntimeException("boom");
            }
            addedValues.add(value);
        }

        @Override
        public String[] getValues() {
            return values;
        }

        @Override
        public boolean hasOptionalArg() {
            hasOptionalArgCalls++;
            return optionalArg;
        }

        void setValues(final String[] values) {
            this.values = values;
        }

        @Override
        public void setOptionalArg(final boolean optionalArg) {
            this.optionalArg = optionalArg;
        }

        void setThrowOnValue(final String throwOnValue) {
            this.throwOnValue = throwOnValue;
        }

        List<String> getAddedValues() {
            return addedValues;
        }

        int getAddValueCalls() {
            return addValueCalls;
        }

        int getHasOptionalArgCalls() {
            return hasOptionalArgCalls;
        }
    }

    private static ListIterator<String> iteratorOf(final String... tokens) {
        return new ArrayList<String>(Arrays.asList(tokens)).listIterator();
    }

    @Test
    public void test_processArgs_collectsMultipleValuesUntilOption() throws Exception {
        final StubOptions options = new StubOptions();
        options.setHasOption("value1", false);
        options.setHasOption("value2", false);
        options.setHasOption("-o", true);
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(new String[] { "value1", "value2" });

        final ListIterator<String> iter = iteratorOf("value1", "value2", "-o");

        parser.processArgs(opt, iter);

        assertEquals(2, opt.getAddValueCalls());
        assertEquals(Arrays.asList("value1", "value2"), opt.getAddedValues());
        assertEquals("-o", iter.next());
    }

    @Test
    public void test_processArgs_runtimeExceptionOnAddValue_rollsBackAndStops() throws Exception {
        final StubOptions options = new StubOptions();
        options.setHasOption("badValue", false);
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(new String[] { "x" });
        opt.setThrowOnValue("badValue");

        final ListIterator<String> iter = iteratorOf("badValue", "nextValue");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.getAddValueCalls());
        assertTrue(opt.getAddedValues().isEmpty());
        assertEquals("badValue", iter.next());
        assertEquals(0, opt.getHasOptionalArgCalls());
    }

    @Test
    public void test_processArgs_noValuesAndNotOptional_throwsMissingArgumentException() throws Exception {
        final StubOptions options = new StubOptions();
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(null);
        opt.setOptionalArg(false);

        final ListIterator<String> iter = iteratorOf();

        try {
            parser.processArgs(opt, iter);
            fail("Expected MissingArgumentException");
        } catch (final MissingArgumentException e) {
            assertSame(opt, e.getOption());
        }

        assertEquals(0, opt.getAddValueCalls());
    }

    @Test
    public void test_processArgs_noValuesButOptional_doesNotThrow() throws Exception {
        final StubOptions options = new StubOptions();
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(null);
        opt.setOptionalArg(true);

        final ListIterator<String> iter = iteratorOf();

        parser.processArgs(opt, iter);

        assertEquals(0, opt.getAddValueCalls());
        assertEquals(1, opt.getHasOptionalArgCalls());
    }

    @Test
    public void test_processArgs_quotedValueIsStripped() throws Exception {
        final StubOptions options = new StubOptions();
        options.setHasOption("\"quoted\"", false);
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(new String[] { "quoted" });

        final ListIterator<String> iter = iteratorOf("\"quoted\"");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.getAddValueCalls());
        assertEquals(Arrays.asList("quoted"), opt.getAddedValues());
        assertFalse(opt.getAddedValues().contains("\"quoted\""));
    }

    @Test
    public void test_processArgs_tokenStartsWithDashButNotRegisteredOption_treatedAsValue() throws Exception {
        final StubOptions options = new StubOptions();
        options.setHasOption("-unknown", false);
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(new String[] { "-unknown" });

        final ListIterator<String> iter = iteratorOf("-unknown");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.getAddValueCalls());
        assertEquals(Arrays.asList("-unknown"), opt.getAddedValues());
    }

    @Test
    public void test_processArgs_registeredOptionWithoutDashPrefix_treatedAsValue() throws Exception {
        final StubOptions options = new StubOptions();
        options.setHasOption("foo", true);
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(new String[] { "foo" });

        final ListIterator<String> iter = iteratorOf("foo");

        parser.processArgs(opt, iter);

        assertEquals(1, opt.getAddValueCalls());
        assertEquals(Arrays.asList("foo"), opt.getAddedValues());
    }

    @Test
    public void test_processArgs_emptyIteratorWithExistingValues_doesNotThrow() throws Exception {
        final StubOptions options = new StubOptions();
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(new String[] { "existing" });

        final ListIterator<String> iter = iteratorOf();

        parser.processArgs(opt, iter);

        assertEquals(0, opt.getAddValueCalls());
        assertEquals(0, opt.getHasOptionalArgCalls());
    }

    @Test
    public void test_processArgs_mockIterator_verifiesPreviousCallCount() throws Exception {
        final StubOptions options = new StubOptions();
        options.setHasOption("v1", false);
        options.setHasOption("-o", true);
        parser.setOptions(options);

        final StubOption opt = new StubOption();
        opt.setValues(new String[] { "v1" });

        final CountingListIterator iter = new CountingListIterator(Arrays.asList("v1", "-o"));

        parser.processArgs(opt, iter);

        assertEquals(2, iter.getNextCalls());
        assertEquals(1, iter.getPreviousCalls());
        assertEquals(1, opt.getAddValueCalls());
        assertEquals(Arrays.asList("v1"), opt.getAddedValues());
    }

    private static final class CountingListIterator implements ListIterator<String> {
        private final List<String> backing;
        private int cursor;
        private int nextCalls;
        private int previousCalls;

        CountingListIterator(final List<String> backing) {
            this.backing = new ArrayList<String>(backing);
            this.cursor = 0;
        }

        @Override
        public boolean hasNext() {
            return cursor < backing.size();
        }

        @Override
        public String next() {
            nextCalls++;
            final String value = backing.get(cursor);
            cursor++;
            return value;
        }

        @Override
        public boolean hasPrevious() {
            return cursor > 0;
        }

        @Override
        public String previous() {
            previousCalls++;
            cursor--;
            return backing.get(cursor);
        }

        @Override
        public int nextIndex() {
            return cursor;
        }

        @Override
        public int previousIndex() {
            return cursor - 1;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void set(final String e) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void add(final String e) {
            throw new UnsupportedOperationException();
        }

        int getNextCalls() {
            return nextCalls;
        }

        int getPreviousCalls() {
            return previousCalls;
        }
    }
}