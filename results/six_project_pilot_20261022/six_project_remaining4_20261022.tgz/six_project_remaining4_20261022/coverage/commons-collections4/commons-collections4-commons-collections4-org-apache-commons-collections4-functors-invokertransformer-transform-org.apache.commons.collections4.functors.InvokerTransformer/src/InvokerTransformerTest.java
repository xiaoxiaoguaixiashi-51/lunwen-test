package org.apache.commons.collections4.functors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections4.FunctorException;
import org.apache.commons.collections4.Transformer;
import org.junit.Before;
import org.junit.Test;

public class InvokerTransformerTest {

    private String hello;

    @Before
    public void setUp() {
        hello = "hello";
    }

    @Test
    public void test_transform_noArgMethod_returnsResult() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("length", null, null);

        final Object result = transformer.transform(hello);

        assertNotNull(result);
        assertTrue(result instanceof Integer);
        assertEquals(Integer.valueOf(5), result);
    }

    @Test
    public void test_transform_withArgs_returnsResult() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("substring", new Class<?>[]{int.class}, new Object[]{Integer.valueOf(1)});

        final Object result = transformer.transform(hello);

        assertNotNull(result);
        assertTrue(result instanceof String);
        assertEquals("ello", result);
    }

    @Test
    public void test_transform_customBeanMethod_returnsResult() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("greet", null, null);

        final Object result = transformer.transform(new SampleBean());

        assertEquals("hi", result);
    }

    @Test
    public void test_transform_nullInput_returnsNull() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("length", null, null);

        final Object result = transformer.transform(null);

        assertNull(result);
    }

    @Test
    public void test_transform_methodNotExist_throwsFunctorException() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("nonExistentMethod", null, null);

        try {
            transformer.transform(hello);
            fail("Expected FunctorException");
        } catch (final FunctorException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("nonExistentMethod"));
            assertTrue(message.contains("java.lang.String"));
            assertNull(ex.getCause());
        }
    }

    @Test
    public void test_transform_methodNotExistOnCustomBean_throwsFunctorException() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("missing", null, null);

        try {
            transformer.transform(new NoMethodBean());
            fail("Expected FunctorException");
        } catch (final FunctorException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("NoMethodBean"));
        }
    }

    @Test
    public void test_transform_targetMethodThrows_wrapsInvocationTargetException() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("boom", null, null);

        try {
            transformer.transform(new SampleBean());
            fail("Expected FunctorException");
        } catch (final FunctorException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("boom"));
            assertTrue(message.contains("SampleBean"));

            final Throwable cause = ex.getCause();
            assertNotNull(cause);
            assertTrue(cause instanceof InvocationTargetException);

            final Throwable inner = cause.getCause();
            assertNotNull(inner);
            assertTrue(inner instanceof IllegalStateException);
            assertEquals("boom", inner.getMessage());
        }
    }

    @Test
    public void test_transform_wrongArgType_throwsFunctorException() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("substring", new Class<?>[]{long.class}, new Object[]{Long.valueOf(1L)});

        try {
            transformer.transform(hello);
            fail("Expected FunctorException");
        } catch (final FunctorException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("substring"));
        }
    }

    @Test
    public void test_transform_privateMethod_throwsFunctorException() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("secret", null, null);

        try {
            transformer.transform(new SampleBean());
            fail("Expected FunctorException");
        } catch (final FunctorException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("secret"));
        }
    }

    @Test
    public void test_transform_voidMethod_returnsNull() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("clear", null, null);
        final List<Integer> input = new ArrayList<>(Arrays.asList(Integer.valueOf(1), Integer.valueOf(2)));

        final Object result = transformer.transform(input);

        assertNull(result);
        assertEquals(0, input.size());
    }

    @Test
    public void test_transform_staticMethod_returnsResult() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("valueOf", new Class<?>[]{int.class}, new Object[]{Integer.valueOf(42)});

        final Object result = transformer.transform("anyString");

        assertEquals("42", result);
    }

    @Test
    public void test_transform_inheritedMethod_returnsResult() {
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("toString", null, null);

        final Object result = transformer.transform(new SampleBean());

        assertNotNull(result);
        assertTrue(result instanceof String);
        assertTrue(((String) result).contains("SampleBean"));
    }

    @Test
    public void test_transform_constructorClonesArrays_defensiveCopy() {
        final Class<?>[] types = new Class<?>[]{int.class};
        final Object[] args = new Object[]{Integer.valueOf(1)};
        final InvokerTransformer<Object, Object> transformer =
                new InvokerTransformer<>("substring", types, args);

        types[0] = String.class;
        args[0] = Integer.valueOf(99);

        final Object result = transformer.transform(hello);

        assertEquals("ello", result);
    }

    @Test
    public void test_invokerTransformer_factory_noArg_returnsWorkingTransformer() {
        final Transformer<Object, Object> transformer = InvokerTransformer.invokerTransformer("length");

        assertNotNull(transformer);
        final Object result = transformer.transform(hello);
        assertEquals(Integer.valueOf(5), result);
    }

    @Test
    public void test_invokerTransformer_factory_withArgs_returnsWorkingTransformer() {
        final Transformer<Object, Object> transformer =
                InvokerTransformer.invokerTransformer("substring", new Class<?>[]{int.class}, new Object[]{Integer.valueOf(1)});

        assertNotNull(transformer);
        final Object result = transformer.transform(hello);
        assertEquals("ello", result);
    }

    @Test
    public void test_invokerTransformer_factory_nullMethodName_throwsNPE() {
        try {
            InvokerTransformer.invokerTransformer(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("methodName"));
        }
    }

    @Test
    public void test_invokerTransformer_factory_paramTypesNullArgsNotNull_throwsIAE() {
        try {
            InvokerTransformer.invokerTransformer("m", null, new Object[]{Integer.valueOf(1)});
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("parameter types must match"));
        }
    }

    @Test
    public void test_invokerTransformer_factory_paramTypesNotNullArgsNull_throwsIAE() {
        try {
            InvokerTransformer.invokerTransformer("m", new Class<?>[]{int.class}, null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("parameter types must match"));
        }
    }

    @Test
    public void test_invokerTransformer_factory_lengthMismatch_throwsIAE() {
        try {
            InvokerTransformer.invokerTransformer("m", new Class<?>[]{int.class}, new Object[]{});
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException ex) {
            final String message = ex.getMessage();
            assertNotNull(message);
            assertTrue(message.contains("parameter types must match"));
        }
    }

    @Test
    public void test_invokerTransformer_factory_emptyParamTypes_returnsNoArgTransformer() {
        final Transformer<Object, Object> transformer =
                InvokerTransformer.invokerTransformer("length", new Class<?>[]{}, new Object[]{});

        assertNotNull(transformer);
        final Object result = transformer.transform(hello);
        assertEquals(Integer.valueOf(5), result);
    }

    public static class SampleBean {
        public String greet() {
            return "hi";
        }

        public String boom() {
            throw new IllegalStateException("boom");
        }

        public String echo(final String s) {
            return s;
        }

        private String secret() {
            return "secret";
        }
    }

    public static class NoMethodBean {
    }
}