package org.jdom2.internal;

import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class ReflectionConstructorTest {

    public static class PublicNoArgStub {
        public PublicNoArgStub() {
        }
    }

    public static class OnlyArgConstructorStub {
        public OnlyArgConstructorStub(String s) {
        }
    }

    public static class PrivateConstructorStub {
        private PrivateConstructorStub() {
        }
    }

    public abstract static class AbstractStub {
        public AbstractStub() {
        }
    }

    public interface InterfaceStub {
    }

    public static class ThrowingConstructorStub {
        public ThrowingConstructorStub() {
            throw new RuntimeException("boom");
        }
    }

    public static class SubTypeStub extends PublicNoArgStub {
        public SubTypeStub() {
        }
    }

    private static final String PUBLIC_NO_ARG_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$PublicNoArgStub";
    private static final String SUB_TYPE_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$SubTypeStub";
    private static final String ONLY_ARG_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$OnlyArgConstructorStub";
    private static final String PRIVATE_CTOR_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$PrivateConstructorStub";
    private static final String ABSTRACT_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$AbstractStub";
    private static final String INTERFACE_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$InterfaceStub";
    private static final String THROWING_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$ThrowingConstructorStub";

    @Test
    public void test_construct_success_public_no_arg() {
        PublicNoArgStub instance = ReflectionConstructor.construct(PUBLIC_NO_ARG_NAME, PublicNoArgStub.class);
        assertNotNull(instance);
        assertTrue(instance instanceof PublicNoArgStub);
        assertEquals(PublicNoArgStub.class, instance.getClass());
    }

    @Test
    public void test_construct_success_subtype_assignable() {
        PublicNoArgStub instance = ReflectionConstructor.construct(SUB_TYPE_NAME, PublicNoArgStub.class);
        assertNotNull(instance);
        assertTrue(instance instanceof SubTypeStub);
        assertTrue(instance instanceof PublicNoArgStub);
    }

    @Test
    public void test_construct_class_not_found() {
        try {
            ReflectionConstructor.construct("org.jdom2.internal.DoesNotExistClass", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getCause() instanceof ClassNotFoundException);
            assertTrue(e.getMessage().contains("org.jdom2.internal.DoesNotExistClass"));
        }
    }

    @Test
    public void test_construct_not_assignable() {
        try {
            ReflectionConstructor.construct("java.lang.String", Integer.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            assertTrue(e.getMessage().contains("java.lang.String"));
            assertTrue(e.getMessage().contains("java.lang.Integer"));
        }
    }

    @Test
    public void test_construct_no_no_arg_constructor() {
        try {
            ReflectionConstructor.construct(ONLY_ARG_NAME, OnlyArgConstructorStub.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getCause() instanceof NoSuchMethodException);
            assertTrue(e.getMessage().contains("no-arg constructor"));
        }
    }

    @Test
    public void test_construct_private_constructor_illegal_access() {
        try {
            ReflectionConstructor.construct(PRIVATE_CTOR_NAME, PrivateConstructorStub.class);
            fail("Expected IllegalArgumentException or IllegalStateException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getCause() instanceof NoSuchMethodException
                    || e.getCause() instanceof IllegalAccessException);
        } catch (IllegalStateException e) {
            assertTrue(e.getCause() instanceof NoSuchMethodException
                    || e.getCause() instanceof IllegalAccessException);
        }
    }

    @Test
    public void test_construct_abstract_class_instantiation() {
        try {
            ReflectionConstructor.construct(ABSTRACT_NAME, AbstractStub.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getCause() instanceof InstantiationException);
            assertTrue(e.getMessage().contains("Unable to instantiate"));
        }
    }

    @Test
    public void test_construct_interface_instantiation() {
        try {
            ReflectionConstructor.construct(INTERFACE_NAME, InterfaceStub.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    @Test
    public void test_construct_constructor_throws_invocation_target() {
        try {
            ReflectionConstructor.construct(THROWING_NAME, ThrowingConstructorStub.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getCause() instanceof InvocationTargetException);
            Throwable inner = e.getCause().getCause();
            assertTrue(inner instanceof RuntimeException);
            assertEquals("boom", inner.getMessage());
        }
    }

    @Test
    public void test_construct_jdk_class_success() {
        CharSequence instance = ReflectionConstructor.construct("java.lang.StringBuilder", CharSequence.class);
        assertNotNull(instance);
        assertTrue(instance instanceof StringBuilder);
        assertTrue(instance instanceof CharSequence);
    }

    @Test
    public void test_construct_null_classname() {
        try {
            ReflectionConstructor.construct(null, Object.class);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
    }

    @Test
    public void test_construct_null_targetclass() {
        try {
            ReflectionConstructor.construct("java.lang.String", null);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
    }

    @Test
    public void test_construct_empty_classname() {
        try {
            ReflectionConstructor.construct("", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }
}