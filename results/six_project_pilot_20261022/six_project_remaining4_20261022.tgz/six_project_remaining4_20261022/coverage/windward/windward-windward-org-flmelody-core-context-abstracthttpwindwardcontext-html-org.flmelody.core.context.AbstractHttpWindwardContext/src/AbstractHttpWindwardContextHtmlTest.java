package org.flmelody.core.context;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flmelody.core.WindwardRequest;
import org.flmelody.core.WindwardResponse;
import org.flmelody.core.exception.WindwardException;
import org.flmelody.core.plugin.json.JsonPlugin;
import org.flmelody.core.plugin.view.AbstractViewPlugin;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Tests for {@link AbstractHttpWindwardContext#html(String, Object)}.
 *
 * <p>This test class avoids Mockito entirely. Instead it uses lightweight fake implementations of
 * the collaborating components ({@link WindwardRequest}, {@link WindwardResponse},
 * {@link AbstractViewPlugin}, {@link JsonPlugin}) and a package-visible test subclass that
 * overrides the static plugin lookup hooks so that the global {@code Windward} registry is never
 * touched.
 */
public class AbstractHttpWindwardContextHtmlTest {

  private FakeWindwardRequest request;
  private FakeWindwardResponse response;
  private TestableHttpWindwardContext context;

  @Before
  public void setUp() {
    request = new FakeWindwardRequest();
    response = new FakeWindwardResponse();
    context = new TestableHttpWindwardContext(request, response);
  }

  // ---------------------------------------------------------------------------
  // Normal path
  // ---------------------------------------------------------------------------

  @Test
  public void test_html_normal_render_success() {
    final Map<String, Object> model = new HashMap<>();
    model.put("name", "windward");
    final Map<String, Object> convertedModel = Collections.singletonMap("k", "v");
    final String renderedHtml = "<html>ok</html>";

    FakeJsonPlugin jsonPlugin = new FakeJsonPlugin(convertedModel);
    FakeViewPlugin viewPlugin = new FakeViewPlugin("html", renderedHtml);

    context.viewPlugins = Collections.<AbstractViewPlugin>singletonList(viewPlugin);
    context.jsonPlugin = jsonPlugin;

    context.html("index.html", model);

    // windwardResponse.write(200, "text/html", emptyMap, renderedHtml) called exactly once
    assertEquals(1, response.writeCalls.size());
    WriteCall call = response.writeCalls.get(0);
    assertEquals(200, call.code);
    assertEquals("text/html", call.contentType);
    assertNotNull(call.headers);
    assertTrue(call.headers.isEmpty());
    assertEquals(renderedHtml, call.body);

    // resolveView called once with (viewUrl, convertedModel)
    assertEquals(1, viewPlugin.resolveViewCalls.size());
    ResolveViewCall resolveCall = viewPlugin.resolveViewCalls.get(0);
    assertEquals("index.html", resolveCall.viewUrl);
    assertSame(convertedModel, resolveCall.model);

    // toObject called once with (model, HashMap.class)
    assertEquals(1, jsonPlugin.toObjectCalls.size());
    ToObjectCall toObjectCall = jsonPlugin.toObjectCalls.get(0);
    assertSame(model, toObjectCall.model);
    assertEquals(HashMap.class, toObjectCall.type);

    // no other interactions with the response
    assertEquals(1, response.totalInteractions());
  }

  // ---------------------------------------------------------------------------
  // Empty / null viewUrl
  // ---------------------------------------------------------------------------

  @Test
  public void test_html_null_viewUrl_throws() {
    final Map<String, Object> model = new HashMap<>();

    try {
      context.html(null, model);
      fail("Expected WindwardException for null viewUrl");
    } catch (WindwardException e) {
      assertEquals("View name is empty!", e.getMessage());
    }

    // No plugin lookup happened
    assertEquals(0, context.pluginsLookupCount);
    // No response write happened
    assertEquals(0, response.writeCalls.size());
    assertEquals(0, response.totalInteractions());
  }

  @Test
  public void test_html_empty_viewUrl_throws() {
    final Map<String, Object> model = new HashMap<>();

    try {
      context.html("", model);
      fail("Expected WindwardException for empty viewUrl");
    } catch (WindwardException e) {
      assertEquals("View name is empty!", e.getMessage());
    }

    assertEquals(0, response.writeCalls.size());
    assertEquals(0, response.totalInteractions());
  }

  // ---------------------------------------------------------------------------
  // Missing / malformed extension
  // ---------------------------------------------------------------------------

  @Test
  public void test_html_no_extension_throws() {
    final Map<String, Object> model = new HashMap<>();

    try {
      context.html("index", model);
      fail("Expected WindwardException for viewUrl without extension");
    } catch (WindwardException e) {
      assertEquals("Unknown View extension!", e.getMessage());
    }

    assertEquals(0, context.pluginsLookupCount);
    assertEquals(0, response.writeCalls.size());
    assertEquals(0, response.totalInteractions());
  }

  @Test
  public void test_html_dot_at_start_throws() {
    final Map<String, Object> model = new HashMap<>();

    try {
      context.html(".html", model);
      fail("Expected WindwardException for viewUrl starting with dot");
    } catch (WindwardException e) {
      assertEquals("Unknown View extension!", e.getMessage());
    }

    assertEquals(0, response.writeCalls.size());
    assertEquals(0, response.totalInteractions());
  }

  // ---------------------------------------------------------------------------
  // No matching plugin
  // ---------------------------------------------------------------------------

  @Test
  public void test_html_no_matching_plugin_throws() {
    final Map<String, Object> model = new HashMap<>();
    FakeViewPlugin viewPlugin = new FakeViewPlugin("jsp", "<html>jsp</html>");

    context.viewPlugins = Collections.<AbstractViewPlugin>singletonList(viewPlugin);
    context.jsonPlugin = new FakeJsonPlugin(Collections.<String, Object>emptyMap());

    try {
      context.html("index.html", model);
      fail("Expected WindwardException for unsupported extension");
    } catch (WindwardException e) {
      assertEquals("Unsupported View extension!", e.getMessage());
    }

    assertEquals(0, viewPlugin.resolveViewCalls.size());
    assertEquals(0, response.writeCalls.size());
    assertEquals(0, response.totalInteractions());
  }

  @Test
  public void test_html_empty_plugin_list_throws() {
    final Map<String, Object> model = new HashMap<>();

    context.viewPlugins = Collections.<AbstractViewPlugin>emptyList();
    context.jsonPlugin = new FakeJsonPlugin(Collections.<String, Object>emptyMap());

    try {
      context.html("index.html", model);
      fail("Expected WindwardException for empty plugin list");
    } catch (WindwardException e) {
      assertEquals("Unsupported View extension!", e.getMessage());
    }

    assertEquals(0, response.writeCalls.size());
    assertEquals(0, response.totalInteractions());
  }

  // ---------------------------------------------------------------------------
  // Exception wrapping
  // ---------------------------------------------------------------------------

  @Test
  public void test_html_resolveView_throws_wrapped_in_runtime_exception() {
    final Map<String, Object> model = new HashMap<>();
    final Map<String, Object> convertedModel = Collections.singletonMap("k", "v");

    FakeJsonPlugin jsonPlugin = new FakeJsonPlugin(convertedModel);
    FakeViewPlugin viewPlugin = new FakeViewPlugin("html", null);
    Exception renderFailure = new Exception("render failed");
    viewPlugin.resolveViewFailure = renderFailure;

    context.viewPlugins = Collections.<AbstractViewPlugin>singletonList(viewPlugin);
    context.jsonPlugin = jsonPlugin;

    try {
      context.html("index.html", model);
      fail("Expected RuntimeException wrapping the resolveView failure");
    } catch (RuntimeException e) {
      assertSame(renderFailure, e.getCause());
      assertEquals("render failed", e.getCause().getMessage());
    }

    assertEquals(0, response.writeCalls.size());
    assertEquals(0, response.totalInteractions());
  }

  @Test
  public void test_html_toObject_throws_wrapped_in_runtime_exception() {
    final Map<String, Object> model = new HashMap<>();

    FakeJsonPlugin jsonPlugin = new FakeJsonPlugin(null);
    RuntimeException serializeFailure = new RuntimeException("serialize failed");
    jsonPlugin.toObjectFailure = serializeFailure;

    FakeViewPlugin viewPlugin = new FakeViewPlugin("html", "<html>ok</html>");

    context.viewPlugins = Collections.<AbstractViewPlugin>singletonList(viewPlugin);
    context.jsonPlugin = jsonPlugin;

    try {
      context.html("index.html", model);
      fail("Expected RuntimeException wrapping the toObject failure");
    } catch (RuntimeException e) {
      assertSame(serializeFailure, e.getCause());
      assertEquals("serialize failed", e.getCause().getMessage());
    }

    assertEquals(0, viewPlugin.resolveViewCalls.size());
    assertEquals(0, response.writeCalls.size());
    assertEquals(0, response.totalInteractions());
  }

  // ---------------------------------------------------------------------------
  // Multiple plugins
  // ---------------------------------------------------------------------------

  @Test
  public void test_html_multiple_plugins_selects_first_matching() {
    final Map<String, Object> model = new HashMap<>();
    final Map<String, Object> convertedModel = Collections.singletonMap("k", "v");
    final String renderedHtml = "<html>ok</html>";

    FakeJsonPlugin jsonPlugin = new FakeJsonPlugin(convertedModel);
    FakeViewPlugin nonMatchingPlugin = new FakeViewPlugin("jsp", "<html>jsp</html>");
    FakeViewPlugin matchingPlugin = new FakeViewPlugin("html", renderedHtml);

    context.viewPlugins =
        Arrays.<AbstractViewPlugin>asList(nonMatchingPlugin, matchingPlugin);
    context.jsonPlugin = jsonPlugin;

    context.html("index.html", model);

    assertEquals(1, matchingPlugin.resolveViewCalls.size());
    assertEquals(0, nonMatchingPlugin.resolveViewCalls.size());

    assertEquals(1, response.writeCalls.size());
    WriteCall call = response.writeCalls.get(0);
    assertEquals(200, call.code);
    assertEquals("text/html", call.contentType);
    assertTrue(call.headers.isEmpty());
    assertEquals(renderedHtml, call.body);
  }

  @Test
  public void test_html_multiple_matching_plugins_selects_first() {
    final Map<String, Object> model = new HashMap<>();
    final Map<String, Object> convertedModel = Collections.singletonMap("k", "v");
    final String renderedHtml = "<html>ok</html>";

    FakeJsonPlugin jsonPlugin = new FakeJsonPlugin(convertedModel);
    FakeViewPlugin firstPlugin = new FakeViewPlugin("html", renderedHtml);
    FakeViewPlugin secondPlugin = new FakeViewPlugin("html", "<html>second</html>");

    context.viewPlugins = Arrays.<AbstractViewPlugin>asList(firstPlugin, secondPlugin);
    context.jsonPlugin = jsonPlugin;

    context.html("index.html", model);

    assertEquals(1, firstPlugin.resolveViewCalls.size());
    assertEquals(0, secondPlugin.resolveViewCalls.size());

    assertEquals(1, response.writeCalls.size());
    assertEquals(renderedHtml, response.writeCalls.get(0).body);
  }

  // ---------------------------------------------------------------------------
  // Extension extraction
  // ---------------------------------------------------------------------------

  @Test
  public void test_html_extension_extraction_with_multiple_dots() {
    final Map<String, Object> model = new HashMap<>();
    final Map<String, Object> convertedModel = Collections.singletonMap("k", "v");
    final String renderedHtml = "<html>ok</html>";

    FakeJsonPlugin jsonPlugin = new FakeJsonPlugin(convertedModel);
    FakeViewPlugin viewPlugin = new FakeViewPlugin("html", renderedHtml);

    context.viewPlugins = Collections.<AbstractViewPlugin>singletonList(viewPlugin);
    context.jsonPlugin = jsonPlugin;

    context.html("a.b.html", model);

    // supportedExtension was invoked with the last segment "html"
    assertFalse(viewPlugin.supportedExtensionCalls.isEmpty());
    for (String extension : viewPlugin.supportedExtensionCalls) {
      assertEquals("html", extension);
    }

    assertEquals(1, viewPlugin.resolveViewCalls.size());
    assertEquals("a.b.html", viewPlugin.resolveViewCalls.get(0).viewUrl);

    assertEquals(1, response.writeCalls.size());
    assertEquals("text/html", response.writeCalls.get(0).contentType);
  }

  // ---------------------------------------------------------------------------
  // Test subclass that bypasses the static Windward registry
  // ---------------------------------------------------------------------------

  /**
   * Test subclass of {@link AbstractHttpWindwardContext} that overrides the static plugin lookup
   * hooks so that tests never touch the global {@code Windward} registry.
   */
  static class TestableHttpWindwardContext extends AbstractHttpWindwardContext {

    List<AbstractViewPlugin> viewPlugins = Collections.emptyList();
    JsonPlugin jsonPlugin;
    int pluginsLookupCount = 0;

    TestableHttpWindwardContext(WindwardRequest request, WindwardResponse response) {
      super(request, response);
    }

    @Override
    protected List<AbstractViewPlugin> lookupViewPlugins() {
      pluginsLookupCount++;
      return viewPlugins;
    }

    @Override
    protected JsonPlugin lookupJsonPlugin() {
      return jsonPlugin;
    }
  }

  // ---------------------------------------------------------------------------
  // Fakes
  // ---------------------------------------------------------------------------

  static class FakeWindwardRequest implements WindwardRequest {
    @Override
    public <I> I readJson(String body, Class<I> clazz) {
      return null;
    }

    @Override
    public <I> I readJson(String body, Type type) {
      return null;
    }

    @Override
    public <I> I bindJson(String body, Class<I> clazz, Class<?>... groups) {
      return null;
    }

    @Override
    public <I> I bindJson(String body, Type type, Class<?>... groups) {
      return null;
    }

    @Override
    public String getRequestBody() {
      return "";
    }
  }

  static class WriteCall {
    final int code;
    final String contentType;
    final Map<String, Object> headers;
    final Object body;

    WriteCall(int code, String contentType, Map<String, Object> headers, Object body) {
      this.code = code;
      this.contentType = contentType;
      this.headers = headers;
      this.body = body;
    }
  }

  static class FakeWindwardResponse implements WindwardResponse {
    final List<WriteCall> writeCalls = new ArrayList<WriteCall>();

    @Override
    public void write(int code, String contentType, Map<String, Object> headers, Object body) {
      writeCalls.add(new WriteCall(code, contentType, headers, body));
    }

    int totalInteractions() {
      return writeCalls.size();
    }
  }

  static class ResolveViewCall {
    final String viewUrl;
    final Object model;

    ResolveViewCall(String viewUrl, Object model) {
      this.viewUrl = viewUrl;
      this.model = model;
    }
  }

  static class FakeViewPlugin extends AbstractViewPlugin {
    private final String extension;
    private final String renderedView;
    final List<String> supportedExtensionCalls = new ArrayList<String>();
    final List<ResolveViewCall> resolveViewCalls = new ArrayList<ResolveViewCall>();
    Exception resolveViewFailure;

    FakeViewPlugin(String extension, String renderedView) {
      this.extension = extension;
      this.renderedView = renderedView;
    }

    @Override
    public boolean supportedExtension(String extension) {
      supportedExtensionCalls.add(extension);
      return this.extension != null && this.extension.equals(extension);
    }

    @Override
    public String resolveView(String viewUrl, Object model) throws Exception {
      resolveViewCalls.add(new ResolveViewCall(viewUrl, model));
      if (resolveViewFailure != null) {
        throw resolveViewFailure;
      }
      return renderedView;
    }

    @Override
    public String render(String viewUrl, Map<String, Object> model) {
      return renderedView;
    }
  }

  static class ToObjectCall {
    final Object model;
    final Class<?> type;

    ToObjectCall(Object model, Class<?> type) {
      this.model = model;
      this.type = type;
    }
  }

  static class FakeJsonPlugin extends JsonPlugin {
    private final Object converted;
    final List<ToObjectCall> toObjectCalls = new ArrayList<ToObjectCall>();
    RuntimeException toObjectFailure;

    FakeJsonPlugin(Object converted) {
      this.converted = converted;
    }

    @Override
    public <T> T toObject(Object source, Class<T> clazz) {
      toObjectCalls.add(new ToObjectCall(source, clazz));
      if (toObjectFailure != null) {
        throw toObjectFailure;
      }
      @SuppressWarnings("unchecked")
      T result = (T) converted;
      return result;
    }
  }
}