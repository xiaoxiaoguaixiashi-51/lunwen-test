package org.apache.commons.collections4;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections4.keyvalue.DefaultKeyValue;
import org.apache.commons.collections4.keyvalue.DefaultMapEntry;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link MapUtils#putAll(Map, Object[])}.
 */
public class MapUtilsPutAllTest {

    @Test
    public void testPutAllWithNullMapThrowsNPE() {
        final NullPointerException ex = assertThrows(NullPointerException.class,
                () -> MapUtils.putAll(null, new Object[0]));
        assertTrue(ex.getMessage().contains("map"), "Exception message should contain 'map'");
    }

    @Test
    public void testPutAllWithNullArrayReturnsSameMap() {
        final Map<String, String> map = new HashMap<>();
        final Map<String, String> result = MapUtils.putAll(map, null);
        assertSame(map, result);
        assertTrue(map.isEmpty(), "Map should remain empty when null array is passed");
    }

    @Test
    public void testPutAllWithEmptyArrayReturnsSameMap() {
        final Map<String, String> map = new HashMap<>();
        final Map<String, String> result = MapUtils.putAll(map, new Object[0]);
        assertSame(map, result);
        assertTrue(map.isEmpty(), "Map should remain empty when empty array is passed");
    }

    @Test
    public void testPutAllWithMapEntryArray() {
        final Map<String, String> map = new LinkedHashMap<>();
        final Map.Entry<String, String> entry1 = new DefaultMapEntry<>("key1", "value1");
        final Map.Entry<String, String> entry2 = new DefaultMapEntry<>("key2", "value2");

        final Map<String, String> result = MapUtils.putAll(map,
                new Map.Entry[] { entry1, entry2 });

        assertSame(map, result);
        assertEquals(2, map.size());
        // LinkedHashMap preserves insertion order
        final String[] expectedKeys = { "key1", "key2" };
        final String[] expectedValues = { "value1", "value2" };
        int i = 0;
        for (final Map.Entry<String, String> e : map.entrySet()) {
            assertEquals(expectedKeys[i], e.getKey());
            assertEquals(expectedValues[i], e.getValue());
            i++;
        }
    }

    @Test
    public void testPutAllWithKeyValueArray() {
        final Map<String, String> map = new LinkedHashMap<>();
        final KeyValue<String, String> kv1 = new DefaultKeyValue<>("k1", "v1");
        final KeyValue<String, String> kv2 = new DefaultKeyValue<>("k2", "v2");

        final Map<String, String> result = MapUtils.putAll(map,
                new KeyValue[] { kv1, kv2 });

        assertSame(map, result);
        assertEquals(2, map.size());
        assertEquals("v1", map.get("k1"));
        assertEquals("v2", map.get("k2"));
    }

    @Test
    public void testPutAllWithObjectArrayOfPairs() {
        final Map<String, String> map = new HashMap<>();
        final Object[][] array = { { "keyA", "valA" }, { "keyB", "valB" } };
        final Map<String, String> result = MapUtils.putAll(map, array);
        assertSame(map, result);
        assertEquals("valA", map.get("keyA"));
        assertEquals("valB", map.get("keyB"));
        assertEquals(2, map.size());
    }

    @Test
    public void testPutAllWithObjectArrayNullSubArrayThrowsIllegalArgumentException() {
        final Object[][] array = { { "k1", "v1" }, null, { "k3", "v3" } };
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> MapUtils.putAll(new HashMap<>(), array));
        assertTrue(ex.getMessage().contains("Invalid array element: 1"), "Exception message should contain index 1");
    }

    @Test
    public void testPutAllWithObjectArrayShortSubArrayThrowsIllegalArgumentException() {
        final Object[][] array = { { "k1", "v1" }, { "single" }, { "k3", "v3" } };
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> MapUtils.putAll(new HashMap<>(), array));
        assertTrue(ex.getMessage().contains("Invalid array element: 1"), "Exception message should contain index 1");
    }

    @Test
    public void testPutAllWithFlatAlternatingArray() {
        final Map<String, String> map = new LinkedHashMap<>();
        final Object[] array = { "k1", "v1", "k2", "v2" };
        final Map<String, String> result = MapUtils.putAll(map, array);
        assertSame(map, result);
        assertEquals(2, map.size());
        assertEquals("v1", map.get("k1"));
        assertEquals("v2", map.get("k2"));
        // LinkedHashMap preserves insertion order
        final String[] expectedKeys = { "k1", "k2" };
        final String[] expectedValues = { "v1", "v2" };
        int i = 0;
        for (final Map.Entry<String, String> e : map.entrySet()) {
            assertEquals(expectedKeys[i], e.getKey());
            assertEquals(expectedValues[i], e.getValue());
            i++;
        }
    }

    @Test
    public void testPutAllWithFlatArrayOddLengthIgnoresLastElement() {
        final Map<String, String> map = new HashMap<>();
        final Object[] array = { "k1", "v1", "k2" };
        final Map<String, String> result = MapUtils.putAll(map, array);
        assertSame(map, result);
        assertEquals(1, map.size());
        assertEquals("v1", map.get("k1"));
        assertFalse(map.containsKey("k2"));
    }

    @Test
    public void testPutAllWithMixedEntryAndNonEntryThrowsClassCastException() {
        final Map<String, String> map = new HashMap<>();
        final Map.Entry<String, String> mockEntry = new DefaultMapEntry<>("k", "v");
        final Object[] array = { mockEntry, "notAnEntry" };
        assertThrows(ClassCastException.class, () -> MapUtils.putAll(map, array));
    }

    @Test
    public void testPutAllWithMixedKeyValueAndNonKeyValueThrowsClassCastException() {
        final Map<String, String> map = new HashMap<>();
        final KeyValue<String, String> mockKV = new DefaultKeyValue<>("k", "v");
        final Object[] array = { mockKV, "notAKV" };
        assertThrows(ClassCastException.class, () -> MapUtils.putAll(map, array));
    }

    @Test
    public void testPutAllWithMixedObjectArrayAndNonArrayThrowsClassCastException() {
        final Map<String, String> map = new HashMap<>();
        final Object[] array = { new Object[] { "k1", "v1" }, "notAnArray" };
        assertThrows(ClassCastException.class, () -> MapUtils.putAll(map, array));
    }

    @Test
    public void testPutAllWithAlternatingArrayInvalidCastPropagation() {
        final TreeMap<Integer, String> map = new TreeMap<>();
        final Object[] array = { "notAnInteger", "value" };
        assertThrows(ClassCastException.class, () -> MapUtils.putAll(map, array));
    }
}