/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4.bloomfilter;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link EnhancedDoubleHasher}.
 *
 * <p>Uses a controlled {@link Shape} instance with fixed bit and hash function counts.
 * All tests rely on the real implementation of {@link BitMaps#mod(long, int)}.</p>
 */
class EnhancedDoubleHasherTest {

    // Helper to create a Shape with the given number of bits and hash functions.
    // Shape is a final class with a private constructor; use the static factory method.
    private static Shape shapeOf(final int bits, final int hashFunctions) {
        return Shape.of(bits, hashFunctions);
    }

    // -----------------------------------------------------------------------
    // asIndexArray normal case
    // -----------------------------------------------------------------------

    @Test
    void testIndicesNormalAsIndexArray() {
        Shape shape = shapeOf(20, 5);

        EnhancedDoubleHasher hasher = new EnhancedDoubleHasher(10L, 5L);
        IndexExtractor extractor = hasher.indices(shape);

        int[] indices = extractor.asIndexArray();

        assertEquals(5, indices.length, "asIndexArray should return exactly k indices");
        // Expected sequence based on enhanced double hashing with bits=20, initial=10, increment=5
        assertArrayEquals(new int[] {10, 5, 1, 19, 0}, indices,
                "Indices should match the expected enhanced double hashing sequence");
    }

    // -----------------------------------------------------------------------
    // processIndices early termination
    // -----------------------------------------------------------------------

    @Test
    void testProcessIndicesEarlyTermination() {
        Shape shape = shapeOf(20, 5);

        EnhancedDoubleHasher hasher = new EnhancedDoubleHasher(10L, 5L);
        IndexExtractor extractor = hasher.indices(shape);

        // Consumer that returns true on first call, then false on second call
        final AtomicInteger callCount = new AtomicInteger(0);
        IntPredicate consumer = i -> {
            int current = callCount.incrementAndGet();
            // Return false on the second invocation (i.e., after the first true)
            return current < 2;
        };

        boolean result = extractor.processIndices(consumer);

        assertFalse(result, "processIndices should return false when consumer returns false");
        // Consumer should have been invoked exactly twice: first index 10 (returns true),
        // second index 5 (returns false). No third invocation.
        assertEquals(2, callCount.get(), "Consumer should be called exactly twice");
    }

    // -----------------------------------------------------------------------
    // k >= bits tetrahedral path
    // -----------------------------------------------------------------------

    @Test
    void testKGteBitsTetrahedralPath() {
        Shape shape = shapeOf(3, 5);

        EnhancedDoubleHasher hasher = new EnhancedDoubleHasher(1L, 2L);
        IndexExtractor extractor = hasher.indices(shape);

        int[] indices = extractor.asIndexArray();

        assertEquals(5, indices.length, "asIndexArray should return exactly k indices");
        // Expected sequence for bits=3, initial=1, increment=2 with tetrahedral reset
        assertArrayEquals(new int[] {1, 2, 1, 2, 0}, indices,
                "Indices should follow tetrahedral logic and stay within [0,2]");

        // Verify all indices are within [0, bits-1]
        for (int idx : indices) {
            assertTrue(idx >= 0 && idx < 3,
                    "Each index must be in the range [0, 2], but got " + idx);
        }
    }

    // -----------------------------------------------------------------------
    // Extreme case: bits == 1
    // -----------------------------------------------------------------------

    @Test
    void testBitsOneExtreme() {
        Shape shape = shapeOf(1, 3);

        EnhancedDoubleHasher hasher = new EnhancedDoubleHasher(12345L, 67890L);
        IndexExtractor extractor = hasher.indices(shape);

        int[] indices = extractor.asIndexArray();

        assertEquals(3, indices.length);
        // All indices should be 0 because mod with 1 always returns 0
        assertArrayEquals(new int[] {0, 0, 0}, indices);

        // Also ensure processIndices does not throw
        assertDoesNotThrow(() -> {
            IntPredicate consumer = i -> true;
            extractor.processIndices(consumer);
        }, "processIndices should not throw for bits=1");
    }

    // -----------------------------------------------------------------------
    // Null shape throws NullPointerException
    // -----------------------------------------------------------------------

    @Test
    void testNullShapeThrowsNPE() {
        EnhancedDoubleHasher hasher = new EnhancedDoubleHasher(1L, 2L);

        NullPointerException ex = assertThrows(NullPointerException.class,
                () -> hasher.indices(null),
                "indices(null) must throw NullPointerException");
        assertTrue(ex.getMessage().contains("shape"),
                "Exception message should contain 'shape'");
    }

    // -----------------------------------------------------------------------
    // Null consumer throws NullPointerException
    // -----------------------------------------------------------------------

    @Test
    void testNullConsumerThrowsNPE() {
        Shape shape = shapeOf(10, 3);

        EnhancedDoubleHasher hasher = new EnhancedDoubleHasher(1L, 2L);
        IndexExtractor extractor = hasher.indices(shape);

        NullPointerException ex = assertThrows(NullPointerException.class,
                () -> extractor.processIndices(null),
                "processIndices(null) must throw NullPointerException");
        assertTrue(ex.getMessage().contains("consumer"),
                "Exception message should contain 'consumer'");
    }

    // -----------------------------------------------------------------------
    // asIndexArray collects all indices even with duplicates
    // -----------------------------------------------------------------------

    @Test
    void testAsIndexArrayCollectsAllIndicesEvenWithDuplicates() {
        Shape shape = shapeOf(3, 6);

        EnhancedDoubleHasher hasher = new EnhancedDoubleHasher(1L, 2L);
        IndexExtractor extractor = hasher.indices(shape);

        int[] indices = extractor.asIndexArray();

        // asIndexArray always returns an array of length k
        assertEquals(6, indices.length, "Array length must equal k");

        // All indices must be in [0,2], duplicates are allowed
        for (int idx : indices) {
            assertTrue(idx >= 0 && idx < 3,
                    "Indices must be in range [0, 2] but got " + idx);
        }

        // Duplicates are expected because of limited bits; verify at least one duplicate exists
        // (not a strict requirement but confirms the behavior)
        long distinctCount = IntStream.of(indices).distinct().count();
        assertTrue(distinctCount <= 3, "With bits=3, there can be at most 3 distinct values");
        assertTrue(distinctCount < 6,
                "With k=6 and bits=3, duplicates are unavoidable");
    }
}