package org.apache.commons.collections4.trie.analyzer;

import org.apache.commons.collections4.trie.KeyAnalyzer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class StringKeyAnalyzerTest {

    private final StringKeyAnalyzer analyzer = StringKeyAnalyzer.INSTANCE;
    private final int EQUAL_BIT_KEY = KeyAnalyzer.EQUAL_BIT_KEY;
    private final int NULL_BIT_KEY = KeyAnalyzer.NULL_BIT_KEY;

    @Test
    void testEqualStringsReturnEQUAL_BIT_KEY() {
        int result = analyzer.bitIndex("abc", 0, 48, "abc", 0, 48);
        assertEquals(EQUAL_BIT_KEY, result);
    }

    @Test
    void testDifferenceInFirstCharReturnsCorrectBitIndex() {
        int result = analyzer.bitIndex("a", 0, 16, "b", 0, 16);
        assertEquals(14, result);
    }

    @Test
    void testOffsetNotMultipleOfLENGTHThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            analyzer.bitIndex("a", 1, 16, "a", 0, 16);
        });
    }

    @Test
    void testLengthNotMultipleOfLENGTHThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            analyzer.bitIndex("aa", 0, 15, "aa", 0, 16);
        });
    }

    @Test
    void testOtherNullTreatsCharactersAsZero() {
        int result = analyzer.bitIndex("a", 0, 16, null, 0, 0);
        assertEquals(9, result);
    }

    @Test
    void testOneKeyLongerMissingCharsTreatedAsZero() {
        int result = analyzer.bitIndex("ab", 0, 32, "a", 0, 16);
        assertEquals(25, result);
    }

    @Test
    void testAllZeroCharactersReturnNULL_BIT_KEY() {
        int result = analyzer.bitIndex("\u0000", 0, 16, "\u0000", 0, 16);
        assertEquals(NULL_BIT_KEY, result);
    }

    @Test
    void testTwoEmptyStringsReturnNULL_BIT_KEY() {
        int result = analyzer.bitIndex("", 0, 0, "", 0, 0);
        assertEquals(NULL_BIT_KEY, result);
    }

    @Test
    void testDifferentLengthWithOneEmptyReturnsDifference() {
        int result = analyzer.bitIndex("a", 0, 16, "", 0, 0);
        assertEquals(9, result);
    }

    @Test
    void testOffsetWithinStringAligned() {
        int result = analyzer.bitIndex("abc", 16, 16, "b", 0, 16);
        assertEquals(EQUAL_BIT_KEY, result);
    }

    @Test
    void testDifferenceInMiddleOfMultiCharKey() {
        int result = analyzer.bitIndex("hello", 16, 32, "hxllo", 16, 32);
        assertEquals(31, result);
    }

    @Test
    void testKeyNullCausesNullPointerException() {
        assertThrows(NullPointerException.class, () -> {
            analyzer.bitIndex(null, 0, 0, "a", 0, 16);
        });
    }
}