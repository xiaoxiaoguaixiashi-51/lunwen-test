package org.apache.commons.collections4.properties;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class OrderedPropertiesToStringTest {

    @Test
    public void test_toString_emptyMap() {
        OrderedProperties props = new OrderedProperties();
        assertEquals("{}", props.toString());
    }

    @Test
    public void test_toString_singleEntry() {
        OrderedProperties props = new OrderedProperties();
        props.put("name", "tom");
        assertEquals("{name=tom}", props.toString());
    }

    @Test
    public void test_toString_multipleEntries_orderPreserved() {
        OrderedProperties props = new OrderedProperties();
        props.put("b", "2");
        props.put("a", "1");
        props.put("c", "3");
        assertEquals("{b=2, a=1, c=3}", props.toString());
    }

    @Test
    public void test_toString_keyIsThis() {
        OrderedProperties props = new OrderedProperties();
        props.put(props, "someValue");
        assertEquals("{(this Map)=someValue}", props.toString());
    }

    @Test
    public void test_toString_valueIsThis() {
        OrderedProperties props = new OrderedProperties();
        props.put("aKey", props);
        assertEquals("{aKey=(this Map)}", props.toString());
    }

    @Test
    public void test_toString_keyAndValueAreThis() {
        OrderedProperties props = new OrderedProperties();
        props.put(props, props);
        assertEquals("{(this Map)=(this Map)}", props.toString());
    }
}