package org.apache.commons.collections4.trie;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link AbstractPatriciaTrie.TrieEntry#toString()}.
 */
public class TrieEntryToStringTest {

    @Test
    public void testNormalEntryAllRelatedNonRoot() {
        // Normal non-root entry where parent, left, right, and predecessor are all non-null and none are root
        AbstractPatriciaTrie.TrieEntry<String, String> entry =
                new AbstractPatriciaTrie.TrieEntry<>("A", "valA", 5);
        AbstractPatriciaTrie.TrieEntry<String, String> parent =
                new AbstractPatriciaTrie.TrieEntry<>("P", "parentVal", 10);
        AbstractPatriciaTrie.TrieEntry<String, String> left =
                new AbstractPatriciaTrie.TrieEntry<>("L", "leftVal", 3);
        AbstractPatriciaTrie.TrieEntry<String, String> right =
                new AbstractPatriciaTrie.TrieEntry<>("R", "rightVal", 7);
        AbstractPatriciaTrie.TrieEntry<String, String> predecessor =
                new AbstractPatriciaTrie.TrieEntry<>("Pred", "predVal", 2);

        entry.parent = parent;
        entry.left = left;
        entry.right = right;
        entry.predecessor = predecessor;

        String expected = "Entry(key=A [5], value=valA, parent=P [10], left=L [3], right=R [7], predecessor=Pred [2])";
        assertEquals(expected, entry.toString());
    }

    @Test
    public void testRootEntry() {
        // Root entry with bitIndex=-1, parent=null, left=self, right=null, predecessor=self
        AbstractPatriciaTrie.TrieEntry<String, String> root =
                new AbstractPatriciaTrie.TrieEntry<>("rootKey", "rootVal", -1);
        // Constructor already sets left=this, right=null, predecessor=this, parent=null

        String expected = "RootEntry(key=rootKey [-1], value=rootVal, parent=null, left=ROOT, right=null, predecessor=ROOT)";
        assertEquals(expected, root.toString());
    }

    @Test
    public void testParentIsRoot() {
        // Entry whose parent is the root (parent.bitIndex == -1), other children non-null and non-root
        AbstractPatriciaTrie.TrieEntry<String, String> entry =
                new AbstractPatriciaTrie.TrieEntry<>("child", "childVal", 8);
        AbstractPatriciaTrie.TrieEntry<String, String> root =
                new AbstractPatriciaTrie.TrieEntry<>("rootKey", "rootVal", -1);
        AbstractPatriciaTrie.TrieEntry<String, String> left =
                new AbstractPatriciaTrie.TrieEntry<>("leftKid", "leftVal", 3);
        AbstractPatriciaTrie.TrieEntry<String, String> right =
                new AbstractPatriciaTrie.TrieEntry<>("rightKid", "rightVal", 12);
        AbstractPatriciaTrie.TrieEntry<String, String> predecessor =
                new AbstractPatriciaTrie.TrieEntry<>("predKid", "predVal", 2);

        entry.parent = root;
        entry.left = left;
        entry.right = right;
        entry.predecessor = predecessor;

        String expected = "Entry(key=child [8], value=childVal, parent=ROOT, left=leftKid [3], right=rightKid [12], predecessor=predKid [2])";
        assertEquals(expected, entry.toString());
    }

    @Test
    public void testLeftNullAndPredecessorNull() {
        // Entry with left=null, right non-null (not root), and predecessor=null
        AbstractPatriciaTrie.TrieEntry<String, String> entry =
                new AbstractPatriciaTrie.TrieEntry<>("X", "Xval", 4);
        AbstractPatriciaTrie.TrieEntry<String, String> parent =
                new AbstractPatriciaTrie.TrieEntry<>("P", "parentVal", 10);
        AbstractPatriciaTrie.TrieEntry<String, String> right =
                new AbstractPatriciaTrie.TrieEntry<>("R", "rightVal", 7);

        entry.parent = parent;
        entry.left = null;
        entry.right = right;
        entry.predecessor = null;

        // When predecessor is null, a trailing comma remains after the right block
        String expected = "Entry(key=X [4], value=Xval, parent=P [10], left=null, right=R [7], )";
        assertEquals(expected, entry.toString());
    }

    @Test
    public void testRightNull() {
        // Entry with right=null, left non-null and predecessor non-null (non-root)
        AbstractPatriciaTrie.TrieEntry<String, String> entry =
                new AbstractPatriciaTrie.TrieEntry<>("Y", "Yval", 9);
        AbstractPatriciaTrie.TrieEntry<String, String> parent =
                new AbstractPatriciaTrie.TrieEntry<>("Yparent", "parentVal", 11);
        AbstractPatriciaTrie.TrieEntry<String, String> left =
                new AbstractPatriciaTrie.TrieEntry<>("Yleft", "leftVal", 5);
        AbstractPatriciaTrie.TrieEntry<String, String> predecessor =
                new AbstractPatriciaTrie.TrieEntry<>("Ypred", "predVal", 1);

        entry.parent = parent;
        entry.left = left;
        entry.right = null;
        entry.predecessor = predecessor;

        String expected = "Entry(key=Y [9], value=Yval, parent=Yparent [11], left=Yleft [5], right=null, predecessor=Ypred [1])";
        assertEquals(expected, entry.toString());
    }

    @Test
    public void testAllNullChildrenAndPredecessor() {
        // Entry with parent=null, left=null, right=null, predecessor=null
        AbstractPatriciaTrie.TrieEntry<String, String> entry =
                new AbstractPatriciaTrie.TrieEntry<>("Z", "Zval", 2);
        // The constructor sets left=this and predecessor=this; we need them to be null
        entry.parent = null;
        entry.left = null;
        entry.right = null;
        entry.predecessor = null;

        // Trailing comma remains when predecessor is absent
        String expected = "Entry(key=Z [2], value=Zval, parent=null, left=null, right=null, )";
        assertEquals(expected, entry.toString());
    }

    @Test
    public void testNullKeyAndValue() {
        // Entry with null key and null value, all other fields typical
        AbstractPatriciaTrie.TrieEntry<String, String> entry =
                new AbstractPatriciaTrie.TrieEntry<>(null, null, 5);
        AbstractPatriciaTrie.TrieEntry<String, String> parent =
                new AbstractPatriciaTrie.TrieEntry<>("P", "parentVal", 10);
        AbstractPatriciaTrie.TrieEntry<String, String> left =
                new AbstractPatriciaTrie.TrieEntry<>("L", "leftVal", 3);
        AbstractPatriciaTrie.TrieEntry<String, String> right =
                new AbstractPatriciaTrie.TrieEntry<>("R", "rightVal", 7);
        AbstractPatriciaTrie.TrieEntry<String, String> predecessor =
                new AbstractPatriciaTrie.TrieEntry<>("Pred", "predVal", 2);

        entry.parent = parent;
        entry.left = left;
        entry.right = right;
        entry.predecessor = predecessor;

        String expected = "Entry(key=null [5], value=null, parent=P [10], left=L [3], right=R [7], predecessor=Pred [2])";
        assertEquals(expected, entry.toString());
    }
}