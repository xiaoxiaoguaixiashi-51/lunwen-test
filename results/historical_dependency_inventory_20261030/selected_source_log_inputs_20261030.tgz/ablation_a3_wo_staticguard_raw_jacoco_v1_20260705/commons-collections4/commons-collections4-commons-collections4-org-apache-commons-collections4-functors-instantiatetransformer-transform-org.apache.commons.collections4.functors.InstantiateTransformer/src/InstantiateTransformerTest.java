package org.apache.commons.collections4.functors;

import static org.junit.jupiter.api.Assertions.*;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

import org.apache.commons.collections4.FunctorException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class InstantiateTransformerTest {

    private InstantiateTransformer<String> transformerWithValidArgs;
    private InstantiateTransformer<Object> transformerNoArgs;
    private InstantiateTransformer<Integer> transformerWithMismatchArgs;
    private InstantiateTransformer<Object> transformerForThrowing;

    @BeforeEach
    void setUp() {
        transformerWithValidArgs = new InstantiateTransformer<>(new Class<?>[]{String.class}, new Object[]{"hello"});
        transformerNoArgs = new InstantiateTransformer<>(null, null);
        transformerWithMismatchArgs = new InstantiateTransformer<>(new Class<?>[]{String.class}, new Object[]{"a"});
        transformerForThrowing = new InstantiateTransformer<>(new Class<?>[]{String.class}, new Object[]{"test"});
    }

    @Test
    void testTransformWithValidArgs() {
        String result = transformerWithValidArgs.transform(String.class);
        assertEquals("hello", result);
        assertTrue(result instanceof String);
    }

    @Test
    void testTransformNoArgs() {
        Object result = transformerNoArgs.transform(StringBuilder.class);
        assertNotNull(result);
        assertTrue(result instanceof StringBuilder);
    }

    @Test
    void testTransformInputNull() {
        FunctorException exception = assertThrows(FunctorException.class,
                () -> transformerNoArgs.transform(null));
        assertTrue(exception.getMessage().contains("Input object was not an instanceof Class, it was a null object"));
    }

    @Test
    void testTransformNoSuchMethodException() {
        FunctorException exception = assertThrows(FunctorException.class,
                () -> transformerWithMismatchArgs.transform(Integer.class));
        assertTrue(exception.getMessage().contains("The constructor must exist and be public "));
    }

    @Test
    void testTransformInstantiationException() {
        // InputStream is abstract but has a public no-arg constructor,
        // so getConstructor succeeds but newInstance throws InstantiationException.
        FunctorException exception = assertThrows(FunctorException.class,
                () -> transformerNoArgs.transform(InputStream.class));
        assertTrue(exception.getMessage().contains("InstantiationTransformer: InstantiationException"));
    }

    @Test
    void testTransformInvocationTargetException() {
        FunctorException exception = assertThrows(FunctorException.class,
                () -> transformerForThrowing.transform(ThrowingConstructor.class));
        assertTrue(exception.getMessage().contains("Constructor threw an exception"));
        assertInstanceOf(InvocationTargetException.class, exception.getCause());
    }

    /**
     * Helper class whose constructor always throws a RuntimeException.
     */
    public static class ThrowingConstructor {
        public ThrowingConstructor(String s) {
            throw new RuntimeException("from constructor");
        }
    }
}