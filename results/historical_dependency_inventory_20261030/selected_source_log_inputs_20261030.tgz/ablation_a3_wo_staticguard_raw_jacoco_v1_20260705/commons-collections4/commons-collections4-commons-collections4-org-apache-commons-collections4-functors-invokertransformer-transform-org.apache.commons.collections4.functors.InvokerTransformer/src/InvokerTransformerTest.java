package org.apache.commons.collections4.functors;

import static org.junit.Assert.*;

import org.apache.commons.collections4.FunctorException;
import org.apache.commons.collections4.Transformer;
import org.junit.Test;

/**
 * Tests for {@link InvokerTransformer}.
 */
public class InvokerTransformerTest {

    /**
     * Helper class providing methods that are called reflectively.
     */
    public static class TestObject {
        public String greet() {
            return "Hello";
        }

        public String greetWithName(String name) {
            return "Hello " + name;
        }

        public String nullable(Object obj) {
            return obj == null ? "null" : obj.toString();
        }

        public void throwing() {
            throw new RuntimeException("method error");
        }
    }

    @Test
    public void test_transform_null_input() {
        Transformer<TestObject, String> transformer = InvokerTransformer.invokerTransformer("greet");
        assertNull("Input null should return null", transformer.transform(null));
    }

    @Test
    public void test_transform_no_arg_method() {
        Transformer<TestObject, String> transformer = InvokerTransformer.invokerTransformer("greet");
        assertEquals("Hello", transformer.transform(new TestObject()));
    }

    @Test
    public void test_transform_with_args_method() {
        Transformer<TestObject, String> transformer =
                InvokerTransformer.invokerTransformer("greetWithName", new Class[]{String.class}, new Object[]{"World"});
        assertEquals("Hello World", transformer.transform(new TestObject()));
    }

    @Test
    public void test_transform_no_such_method_by_name() {
        Transformer<TestObject, String> transformer = InvokerTransformer.invokerTransformer("nonexistent");
        try {
            transformer.transform(new TestObject());
            fail("Expected FunctorException was not thrown");
        } catch (FunctorException e) {
            assertTrue("Exception message should contain 'does not exist'",
                    e.getMessage().contains("does not exist"));
        }
    }

    @Test
    public void test_transform_parameter_type_mismatch() {
        Transformer<TestObject, String> transformer =
                InvokerTransformer.invokerTransformer("greet", new Class[]{String.class}, new Object[]{"bad"});
        try {
            transformer.transform(new TestObject());
            fail("Expected FunctorException was not thrown");
        } catch (FunctorException e) {
            assertTrue("Exception message should contain 'does not exist'",
                    e.getMessage().contains("does not exist"));
        }
    }

    @Test
    public void test_transform_invocation_target_exception() {
        Transformer<TestObject, String> transformer = InvokerTransformer.invokerTransformer("throwing");
        try {
            transformer.transform(new TestObject());
            fail("Expected FunctorException was not thrown");
        } catch (FunctorException e) {
            assertTrue("Exception message should contain 'threw an exception'",
                    e.getMessage().contains("threw an exception"));
            assertNotNull("Cause should not be null", e.getCause());
            assertTrue("Cause should be RuntimeException", e.getCause() instanceof RuntimeException);
            assertEquals("method error", e.getCause().getMessage());
        }
    }

    @Test
    public void test_transform_null_args_allowed() {
        Transformer<TestObject, String> transformer =
                InvokerTransformer.invokerTransformer("nullable", new Class[]{Object.class}, new Object[]{null});
        assertEquals("null", transformer.transform(new TestObject()));
    }
}