package org.apache.commons.collections4;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Vector;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link CollectionUtils#size(Object)}.
 */
public class CollectionUtilsSizeTest {

    // Custom Iterable (non-Collection) returning 4 elements
    private static class FourElementIterable implements Iterable<String> {
        @Override
        public Iterator<String> iterator() {
            return new Iterator<String>() {
                private int remaining = 4;

                @Override
                public boolean hasNext() {
                    return remaining > 0;
                }

                @Override
                public String next() {
                    if (!hasNext()) {
                        throw new NoSuchElementException();
                    }
                    remaining--;
                    return "element-" + remaining;
                }
            };
        }
    }

    @Test
    public void testSizeWithNull() {
        assertEquals(0, CollectionUtils.size(null));
    }

    @Test
    public void testSizeWithMap() {
        Map<String, Integer> map = new HashMap<>();
        map.put("a", 1);
        map.put("b", 2);
        assertEquals(2, CollectionUtils.size(map));
    }

    @Test
    public void testSizeWithEmptyMap() {
        assertEquals(0, CollectionUtils.size(new HashMap<>()));
    }

    @Test
    public void testSizeWithCollection() {
        assertEquals(3, CollectionUtils.size(new ArrayList<>(Arrays.asList(1, 2, 3))));
    }

    @Test
    public void testSizeWithEmptyCollection() {
        assertEquals(0, CollectionUtils.size(Collections.emptyList()));
    }

    @Test
    public void testSizeWithIterableNonCollection() {
        Iterable<String> iterable = new FourElementIterable();
        assertEquals(4, CollectionUtils.size(iterable)); // delegates to IterableUtils.size()
    }

    @Test
    public void testSizeWithObjectArray() {
        assertEquals(5, CollectionUtils.size(new Object[5]));
    }

    @Test
    public void testSizeWithEmptyObjectArray() {
        assertEquals(0, CollectionUtils.size(new Object[0]));
    }

    @Test
    public void testSizeWithIterator() {
        Iterator<Integer> iterator = new ArrayList<>(Arrays.asList(1, 2)).iterator();
        assertEquals(2, CollectionUtils.size(iterator)); // delegates to IteratorUtils.size()
    }

    @Test
    public void testSizeWithEmptyIterator() {
        Iterator<?> iterator = Collections.emptyIterator();
        assertEquals(0, CollectionUtils.size(iterator));
    }

    @Test
    public void testSizeWithEnumeration() {
        Vector<Integer> vector = new Vector<>(Arrays.asList(1, 2, 3));
        Enumeration<Integer> enumeration = vector.elements();
        assertEquals(3, CollectionUtils.size(enumeration));
        // after size() call, the enumeration should be exhausted
        assertFalse(enumeration.hasMoreElements());
    }

    @Test
    public void testSizeWithEmptyEnumeration() {
        assertEquals(0, CollectionUtils.size(new Vector<>().elements()));
    }

    @Test
    public void testSizeWithPrimitiveArray() {
        assertEquals(3, CollectionUtils.size(new int[3]));
    }

    @Test
    public void testSizeWithEmptyPrimitiveArray() {
        assertEquals(0, CollectionUtils.size(new int[0]));
    }

    @Test
    public void testSizeWithUnsupportedType() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> CollectionUtils.size("hello"));
        String msg = exception.getMessage();
        assertTrue(msg.contains("Unsupported object type: java.lang.String"),
                "Message should contain the unsupported type name");
    }

    @Test
    public void testSizeWithAnotherUnsupportedType() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> CollectionUtils.size(Integer.valueOf(42)));
        String msg = exception.getMessage();
        assertTrue(msg.contains("Unsupported object type: java.lang.Integer"),
                "Message should contain the unsupported type name");
    }
}