package org.apache.commons.collections4.bag;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.LinkedHashMap;
import java.util.Set;

import org.junit.jupiter.api.Test;

public class AbstractMapBagToStringTest {

    @Test
    void testEmptyBagReturnsBrackets() {
        AbstractMapBag<String> bag = new AbstractMapBag<String>(new LinkedHashMap<>()) {};
        assertEquals("[]", bag.toString());
    }

    @Test
    void testNonEmptyBagFormat() {
        AbstractMapBag<String> bag = new AbstractMapBag<String>(new LinkedHashMap<>()) {};
        bag.add("a", 2);
        bag.add("b", 1);
        assertEquals("[2:a,1:b]", bag.toString());
    }

    @Test
    void testBagWithNullElement() {
        AbstractMapBag<String> bag = new AbstractMapBag<String>(new LinkedHashMap<>()) {};
        bag.add(null, 1);
        assertEquals("[1:null]", bag.toString());
    }

    @Test
    void testSingleElementHighCount() {
        AbstractMapBag<String> bag = new AbstractMapBag<String>(new LinkedHashMap<>()) {};
        bag.add("x", 5);
        assertEquals("[5:x]", bag.toString());
    }

    @Test
    void testOrderMatchesUniqueSetIteration() {
        AbstractMapBag<String> bag = new AbstractMapBag<String>(new LinkedHashMap<>()) {};
        bag.add("z", 1);
        bag.add("a", 3);
        bag.add("m", 2);
        assertEquals("[1:z,3:a,2:m]", bag.toString());
    }

    @Test
    void testEmptyBagDoesNotCallUniqueSet() {
        AbstractMapBag<String> bag = new AbstractMapBag<String>(new LinkedHashMap<>()) {
            @Override
            public boolean isEmpty() {
                return true;
            }

            @Override
            public Set<String> uniqueSet() {
                throw new AssertionError("uniqueSet should not be called when bag is empty");
            }
        };
        assertEquals("[]", bag.toString());
    }
}