package org.apache.commons.collections4;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

import java.util.*;

import org.apache.commons.collections4.iterators.*;
import org.junit.jupiter.api.Test;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.UserDataHandler;

public class IteratorUtilsTest {

    // Support classes for reflection-based tests
    public static class WithIteratorMethod {
        public Iterator<String> iterator() {
            return Arrays.asList("x").iterator();
        }
    }

    public static class WithIteratorReturningString {
        public String iterator() {
            return "anything";
        }
    }

    public static class WithIteratorReturningNull {
        public Iterator<String> iterator() {
            return null;
        }
    }

    public static class WithIteratorThrowingException {
        public Iterator<String> iterator() {
            throw new RuntimeException("error");
        }
    }

    // Simple implementations for DOM testing
    private static class SimpleNodeList implements NodeList {
        private final List<Node> nodes = new ArrayList<>();
        public SimpleNodeList(Node... nodes) {
            Collections.addAll(this.nodes, nodes);
        }
        @Override
        public Node item(int index) {
            if (index < 0 || index >= nodes.size()) return null;
            return nodes.get(index);
        }
        @Override
        public int getLength() {
            return nodes.size();
        }
    }

    private static class SimpleNode implements Node {
        private final NodeList childNodes;
        public SimpleNode(NodeList childNodes) {
            this.childNodes = childNodes;
        }
        @Override
        public String getNodeName() { return null; }
        @Override
        public String getNodeValue() throws DOMException { return null; }
        @Override
        public void setNodeValue(String nodeValue) throws DOMException {}
        @Override
        public short getNodeType() { return 0; }
        @Override
        public Node getParentNode() { return null; }
        @Override
        public NodeList getChildNodes() { return childNodes; }
        @Override
        public Node getFirstChild() { return null; }
        @Override
        public Node getLastChild() { return null; }
        @Override
        public Node getPreviousSibling() { return null; }
        @Override
        public Node getNextSibling() { return null; }
        @Override
        public NamedNodeMap getAttributes() { return null; }
        @Override
        public Document getOwnerDocument() { return null; }
        @Override
        public Node insertBefore(Node newChild, Node refChild) throws DOMException { return null; }
        @Override
        public Node replaceChild(Node newChild, Node oldChild) throws DOMException { return null; }
        @Override
        public Node removeChild(Node oldChild) throws DOMException { return null; }
        @Override
        public Node appendChild(Node newChild) throws DOMException { return null; }
        @Override
        public boolean hasChildNodes() {
            return childNodes != null && childNodes.getLength() > 0;
        }
        @Override
        public Node cloneNode(boolean deep) { return null; }
        @Override
        public void normalize() {}
        @Override
        public boolean isSupported(String feature, String version) { return false; }
        @Override
        public String getNamespaceURI() { return null; }
        @Override
        public String getPrefix() { return null; }
        @Override
        public void setPrefix(String prefix) throws DOMException {}
        @Override
        public String getLocalName() { return null; }
        @Override
        public boolean hasAttributes() { return false; }
        @Override
        public String getBaseURI() { return null; }
        @Override
        public short compareDocumentPosition(Node other) throws DOMException { return 0; }
        @Override
        public String getTextContent() throws DOMException { return null; }
        @Override
        public void setTextContent(String textContent) throws DOMException {}
        @Override
        public boolean isSameNode(Node other) { return false; }
        @Override
        public String lookupPrefix(String namespaceURI) { return null; }
        @Override
        public boolean isDefaultNamespace(String namespaceURI) { return false; }
        @Override
        public String lookupNamespaceURI(String prefix) { return null; }
        @Override
        public boolean isEqualNode(Node arg) { return false; }
        @Override
        public Object getFeature(String feature, String version) { return null; }
        @Override
        public Object setUserData(String key, Object data, UserDataHandler handler) { return null; }
        @Override
        public Object getUserData(String key) { return null; }
    }

    @Test
    void test_null_returns_emptyIterator() {
        Iterator<?> result = IteratorUtils.getIterator(null);
        assertNotNull(result);
        assertFalse(result.hasNext());
    }

    @Test
    void test_Iterator_instance_returns_same_object() {
        Iterator<String> original = new ArrayList<String>().iterator();
        Iterator<?> result = IteratorUtils.getIterator(original);
        assertSame(original, result);
    }

    @Test
    void test_Iterable_returns_iterator_from_iterable() {
        List<String> list = Arrays.asList("a", "b");
        Iterator<?> result = IteratorUtils.getIterator(list);
        assertNotNull(result);
        List<String> extracted = new ArrayList<>();
        while (result.hasNext()) {
            extracted.add((String) result.next());
        }
        assertEquals(Arrays.asList("a", "b"), extracted);
    }

    @Test
    void test_Object_array_returns_ObjectArrayIterator() {
        String[] array = { "x", "y" };
        Iterator<?> result = IteratorUtils.getIterator(array);
        assertInstanceOf(ObjectArrayIterator.class, result);
        List<String> extracted = new ArrayList<>();
        while (result.hasNext()) {
            extracted.add((String) result.next());
        }
        assertEquals(Arrays.asList("x", "y"), extracted);
    }

    @Test
    void test_Enumeration_returns_EnumerationIterator() {
        Enumeration<Integer> enumeration = Collections.enumeration(Arrays.asList(1, 2));
        Iterator<?> result = IteratorUtils.getIterator(enumeration);
        assertInstanceOf(EnumerationIterator.class, result);
        List<Integer> extracted = new ArrayList<>();
        while (result.hasNext()) {
            extracted.add((Integer) result.next());
        }
        assertEquals(Arrays.asList(1, 2), extracted);
    }

    @Test
    void test_Map_returns_values_iterator() {
        Map<String, String> map = Collections.singletonMap("key", "val");
        Iterator<?> result = IteratorUtils.getIterator(map);
        assertNotNull(result);
        List<String> values = new ArrayList<>();
        while (result.hasNext()) {
            values.add((String) result.next());
        }
        assertEquals(Collections.singletonList("val"), values);
    }

    @Test
    void test_NodeList_returns_NodeListIterator() {
        Node mockNode = new SimpleNode(null);
        NodeList nodeList = new SimpleNodeList(mockNode);
        Iterator<?> result = IteratorUtils.getIterator(nodeList);
        assertInstanceOf(NodeListIterator.class, result);
        assertTrue(result.hasNext());
        assertNotNull(result.next());
        assertFalse(result.hasNext());
    }

    @Test
    void test_Node_returns_NodeListIterator_from_childNodes() {
        Node child1 = new SimpleNode(null);
        Node child2 = new SimpleNode(null);
        NodeList childNodes = new SimpleNodeList(child1, child2);
        Node node = new SimpleNode(childNodes);
        Iterator<?> result = IteratorUtils.getIterator(node);
        assertInstanceOf(NodeListIterator.class, result);
        assertTrue(result.hasNext());
        assertNotNull(result.next());
        assertTrue(result.hasNext());
        assertNotNull(result.next());
        assertFalse(result.hasNext());
    }
}