/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4.functors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;

import org.apache.commons.collections4.Factory;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link PrototypeFactory#prototypeFactory(Object)}.
 */
public class PrototypeFactoryTest {

    /**
     * A test bean that implements Cloneable and provides a public clone method.
     */
    static class CloneablePerson implements Cloneable {
        private final String name;

        CloneablePerson(final String name) {
            this.name = name;
        }

        @Override
        public CloneablePerson clone() {
            try {
                return (CloneablePerson) super.clone();
            } catch (final CloneNotSupportedException e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof CloneablePerson)) {
                return false;
            }
            final CloneablePerson other = (CloneablePerson) obj;
            return name != null ? name.equals(other.name) : other.name == null;
        }

        @Override
        public int hashCode() {
            return name != null ? name.hashCode() : 0;
        }
    }

    /**
     * A test bean that has a public copy constructor but no clone method.
     */
    static class CopiableNoClone {
        private final String data;

        CopiableNoClone(final String data) {
            this.data = data;
        }

        /**
         * Copy constructor.
         */
        public CopiableNoClone(final CopiableNoClone other) {
            this.data = other.data;
        }

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof CopiableNoClone)) {
                return false;
            }
            final CopiableNoClone other = (CopiableNoClone) obj;
            return data != null ? data.equals(other.data) : other.data == null;
        }

        @Override
        public int hashCode() {
            return data != null ? data.hashCode() : 0;
        }
    }

    /**
     * A test bean that only implements Serializable; no clone method or copy constructor.
     */
    static class SerializableOnly implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int value = 42;

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof SerializableOnly)) {
                return false;
            }
            final SerializableOnly other = (SerializableOnly) obj;
            return value == other.value;
        }

        @Override
        public int hashCode() {
            return value;
        }
    }

    @Test
    public void testPrototypeFactoryWhenPrototypeIsNull() {
        final Factory<?> factory = PrototypeFactory.prototypeFactory(null);
        assertSame(ConstantFactory.NULL_INSTANCE, factory);
        assertNull(factory.create());
    }

    @Test
    public void testPrototypeFactoryWithPublicCloneMethod() {
        final CloneablePerson prototype = new CloneablePerson("John");
        final Factory<CloneablePerson> factory = PrototypeFactory.prototypeFactory(prototype);
        assertTrue(factory instanceof PrototypeFactory.PrototypeCloneFactory);
        final CloneablePerson created = factory.create();
        assertNotSame(prototype, created);
        assertEquals(prototype, created);
    }

    @Test
    public void testPrototypeFactoryWithCopyConstructor() {
        final CopiableNoClone prototype = new CopiableNoClone("data");
        final Factory<CopiableNoClone> factory = PrototypeFactory.prototypeFactory(prototype);
        assertTrue(factory instanceof InstantiateFactory);
        final CopiableNoClone created = factory.create();
        assertNotSame(prototype, created);
        assertEquals(prototype, created);
    }

    @Test
    public void testPrototypeFactoryWithSerializableOnly() {
        final SerializableOnly prototype = new SerializableOnly();
        final Factory<SerializableOnly> factory = PrototypeFactory.prototypeFactory(prototype);
        assertTrue(factory instanceof PrototypeFactory.PrototypeSerializationFactory);
        final SerializableOnly created = factory.create();
        assertNotSame(prototype, created);
        assertEquals(prototype, created);
    }

    @Test
    public void testPrototypeFactoryThrowsForNonCloneable() {
        final Object prototype = new Object();
        final IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> PrototypeFactory.prototypeFactory(prototype));
        assertTrue(exception.getMessage().contains("public clone method"));
    }
}