/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4.iterators;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link CartesianProductIterator}.
 */
public class CartesianProductIteratorTest {

    private static <E> List<E> list(E... elements) {
        return Arrays.asList(elements);
    }

    // -----------------------------------------------------------------------
    @Test
    public void testBasicProduct() {
        final List<String> iterable1 = list("A", "B");
        final List<String> iterable2 = list("1", "2");
        final CartesianProductIterator<String> it = new CartesianProductIterator<>(iterable1, iterable2);

        assertTrue(it.hasNext());
        assertEquals(list("A", "1"), it.next());

        assertTrue(it.hasNext());
        assertEquals(list("A", "2"), it.next());

        assertTrue(it.hasNext());
        assertEquals(list("B", "1"), it.next());

        assertTrue(it.hasNext());
        assertEquals(list("B", "2"), it.next());

        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    public void testSingleIterable() {
        final List<String> iterable = list("P", "Q", "R");
        final CartesianProductIterator<String> it = new CartesianProductIterator<>(iterable);

        assertTrue(it.hasNext());
        assertEquals(list("P"), it.next());

        assertTrue(it.hasNext());
        assertEquals(list("Q"), it.next());

        assertTrue(it.hasNext());
        assertEquals(list("R"), it.next());

        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    public void testCarryOverWhenRightExhausted() {
        final List<String> iterable1 = list("X", "Y");
        final List<String> iterable2 = list("1");
        final CartesianProductIterator<String> it = new CartesianProductIterator<>(iterable1, iterable2);

        assertTrue(it.hasNext());
        assertEquals(list("X", "1"), it.next());

        assertTrue(it.hasNext());
        assertEquals(list("Y", "1"), it.next());

        assertFalse(it.hasNext());
    }

    @Test
    public void testThreeIterables() {
        final List<String> iterable1 = list("A", "B");
        final List<String> iterable2 = list("1", "2");
        final List<String> iterable3 = list("x", "y");
        final CartesianProductIterator<String> it = new CartesianProductIterator<>(iterable1, iterable2, iterable3);

        final List<List<String>> expected = list(
                list("A", "1", "x"),
                list("A", "1", "y"),
                list("A", "2", "x"),
                list("A", "2", "y"),
                list("B", "1", "x"),
                list("B", "1", "y"),
                list("B", "2", "x"),
                list("B", "2", "y")
        );
        final List<List<String>> actual = new ArrayList<>();
        while (it.hasNext()) {
            actual.add(it.next());
        }
        assertEquals(expected, actual);
    }

    @Test
    public void testEmptyIterableYieldsNoProduct() {
        final List<String> iterable1 = list("A", "B");
        final List<String> emptyIterable = list();
        final CartesianProductIterator<String> it = new CartesianProductIterator<>(iterable1, emptyIterable);

        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    public void testReturnedListIsDefensiveCopy() {
        final List<String> iterable1 = list("A", "B");
        final List<String> iterable2 = list("1", "2");
        final CartesianProductIterator<String> it = new CartesianProductIterator<>(iterable1, iterable2);

        final List<String> first = it.next();
        first.clear(); // attempt to corrupt internal state via returned list
        final List<String> second = it.next();
        assertEquals(list("A", "2"), second); // should not be affected by clearing first list
    }

    @Test
    public void testNextAfterExhaustionThrows() {
        final List<String> iterable = list("X", "Y");
        final CartesianProductIterator<String> it = new CartesianProductIterator<>(iterable);

        assertDoesNotThrow(() -> {
            it.next();
            it.next();
        });
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    public void testRemoveThrowsUnsupportedOperation() {
        final CartesianProductIterator<String> it = new CartesianProductIterator<>(list("A"));
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    @Test
    public void testIllegalStateExceptionViaCorruptedState() throws Exception {
        // construct an iterator with a single non-empty iterable, overriding hasNext to always return true
        final CartesianProductIterator<String> it = new CartesianProductIterator<String>(list("A", "B")) {
            @Override
            public boolean hasNext() {
                return true;
            }
        };

        // corrupt internal state: empty iterators list, but non-null previousTuple
        final Field iteratorsField = CartesianProductIterator.class.getDeclaredField("iterators");
        iteratorsField.setAccessible(true);
        iteratorsField.set(it, new ArrayList<>());

        final Field previousTupleField = CartesianProductIterator.class.getDeclaredField("previousTuple");
        previousTupleField.setAccessible(true);
        final List<String> fakeTuple = new ArrayList<>();
        fakeTuple.add("dummy"); // size must match number of iterables (which is 1)
        previousTupleField.set(it, fakeTuple);

        // next() should fail to find any iterator, fall through to the unreachable throw
        assertThrows(IllegalStateException.class, it::next);
    }
}