import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.apache.commons.collections4.CollectionUtils;
import org.junit.jupiter.api.Test;

public class CollectionUtilsRemoveCountTest {

    @Test
    public void testRemoveCount_NormalMiddleRemoval() {
        Collection<String> input = new ArrayList<>(Arrays.asList("A", "B", "C", "D", "E"));
        int startIndex = 1;
        int count = 2;

        Collection<String> result = CollectionUtils.removeCount(input, startIndex, count);

        assertEquals(Arrays.asList("B", "C"), result, "返回的移除元素集合应与预期一致");
        assertEquals(Arrays.asList("A", "D", "E"), input, "原集合中剩余元素应与预期一致");
        assertEquals(3, input.size(), "原集合大小应为 3");
    }

    @Test
    public void testRemoveCount_RemoveAllFromStart() {
        Collection<String> input = new ArrayList<>(Arrays.asList("X", "Y", "Z"));
        int startIndex = 0;
        int count = 3;

        Collection<String> result = CollectionUtils.removeCount(input, startIndex, count);

        assertEquals(Arrays.asList("X", "Y", "Z"), result, "返回的移除元素集合应为全部元素");
        assertTrue(input.isEmpty(), "原集合应变空");
    }

    @Test
    public void testRemoveCount_RemoveFromEnd() {
        Collection<Integer> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
        int startIndex = 2;
        int count = 2;

        Collection<Integer> result = CollectionUtils.removeCount(input, startIndex, count);

        assertEquals(Arrays.asList(3, 4), result, "返回的移除元素集合应为 [3, 4]");
        assertEquals(Arrays.asList(1, 2), input, "原集合剩余 [1, 2]");
    }

    @Test
    public void testRemoveCount_CountZeroNoRemoval() {
        Collection<Integer> input = new ArrayList<>(Arrays.asList(1, 2, 3));
        int startIndex = 1;
        int count = 0;

        Collection<Integer> result = CollectionUtils.removeCount(input, startIndex, count);

        assertTrue(result.isEmpty(), "返回集合应为空");
        assertEquals(Arrays.asList(1, 2, 3), input, "原集合保持不变");
    }

    @Test
    public void testRemoveCount_StartIndexEqualsSizeAndCountZero() {
        Collection<String> input = new ArrayList<>(Arrays.asList("A"));
        int startIndex = 1;
        int count = 0;

        Collection<String> result = CollectionUtils.removeCount(input, startIndex, count);

        assertTrue(result.isEmpty(), "返回空集合");
        assertEquals(Arrays.asList("A"), input, "原集合不变");
    }

    @Test
    public void testRemoveCount_InputNullThrowsNPE() {
        Collection<String> input = null;
        int startIndex = 0;
        int count = 1;

        assertThrows(NullPointerException.class, () -> CollectionUtils.removeCount(input, startIndex, count));
    }

    @Test
    public void testRemoveCount_StartIndexNegativeThrowsIOOBE() {
        Collection<Integer> input = new ArrayList<>(Arrays.asList(1));
        int startIndex = -1;
        int count = 1;

        assertThrows(IndexOutOfBoundsException.class, () -> CollectionUtils.removeCount(input, startIndex, count));
    }

    @Test
    public void testRemoveCount_CountNegativeThrowsIOOBE() {
        Collection<Integer> input = new ArrayList<>(Arrays.asList(1));
        int startIndex = 0;
        int count = -1;

        assertThrows(IndexOutOfBoundsException.class, () -> CollectionUtils.removeCount(input, startIndex, count));
    }

    @Test
    public void testRemoveCount_SumExceedsSizeThrowsIOOBE() {
        Collection<Integer> input = new ArrayList<>(Arrays.asList(1, 2, 3));
        int startIndex = 2;
        int count = 2;

        assertThrows(IndexOutOfBoundsException.class, () -> CollectionUtils.removeCount(input, startIndex, count));
    }

    @Test
    public void testRemoveCount_RemoveFirstElement() {
        Collection<Integer> input = new ArrayList<>(Arrays.asList(10, 20, 30));
        int startIndex = 0;
        int count = 1;

        Collection<Integer> result = CollectionUtils.removeCount(input, startIndex, count);

        assertEquals(Arrays.asList(10), result, "返回集合包含第一个元素");
        assertEquals(Arrays.asList(20, 30), input, "原集合移除第一个元素");
    }

    @Test
    public void testRemoveCount_RemoveLastElement() {
        Collection<Integer> input = new ArrayList<>(Arrays.asList(10, 20, 30));
        int startIndex = 2;
        int count = 1;

        Collection<Integer> result = CollectionUtils.removeCount(input, startIndex, count);

        assertEquals(Arrays.asList(30), result, "返回集合包含最后一个元素");
        assertEquals(Arrays.asList(10, 20), input, "原集合移除最后一个元素");
    }

    @Test
    public void testRemoveCount_StartIndexZeroCountZero() {
        Collection<Integer> input = new ArrayList<>(Arrays.asList(1, 2, 3));
        int startIndex = 0;
        int count = 0;

        Collection<Integer> result = CollectionUtils.removeCount(input, startIndex, count);

        assertTrue(result.isEmpty());
        assertEquals(Arrays.asList(1, 2, 3), input, "原集合不变");
    }
}