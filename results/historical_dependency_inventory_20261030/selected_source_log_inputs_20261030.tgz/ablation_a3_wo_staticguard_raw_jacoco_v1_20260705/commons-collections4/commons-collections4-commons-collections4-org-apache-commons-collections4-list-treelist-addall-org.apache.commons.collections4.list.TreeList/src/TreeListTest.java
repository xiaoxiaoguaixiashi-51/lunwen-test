package org.apache.commons.collections4.list;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

import org.junit.jupiter.api.Test;

public class TreeListTest {

    /**
     * Helper to get the root of a TreeList using reflection.
     */
    private static <E> TreeList.AVLNode<E> getRoot(TreeList<E> list) {
        try {
            Field rootField = TreeList.class.getDeclaredField("root");
            rootField.setAccessible(true);
            return (TreeList.AVLNode<E>) rootField.get(list);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Helper to call the private method getLeftSubTree() via reflection.
     */
    private static <E> TreeList.AVLNode<E> getLeftSubTree(TreeList.AVLNode<E> node) {
        try {
            Method method = TreeList.AVLNode.class.getDeclaredMethod("getLeftSubTree");
            method.setAccessible(true);
            return (TreeList.AVLNode<E>) method.invoke(node);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Helper to call the private method getRightSubTree() via reflection.
     */
    private static <E> TreeList.AVLNode<E> getRightSubTree(TreeList.AVLNode<E> node) {
        try {
            Method method = TreeList.AVLNode.class.getDeclaredMethod("getRightSubTree");
            method.setAccessible(true);
            return (TreeList.AVLNode<E>) method.invoke(node);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Computes the height of a subtree rooted at the given node.
     * A null node has height -1.
     */
    private static <E> int calculateHeight(TreeList.AVLNode<E> node) {
        if (node == null) {
            return -1;
        }
        return 1 + Math.max(calculateHeight(getLeftSubTree(node)), calculateHeight(getRightSubTree(node)));
    }

    /**
     * Verifies that the subtree rooted at the given node satisfies the AVL
     * balance condition (balance factor in {-1, 0, 1}) for every node.
     */
    private static <E> boolean isAVLBalanced(TreeList.AVLNode<E> node) {
        if (node == null) {
            return true;
        }
        int leftHeight = calculateHeight(getLeftSubTree(node));
        int rightHeight = calculateHeight(getRightSubTree(node));
        if (Math.abs(leftHeight - rightHeight) > 1) {
            return false;
        }
        return isAVLBalanced(getLeftSubTree(node)) && isAVLBalanced(getRightSubTree(node));
    }

    /**
     * Convenience method to create a TreeList from varargs.
     */
    @SafeVarargs
    private static <E> TreeList<E> treeListOf(E... elements) {
        return new TreeList<>(Arrays.asList(elements));
    }

    @Test
    public void testAddAllEmptyCollectionToNonEmptyList() {
        TreeList<Integer> list = treeListOf(1, 2, 3);
        boolean result = list.addAll(Collections.emptyList());
        assertFalse(result);
        assertEquals(3, list.size());
        assertArrayEquals(new Integer[]{1, 2, 3}, list.toArray());
    }

    @Test
    public void testAddAllNonEmptyCollectionToEmptyList() {
        TreeList<Integer> list = new TreeList<>();
        boolean result = list.addAll(Arrays.asList(5, 2, 7));
        assertTrue(result);
        assertEquals(3, list.size());
        assertArrayEquals(new Integer[]{5, 2, 7}, list.toArray());
    }

    @Test
    public void testAddAllNullCollectionThrowsNullPointerException() {
        TreeList<Integer> list = treeListOf(1);
        assertThrows(NullPointerException.class, () -> list.addAll(null));
    }

    @Test
    public void testMergeEqualHeightTrees() {
        TreeList<Integer> list = treeListOf(2, 1, 3);
        list.addAll(Arrays.asList(5, 4, 6));
        assertEquals(6, list.size());
        assertArrayEquals(new Integer[]{2, 1, 3, 5, 4, 6}, list.toArray());
        assertTrue(isAVLBalanced(getRoot(list)), "Tree should be AVL balanced after merging equal heights");
    }

    @Test
    public void testMergeShorterTreeIntoHigherTree() {
        TreeList<Integer> list = treeListOf(0);
        List<Integer> tallSorted = new ArrayList<>();
        for (int i = 1; i <= 7; i++) {
            tallSorted.add(i);
        }
        list.addAll(tallSorted);
        assertEquals(8, list.size());
        Integer[] expected = new Integer[]{0, 1, 2, 3, 4, 5, 6, 7};
        assertArrayEquals(expected, list.toArray(), "Elements should be appended at the end");
        assertTrue(isAVLBalanced(getRoot(list)), "Tree must remain AVL balanced");
    }

    @Test
    public void testMergeHigherTreeIntoShorterTree() {
        TreeList<Integer> list = treeListOf(10, 5, 15, 2, 7, 12, 17);
        list.addAll(Collections.singletonList(1));
        assertEquals(8, list.size());
        // Appending 1 at the end preserving original order
        Integer[] expected = new Integer[]{10, 5, 15, 2, 7, 12, 17, 1};
        assertArrayEquals(expected, list.toArray());
        assertTrue(isAVLBalanced(getRoot(list)), "Tree must be AVL balanced");
    }

    @Test
    public void testMergeSingleNodeFromOtherTree() {
        TreeList<Integer> list = treeListOf(20, 10, 30);
        list.addAll(Collections.singletonList(5));
        assertEquals(4, list.size());
        // 5 is appended at the end, so it becomes the last element
        assertEquals(Integer.valueOf(20), list.get(0));
        assertEquals(Integer.valueOf(5), list.get(3));
        assertTrue(isAVLBalanced(getRoot(list)), "Tree must be AVL balanced");
    }

    @Test
    public void testMergeThisTreeSingleNodeIntoOtherTree() {
        TreeList<Integer> list = treeListOf(100);
        list.addAll(Arrays.asList(50, 40, 60));
        assertEquals(4, list.size());
        Integer[] expected = new Integer[]{100, 50, 40, 60};
        assertArrayEquals(expected, list.toArray(), "Elements should be appended in the given order");
        assertTrue(isAVLBalanced(getRoot(list)), "Tree must be AVL balanced");
    }

    @Test
    public void testMergePreservesPredecessorSuccessorLinks() {
        TreeList<Integer> list = treeListOf(3, 1, 2);
        list.addAll(Arrays.asList(6, 4, 5));
        assertEquals(6, list.size());

        ListIterator<Integer> it = list.listIterator();
        List<Integer> forward = new ArrayList<>();
        while (it.hasNext()) {
            forward.add(it.next());
        }
        assertEquals(Arrays.asList(3, 1, 2, 6, 4, 5), forward, "Forward traversal order is wrong");

        List<Integer> backward = new ArrayList<>();
        while (it.hasPrevious()) {
            backward.add(it.previous());
        }
        assertEquals(Arrays.asList(5, 4, 6, 2, 1, 3), backward, "Backward traversal order is wrong");
    }

    @Test
    public void testMergeLargeCollectionStressTest() {
        List<Integer> first5000 = new ArrayList<>();
        for (int i = 0; i < 5000; i++) {
            first5000.add(i);
        }
        TreeList<Integer> list = new TreeList<>(first5000);

        List<Integer> next5000 = new ArrayList<>();
        for (int i = 5000; i < 10000; i++) {
            next5000.add(i);
        }
        list.addAll(next5000);

        assertEquals(10000, list.size());

        assertEquals(Integer.valueOf(0), list.get(0));
        assertEquals(Integer.valueOf(9999), list.get(9999));
        assertEquals(Integer.valueOf(5000), list.get(5000));
        assertEquals(Integer.valueOf(100), list.get(100));

        int height = calculateHeight(getRoot(list));
        double log2n = Math.log(10000) / Math.log(2);
        assertTrue(height <= 2 * log2n + 2,
                "Tree height should be O(log n); got " + height + " for n=10000");
    }
}