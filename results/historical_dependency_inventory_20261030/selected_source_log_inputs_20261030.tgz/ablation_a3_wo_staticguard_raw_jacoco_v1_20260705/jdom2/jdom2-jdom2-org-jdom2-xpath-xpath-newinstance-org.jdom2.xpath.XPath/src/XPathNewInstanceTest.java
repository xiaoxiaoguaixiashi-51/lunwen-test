package org.jdom2.xpath;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.List;

import org.jdom2.JDOMException;
import org.jdom2.Namespace;

/**
 * Tests for {@link XPath#newInstance(String)} method.
 * <p>
 * This test class uses plain Java assertions and does not depend on
 * any external testing framework (like JUnit or Mockito). It can be
 * executed by calling {@link #main(String[])}.
 */
public class XPathNewInstanceTest {

    // ---------------------------------------------------------------
    // Concrete subclasses used in tests
    // ---------------------------------------------------------------

    /**
     * A simple XPath implementation that records the expression
     * and returns it via {@code getXPath()}.
     */
    public static class TestXPath extends XPath {
        private final String expression;

        public TestXPath(String expr) {
            this.expression = expr;
        }

        @Override
        public String getXPath() {
            return expression;
        }

        @Override
        public List<?> selectNodes(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object selectSingleNode(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String valueOf(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Number numberValueOf(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setVariable(String name, Object value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void addNamespace(Namespace namespace) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * An XPath implementation whose constructor throws a JDOMException
     * (configurable via a static field).
     */
    public static class FaultyJDOMXPath extends XPath {
        public static JDOMException exceptionToThrow;

        public FaultyJDOMXPath(String expr) throws JDOMException {
            if (exceptionToThrow != null) {
                throw exceptionToThrow;
            }
        }

        @Override
        public String getXPath() {
            return null;
        }

        @Override
        public List<?> selectNodes(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object selectSingleNode(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String valueOf(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Number numberValueOf(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setVariable(String name, Object value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void addNamespace(Namespace namespace) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * An XPath implementation whose constructor throws a RuntimeException
     * (configurable via a static field).
     */
    public static class FaultyRuntimeXPath extends XPath {
        public static RuntimeException runtimeExceptionToThrow;

        public FaultyRuntimeXPath(String expr) {
            if (runtimeExceptionToThrow != null) {
                throw runtimeExceptionToThrow;
            }
        }

        @Override
        public String getXPath() {
            return null;
        }

        @Override
        public List<?> selectNodes(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object selectSingleNode(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String valueOf(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Number numberValueOf(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setVariable(String name, Object value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void addNamespace(Namespace namespace) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * A concrete XPath subclass that does not provide a public
     * {@code (String)} constructor, used to provoke a
     * {@link NoSuchMethodException} during {@link Class#getConstructor}.
     */
    public static class NoStringCtorXPath extends XPath {
        public NoStringCtorXPath() { /* intentionally no String constructor */ }

        @Override
        public String getXPath() {
            return null;
        }

        @Override
        public List<?> selectNodes(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object selectSingleNode(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String valueOf(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Number numberValueOf(Object context) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setVariable(String name, Object value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void addNamespace(Namespace namespace) {
            throw new UnsupportedOperationException();
        }
    }

    // ---------------------------------------------------------------
    // Test isolation helpers
    // ---------------------------------------------------------------

    private void setConstructorField(Object value) throws Exception {
        Field field = XPath.class.getDeclaredField("constructor");
        field.setAccessible(true);
        field.set(null, value);
    }

    /**
     * Resets the static {@code constructor} field in {@link XPath}
     * and the static exception fields in the faulty classes.
     */
    private void setUp() throws Exception {
        setConstructorField(null);
        FaultyJDOMXPath.exceptionToThrow = null;
        FaultyRuntimeXPath.runtimeExceptionToThrow = null;
    }

    private void tearDown() throws Exception {
        setConstructorField(null);
        FaultyJDOMXPath.exceptionToThrow = null;
        FaultyRuntimeXPath.runtimeExceptionToThrow = null;
    }

    // ---------------------------------------------------------------
    // Custom assertion helpers
    // ---------------------------------------------------------------

    private static void fail(String message) {
        throw new AssertionError(message);
    }

    private static void assertNotNull(Object obj, String message) {
        if (obj == null) fail(message != null ? message : "expected non-null value");
    }

    private static void assertNull(Object obj, String message) {
        if (obj != null) fail(message != null ? message : "expected null value");
    }

    private static void assertEquals(String expected, String actual, String message) {
        if (expected == null) {
            if (actual != null) fail(message != null ? message : "expected null but was " + actual);
        } else if (!expected.equals(actual)) {
            fail(message != null ? message : "expected <" + expected + "> but was <" + actual + ">");
        }
    }

    private static void assertTrue(boolean condition, String message) {
        if (!condition) fail(message != null ? message : "condition is false");
    }

    /**
     * Asserts that the given runnable throws an exception of the specified type.
     * Returns the caught exception for further inspection.
     */
    private static <T extends Throwable> T assertThrows(Class<T> expectedType, ThrowingRunnable runnable, String message) {
        try {
            runnable.run();
        } catch (Throwable t) {
            if (expectedType.isInstance(t)) {
                return expectedType.cast(t);
            }
            throw new AssertionError(message != null ? message : 
                "expected " + expectedType.getName() + " but caught " + t.getClass().getName(), t);
        }
        throw new AssertionError(message != null ? message : 
            "expected " + expectedType.getName() + " but no exception was thrown");
    }

    private static void assertDoesNotThrow(ThrowingRunnable runnable, String message) {
        try {
            runnable.run();
        } catch (Throwable t) {
            throw new AssertionError(message != null ? message : 
                "unexpected exception thrown: " + t.toString(), t);
        }
    }

    @FunctionalInterface
    private interface ThrowingRunnable {
        void run() throws Throwable;
    }

    // ---------------------------------------------------------------
    // Test methods
    // ---------------------------------------------------------------

    private void testNewInstance_Success() throws Exception {
        setUp();
        try {
            XPath.setXPathClass(TestXPath.class);
            XPath xpath = XPath.newInstance("//test");
            assertNotNull(xpath, "newInstance should return non-null");
            assertEquals("//test", xpath.getXPath(), "expression mismatch");
        } finally {
            tearDown();
        }
    }

    private void testNewInstance_ConstructorThrowsJDOMException() throws Exception {
        setUp();
        try {
            FaultyJDOMXPath.exceptionToThrow = new JDOMException("test error");
            assertThrows(JDOMException.class, () -> {
                XPath.setXPathClass(FaultyJDOMXPath.class);
                XPath.newInstance("expr");
            }, "Expected JDOMException when constructor throws JDOMException");
        } finally {
            tearDown();
        }
    }

    private void testNewInstance_ConstructorThrowsRuntimeException() throws Exception {
        setUp();
        try {
            RuntimeException re = new RuntimeException("runtime error");
            FaultyRuntimeXPath.runtimeExceptionToThrow = re;
            JDOMException thrown = assertThrows(JDOMException.class, () -> {
                XPath.setXPathClass(FaultyRuntimeXPath.class);
                XPath.newInstance("expr");
            }, "Expected JDOMException when constructor throws RuntimeException");
            assertTrue(thrown.getMessage().contains("runtime error"),
                    "Message should contain the original exception message");
        } finally {
            tearDown();
        }
    }

    private void testNewInstance_DefaultClassResolutionFailure() throws Exception {
        setUp();
        // Ensure constructor is null so that newInstance tries to load the class.
        setConstructorField(null);
        String originalProperty = null;
        try {
            originalProperty = System.getProperty("org.jdom2.xpath.class");
            // Set a non-existent class name via system property.
            System.setProperty("org.jdom2.xpath.class", "com.nonexistent.Class");
            assertThrows(JDOMException.class, () -> {
                XPath.newInstance("expr");
            }, "Expected JDOMException for invalid class");
        } finally {
            // Restore original property
            if (originalProperty == null) {
                System.clearProperty("org.jdom2.xpath.class");
            } else {
                System.setProperty("org.jdom2.xpath.class", originalProperty);
            }
            tearDown();
        }
    }

    private void testNewInstance_PathIsNull() throws Exception {
        setUp();
        try {
            XPath.setXPathClass(TestXPath.class);
            assertDoesNotThrow(() -> {
                XPath xpath = XPath.newInstance(null);
                assertNull(xpath.getXPath(), "expression should be null");
            }, "null path should not cause exception");
        } finally {
            tearDown();
        }
    }

    // ---------------------------------------------------------------
    // Simple test runner
    // ---------------------------------------------------------------

    public static void main(String[] args) throws Exception {
        XPathNewInstanceTest tester = new XPathNewInstanceTest();

        System.out.println("Running testNewInstance_Success...");
        tester.testNewInstance_Success();

        System.out.println("Running testNewInstance_ConstructorThrowsJDOMException...");
        tester.testNewInstance_ConstructorThrowsJDOMException();

        System.out.println("Running testNewInstance_ConstructorThrowsRuntimeException...");
        tester.testNewInstance_ConstructorThrowsRuntimeException();

        System.out.println("Running testNewInstance_DefaultClassResolutionFailure...");
        tester.testNewInstance_DefaultClassResolutionFailure();

        System.out.println("Running testNewInstance_PathIsNull...");
        tester.testNewInstance_PathIsNull();

        System.out.println("All tests passed.");
    }
}