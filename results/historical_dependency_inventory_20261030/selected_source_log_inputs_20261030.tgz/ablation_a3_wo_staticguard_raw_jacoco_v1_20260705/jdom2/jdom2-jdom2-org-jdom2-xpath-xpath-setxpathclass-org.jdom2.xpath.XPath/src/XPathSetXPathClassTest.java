import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

import org.jdom2.*;
import org.jdom2.xpath.XPath;
import org.junit.*;
import org.junit.rules.ExpectedException;

/**
 * Tests for {@link XPath#setXPathClass(Class)}.
 */
public class XPathSetXPathClassTest {

    @Before
    public void resetConstructorField() throws Exception {
        Field constructorField = XPath.class.getDeclaredField("constructor");
        constructorField.setAccessible(true);
        constructorField.set(null, null);
    }

    // -----------------------------------------------------------------------
    // Test fixtures: valid concrete XPath subclass with String constructor
    // -----------------------------------------------------------------------
    public static class ValidXPath extends XPath {
        private static final long serialVersionUID = 1L;
        private String expr;
        public ValidXPath(String expr) { this.expr = expr; }
        @Override public List<?> selectNodes(Object context) { return null; }
        @Override public Object selectSingleNode(Object context) { return null; }
        @Override public String valueOf(Object context) { return null; }
        @Override public Number numberValueOf(Object context) { return null; }
        @Override public void setVariable(String name, Object value) { }
        @Override public void addNamespace(Namespace namespace) { }
        @Override public String getXPath() { return expr; }
    }

    public static class AnotherValidXPath extends XPath {
        private static final long serialVersionUID = 1L;
        private String expr;
        public AnotherValidXPath(String expr) { this.expr = expr; }
        @Override public List<?> selectNodes(Object context) { return null; }
        @Override public Object selectSingleNode(Object context) { return null; }
        @Override public String valueOf(Object context) { return null; }
        @Override public Number numberValueOf(Object context) { return null; }
        @Override public void setVariable(String name, Object value) { }
        @Override public void addNamespace(Namespace namespace) { }
        @Override public String getXPath() { return expr; }
    }

    // Abstract XPath subclass – not concrete
    public static abstract class AbstractXPath extends XPath {
        private static final long serialVersionUID = 1L;
    }

    // Concrete subclass without a String constructor
    public static class NoStringConstructorXPath extends XPath {
        private static final long serialVersionUID = 1L;
        public NoStringConstructorXPath() { /* no String constructor */ }
        @Override public List<?> selectNodes(Object context) { return null; }
        @Override public Object selectSingleNode(Object context) { return null; }
        @Override public String valueOf(Object context) { return null; }
        @Override public Number numberValueOf(Object context) { return null; }
        @Override public void setVariable(String name, Object value) { }
        @Override public void addNamespace(Namespace namespace) { }
        @Override public String getXPath() { return null; }
    }

    // -----------------------------------------------------------------------
    // Tests
    // -----------------------------------------------------------------------

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void test_setXPathClass_withValidConcreteClass_setsConstructor() throws Exception {
        XPath.setXPathClass(ValidXPath.class);

        Field constructorField = XPath.class.getDeclaredField("constructor");
        constructorField.setAccessible(true);
        Constructor<?> constructor = (Constructor<?>) constructorField.get(null);

        assertNotNull(constructor);
        assertEquals(ValidXPath.class, constructor.getDeclaringClass());
        Class<?>[] paramTypes = constructor.getParameterTypes();
        assertEquals(1, paramTypes.length);
        assertEquals(String.class, paramTypes[0]);
    }

    @Test
    public void test_setXPathClass_withNull_throwsIllegalArgumentException() {
        thrown.expect(IllegalArgumentException.class);
        XPath.setXPathClass(null);
    }

    @Test
    public void test_setXPathClass_withAbstractXPathClass_throwsJDOMException() {
        thrown.expect(JDOMException.class);
        thrown.expectMessage("not a concrete");
        XPath.setXPathClass(AbstractXPath.class);
    }

    @Test
    public void test_setXPathClass_withNonXPathClass_throwsJDOMException() {
        thrown.expect(JDOMException.class);
        thrown.expectMessage("not a concrete");
        XPath.setXPathClass(Object.class);
    }

    @Test
    public void test_setXPathClass_withMissingStringConstructor_throwsJDOMException() {
        thrown.expect(JDOMException.class);
        thrown.expectCause(instanceOf(NoSuchMethodException.class));
        XPath.setXPathClass(NoStringConstructorXPath.class);
    }

    @Test
    public void test_setXPathClass_updatesConstructorWhenCalledAgain() throws Exception {
        // First call
        XPath.setXPathClass(ValidXPath.class);
        Field constructorField = XPath.class.getDeclaredField("constructor");
        constructorField.setAccessible(true);
        Constructor<?> firstConstructor = (Constructor<?>) constructorField.get(null);
        assertEquals(ValidXPath.class, firstConstructor.getDeclaringClass());

        // Second call with different class
        XPath.setXPathClass(AnotherValidXPath.class);
        Constructor<?> secondConstructor = (Constructor<?>) constructorField.get(null);
        assertEquals(AnotherValidXPath.class, secondConstructor.getDeclaringClass());
    }
}