package org.jdom2.output;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.jdom2.IllegalDataException;
import org.junit.Test;

/**
 * Unit tests for {@link Format#escapeText(EscapeStrategy, String, String)}.
 */
public class FormatEscapeTextTest {

    @Test
    public void test_no_escape_needed_returns_same_string() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "Hello World";
        String result = Format.escapeText(strategy, null, value);

        assertSame("Should return the exact same String instance when no escaping is needed", value, result);
    }

    @Test
    public void test_empty_string_no_escape() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String result = Format.escapeText(strategy, null, "");

        assertEquals("Empty string should be returned unchanged", "", result);
    }

    @Test
    public void test_escape_predefined_entities_and_crlf_with_eol() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "a<b>&c\"d'\re\nf";
        String result = Format.escapeText(strategy, "##", value);

        assertEquals("Predefined entities and CR/LF should be escaped; LF replaced with eol",
                "a&lt;b&gt;&amp;c\"d'&#xD;e##f", result);
    }

    @Test
    public void test_escape_predefined_entities_with_null_eol_keeps_newline() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "a\nb";
        String result = Format.escapeText(strategy, null, value);

        assertEquals("Newline should be preserved when eol is null", "a\nb", result);
    }

    @Test
    public void test_escape_predefined_entities_with_empty_eol_removes_newline() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "a\nb";
        String result = Format.escapeText(strategy, "", value);

        assertEquals("Newline should be removed when eol is empty string", "ab", result);
    }

    @Test
    public void test_strategy_escapes_non_surrogate_char() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return ch == 'a';
            }
        };

        String result = Format.escapeText(strategy, null, "abc");

        assertEquals("Character 'a' should be escaped as &#x61;", "&#x61;bc", result);
    }

    @Test
    public void test_strategy_escapes_high_surrogate_with_valid_low_surrogate() {
        char high = '\uD800';
        char low = '\uDF48';
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return ch == high;
            }
        };

        String value = String.valueOf(new char[]{high, low});
        String result = Format.escapeText(strategy, null, value);

        assertEquals("Valid surrogate pair should be decoded and escaped", "&#x10348;", result);
    }

    @Test(expected = IllegalDataException.class)
    public void test_invalid_surrogate_pair_throws_exception() {
        char high = '\uD800';
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return ch == high;
            }
        };

        String value = "\uD800X";
        Format.escapeText(strategy, null, value);
    }

    @Test(expected = IllegalDataException.class)
    public void test_truncated_high_surrogate_at_end_throws_exception() {
        char high = '\uD800';
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return ch == high;
            }
        };

        String value = "ab\uD800";
        Format.escapeText(strategy, null, value);
    }

    @Test
    public void test_mixed_predefined_and_strategy_escape() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return ch == 'a';
            }
        };

        String result = Format.escapeText(strategy, "", "<a>");

        assertEquals("Mixed predefined entity and strategy escape should produce correct output",
                "&lt;&#x61;&gt;", result);
    }

    @Test
    public void test_high_surrogate_not_escaped_by_strategy_is_output_directly() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "\uD800\uDF48";
        String result = Format.escapeText(strategy, null, value);

        assertEquals("When strategy does not escape high surrogate, characters are output directly (though invalid XML)",
                "\uD800\uDF48", result);
    }

    @Test(expected = NullPointerException.class)
    public void test_null_strategy_causes_npe() {
        Format.escapeText(null, null, "test");
    }

    @Test
    public void test_eol_null_on_newline_inside_string() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "line1\nline2";
        String result = Format.escapeText(strategy, null, value);

        assertEquals("Newline should be preserved when eol is null", "line1\nline2", result);
    }

    @Test
    public void test_strategy_called_only_when_needed_performance_check() {
        // Counting escape strategy to verify that shouldEscape is called for each character.
        final int[] callCount = {0};
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                callCount[0]++;
                return false;
            }
        };

        Format.escapeText(strategy, null, "abcdef");

        assertEquals("shouldEscape should be called exactly 6 times for 6 characters", 6, callCount[0]);
    }
}