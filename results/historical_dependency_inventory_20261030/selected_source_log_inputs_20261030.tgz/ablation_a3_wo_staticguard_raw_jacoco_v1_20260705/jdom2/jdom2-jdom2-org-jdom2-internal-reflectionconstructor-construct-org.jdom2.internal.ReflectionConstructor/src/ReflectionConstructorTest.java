package org.jdom2.internal;

import java.security.Permission;

/**
 * Test class for {@link ReflectionConstructor#construct(String, Class)}.
 * Runs via a main method, with no JUnit dependency.
 */
public class ReflectionConstructorTest {

    /**
     * Helper: package-private class with a public no-arg constructor that
     * always throws a RuntimeException. Used to test wrapping of
     * InvocationTargetException.
     */
    static class BadConstructor {
        public BadConstructor() {
            throw new RuntimeException("Intentional failure in constructor");
        }
    }

    /**
     * Helper: package-private abstract class with a public no-arg constructor.
     * Used to trigger InstantiationException.
     */
    abstract static class AbstractForTest {
        public AbstractForTest() {
            // nothing
        }
    }

    /**
     * Helper: private static inner class with a public no-arg constructor.
     * Used to trigger IllegalAccessException because the class itself is not
     * accessible from {@code ReflectionConstructor} (package-private/private
     * access). The constructor is public, so {@code getConstructor()} succeeds,
     * but {@code newInstance()} fails with an access check.
     */
    private static class PrivateClassWithPublicConstructor {
        public PrivateClassWithPublicConstructor() {
            // nothing
        }
    }

    /* --- Custom assertion utilities (no JUnit) --- */

    private static void assertTrue(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static void assertTrue(boolean condition) {
        if (!condition) {
            throw new AssertionError("assertTrue failed");
        }
    }

    private static void assertNotNull(Object obj) {
        if (obj == null) {
            throw new AssertionError("Expected non-null value but got null");
        }
    }

    private static void assertEquals(Object expected, Object actual) {
        if (expected == null && actual == null) {
            return;
        }
        if (expected == null || !expected.equals(actual)) {
            throw new AssertionError("Expected <" + expected + "> but was <" + actual + ">");
        }
    }

    @FunctionalInterface
    private interface Executable {
        void execute() throws Throwable;
    }

    private static <T extends Throwable> T assertThrows(Class<T> expectedType, Executable executable) {
        try {
            executable.execute();
        } catch (Throwable actualException) {
            if (!expectedType.isInstance(actualException)) {
                throw new AssertionError(
                        "Expected " + expectedType.getName() + " but got " + actualException.getClass().getName(),
                        actualException);
            }
            return expectedType.cast(actualException);
        }
        throw new AssertionError("Expected " + expectedType.getName() + " but no exception was thrown");
    }

    private static void assertInstanceOf(Class<?> expectedType, Object obj) {
        assertTrue(expectedType.isInstance(obj),
                "Expected instance of " + expectedType.getName() + " but was " +
                (obj == null ? "null" : obj.getClass().getName()));
    }

    private static void skipTest(String reason) {
        System.out.println("SKIPPED: " + reason);
    }

    /* --- Test methods (originally annotated with @Test) --- */

    // @Test
    public static void test_construct_success() {
        // Valid class, matching target type
        Object result = ReflectionConstructor.construct("java.lang.String", Object.class);
        assertNotNull(result);
        assertInstanceOf(String.class, result);
        assertEquals("", result);
    }

    // @Test
    public static void test_class_not_found() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
            () -> ReflectionConstructor.construct("com.example.NonExistent", Object.class)
        );
        assertTrue(ex.getMessage().contains("Unable to locate class"));
    }

    // @Test
    public static void test_class_not_assignable() {
        ClassCastException ex = assertThrows(ClassCastException.class,
            () -> ReflectionConstructor.construct("java.lang.String", Integer.class)
        );
        assertTrue(ex.getMessage().contains("not assignable"));
    }

    // @Test
    public static void test_no_noarg_constructor() {
        // Integer does not have a public no-arg constructor
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
            () -> ReflectionConstructor.construct("java.lang.Integer", Integer.class)
        );
        assertTrue(ex.getMessage().contains("no-arg constructor"));
    }

    // @Test
    public static void test_instantiation_exception_for_abstract_class() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
            () -> ReflectionConstructor.construct(
                "org.jdom2.internal.ReflectionConstructorTest$AbstractForTest", Object.class)
        );
        assertTrue(ex.getMessage().contains("Unable to instantiate class"));
    }

    // @Test
    public static void test_constructor_throws_exception() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
            () -> ReflectionConstructor.construct(
                "org.jdom2.internal.ReflectionConstructorTest$BadConstructor", Object.class)
        );
        assertTrue(ex.getMessage().contains("Unable to call class constructor"));
        assertInstanceOf(RuntimeException.class, ex.getCause());
    }

    // @Test
    public static void test_illegal_access_exception() {
        // Use the private inner class with a public constructor.
        // Because the class itself is private, the newInstance() call will throw
        // IllegalAccessException despite the constructor being public.
        IllegalStateException ex = assertThrows(IllegalStateException.class,
            () -> ReflectionConstructor.construct(
                "org.jdom2.internal.ReflectionConstructorTest$PrivateClassWithPublicConstructor", Object.class)
        );
        assertTrue(ex.getMessage().contains("Unable to access class constructor"));
    }

    // @Test
    public static void test_security_exception_by_security_manager() {
        SecurityManager original = System.getSecurityManager();
        try {
            // Attempt to install a restrictive SecurityManager
            System.setSecurityManager(new SecurityManager() {
                @Override
                public void checkPermission(Permission perm) {
                    // Deny everything
                    throw new SecurityException("Access denied by test");
                }
            });
        } catch (UnsupportedOperationException e) {
            // Security manager not supported in this JVM (e.g. newer Java versions)
            skipTest("SecurityManager not supported, skipping test.");
            return;
        }

        try {
            IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> ReflectionConstructor.construct("java.lang.String", Object.class)
            );
            assertTrue(ex.getMessage().contains("Unable to access class constructor"));
        } finally {
            System.setSecurityManager(original);
        }
    }

    /* --- simple test runner main method --- */

    public static void main(String[] args) {
        String[] testMethodNames = {
                "test_construct_success",
                "test_class_not_found",
                "test_class_not_assignable",
                "test_no_noarg_constructor",
                "test_instantiation_exception_for_abstract_class",
                "test_constructor_throws_exception",
                "test_illegal_access_exception",
                "test_security_exception_by_security_manager"
        };

        int passed = 0;
        int failed = 0;

        for (String methodName : testMethodNames) {
            try {
                java.lang.reflect.Method method = ReflectionConstructorTest.class.getDeclaredMethod(methodName);
                method.setAccessible(true);
                method.invoke(null);
                System.out.println("PASSED: " + methodName);
                passed++;
            } catch (java.lang.reflect.InvocationTargetException e) {
                Throwable cause = e.getCause();
                if (cause instanceof AssertionError) {
                    System.out.println("FAILED: " + methodName + " - " + cause.getMessage());
                    failed++;
                } else {
                    System.out.println("ERROR: " + methodName + " - " + cause);
                    failed++;
                }
            } catch (Exception e) {
                System.out.println("ERROR: " + methodName + " - " + e);
                failed++;
            }
        }

        System.out.println("\nResults: " + passed + " passed, " + failed + " failed.");
        if (failed > 0) {
            System.exit(1);
        }
    }
}