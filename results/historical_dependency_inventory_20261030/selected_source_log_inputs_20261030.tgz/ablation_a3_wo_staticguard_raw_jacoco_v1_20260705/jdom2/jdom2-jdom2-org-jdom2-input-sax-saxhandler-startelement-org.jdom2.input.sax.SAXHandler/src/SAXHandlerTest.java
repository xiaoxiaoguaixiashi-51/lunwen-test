package org.jdom2.input.sax;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Attribute;
import org.jdom2.AttributeType;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMFactory;
import org.jdom2.Namespace;
import org.jdom2.Text;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.ext.Attributes2;

public class SAXHandlerTest {

    private JDOMFactory factory;
    private SAXHandler handler;
    private Attributes atts;
    private Locator locator;

    @Before
    public void setUp() throws Exception {
        factory = mock(JDOMFactory.class);
        handler = new SAXHandler(factory);
        atts = mock(Attributes.class);
        locator = mock(Locator.class);

        when(factory.document(null)).thenAnswer(inv -> {
            Document doc = mock(Document.class);
            return doc;
        });
    }

    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private Object getField(Object target, String fieldName) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(target);
    }

    @Test
    public void test_startElement_suppress_true_returns_immediately() throws Exception {
        setField(handler, "suppress", true);
        Element originalCurrentElement = (Element) getField(handler, "currentElement");

        handler.startElement("", "root", "root", atts);

        verifyNoInteractions(factory, atts);
        assertSame(originalCurrentElement, getField(handler, "currentElement"));
    }

    @Test
    public void test_startElement_root_element_no_attributes_no_namespace() throws Exception {
        when(atts.getLength()).thenReturn(0);

        Element mockElement = mock(Element.class);
        when(factory.element(eq("book"), eq(Namespace.NO_NAMESPACE))).thenReturn(mockElement);

        handler.startElement("", "book", "book", atts);

        verify(factory).element("book", Namespace.NO_NAMESPACE);
        verify(factory).setRoot(any(Document.class), eq(mockElement));
        assertFalse((Boolean) getField(handler, "atRoot"));
        assertSame(mockElement, getField(handler, "currentElement"));
        verify(factory, never()).addContent(any(Element.class), any());
    }

    @Test
    public void test_startElement_non_root_element_with_parent() throws Exception {
        setField(handler, "atRoot", false);
        Element parentElement = mock(Element.class);
        when(parentElement.getParent()).thenReturn(mock(Document.class));
        setField(handler, "currentElement", parentElement);

        when(atts.getLength()).thenReturn(0);
        Element childElement = mock(Element.class);
        when(factory.element(eq("chapter"), eq(Namespace.NO_NAMESPACE))).thenReturn(childElement);

        handler.startElement("", "chapter", "chapter", atts);

        verify(factory).element("chapter", Namespace.NO_NAMESPACE);
        verify(factory).addContent(parentElement, childElement);
        assertSame(childElement, getField(handler, "currentElement"));
        assertFalse((Boolean) getField(handler, "atRoot"));
    }

    @Test
    public void test_startElement_with_namespace_and_prefix() throws Exception {
        when(atts.getLength()).thenReturn(0);
        Namespace expectedNs = Namespace.getNamespace("ns", "http://example.com/ns");
        Element mockElement = mock(Element.class);
        when(factory.element(eq("child"), eq(expectedNs))).thenReturn(mockElement);

        handler.startElement("http://example.com/ns", "child", "ns:child", atts);

        verify(factory).element("child", expectedNs);
        verify(factory).setRoot(any(Document.class), eq(mockElement));
        assertFalse((Boolean) getField(handler, "atRoot"));
    }

    @Test
    public void test_startElement_qname_missing_localName_derived_from_qname() throws Exception {
        when(atts.getLength()).thenReturn(0);
        Element mockElement = mock(Element.class);
        when(factory.element(eq("element"), eq(Namespace.NO_NAMESPACE))).thenReturn(mockElement);

        handler.startElement("", "", "ns:element", atts);

        verify(factory).element("element", Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_startElement_localName_null_derived_from_qname() throws Exception {
        when(atts.getLength()).thenReturn(0);
        Element mockElement = mock(Element.class);
        when(factory.element(eq("name"), eq(Namespace.NO_NAMESPACE))).thenReturn(mockElement);

        handler.startElement("", null, "pre:name", atts);

        verify(factory).element("name", Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_startElement_transfer_declared_namespaces() throws Exception {
        List<Namespace> declaredNamespaces = new ArrayList<>();
        Namespace ns1 = Namespace.getNamespace("ns1", "http://ns1");
        Namespace ns2 = Namespace.getNamespace("ns2", "http://ns2");
        declaredNamespaces.add(ns1);
        declaredNamespaces.add(ns2);
        setField(handler, "declaredNamespaces", declaredNamespaces);
        setField(handler, "atRoot", false);
        Element parentElement = mock(Element.class);
        when(parentElement.getParent()).thenReturn(mock(Document.class));
        setField(handler, "currentElement", parentElement);

        when(atts.getLength()).thenReturn(0);
        Element newElement = mock(Element.class);
        when(newElement.getNamespace()).thenReturn(Namespace.NO_NAMESPACE);
        when(factory.element(eq("tag"), eq(Namespace.NO_NAMESPACE))).thenReturn(newElement);

        handler.startElement("", "tag", "tag", atts);

        verify(newElement, times(1)).addNamespaceDeclaration(ns1);
        verify(newElement, times(1)).addNamespaceDeclaration(ns2);
        assertTrue(((List<?>) getField(handler, "declaredNamespaces")).isEmpty());
    }

    @Test
    public void test_startElement_flush_characters_before_creating_element() throws Exception {
        Text mockText = mock(Text.class);
        when(factory.text(anyString())).thenReturn(mockText);
        setField(handler, "textBuffer", new TextBuffer());
        TextBuffer textBuffer = (TextBuffer) getField(handler, "textBuffer");
        textBuffer.append("some text".toCharArray(), 0, 9);
        setField(handler, "atRoot", false);
        Element parentElement = mock(Element.class);
        when(parentElement.getParent()).thenReturn(mock(Document.class));
        setField(handler, "currentElement", parentElement);

        when(atts.getLength()).thenReturn(0);
        Element elem = mock(Element.class);
        when(factory.element(eq("elem"), eq(Namespace.NO_NAMESPACE))).thenReturn(elem);

        handler.startElement("", "elem", "elem", atts);

        verify(factory).text("some text");
        assertTrue(textBuffer.toString().isEmpty());
        verify(factory).element("elem", Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_startElement_attributes_simple_case() throws Exception {
        when(atts.getLength()).thenReturn(2);
        when(atts.getLocalName(0)).thenReturn("id");
        when(atts.getQName(0)).thenReturn("id");
        when(atts.getType(0)).thenReturn("CDATA");
        when(atts.getValue(0)).thenReturn("10");
        when(atts.getURI(0)).thenReturn("");
        when(atts.getLocalName(1)).thenReturn("name");
        when(atts.getQName(1)).thenReturn("name");
        when(atts.getType(1)).thenReturn("CDATA");
        when(atts.getValue(1)).thenReturn("test");
        when(atts.getURI(1)).thenReturn("");

        Attribute attr0 = mock(Attribute.class);
        Attribute attr1 = mock(Attribute.class);
        when(factory.attribute(eq("id"), eq("10"), eq(AttributeType.CDATA), any(Namespace.class)))
                .thenReturn(attr0);
        when(factory.attribute(eq("name"), eq("test"), eq(AttributeType.CDATA), any(Namespace.class)))
                .thenReturn(attr1);

        Element rootElement = mock(Element.class);
        when(factory.element(eq("item"), eq(Namespace.NO_NAMESPACE))).thenReturn(rootElement);

        handler.startElement("", "item", "item", atts);

        verify(factory).attribute("id", "10", AttributeType.CDATA, Namespace.NO_NAMESPACE);
        verify(factory).attribute("name", "test", AttributeType.CDATA, Namespace.NO_NAMESPACE);
        verify(factory).setAttribute(rootElement, attr0);
        verify(factory).setAttribute(rootElement, attr1);
    }

    @Test
    public void test_startElement_skip_xmlns_attributes() throws Exception {
        when(atts.getLength()).thenReturn(3);
        when(atts.getLocalName(0)).thenReturn("xmlns");
        when(atts.getQName(0)).thenReturn("xmlns");
        when(atts.getType(0)).thenReturn("CDATA");
        when(atts.getValue(0)).thenReturn("http://default");
        when(atts.getURI(0)).thenReturn("");
        when(atts.getLocalName(1)).thenReturn("pfx");
        when(atts.getQName(1)).thenReturn("xmlns:pfx");
        when(atts.getType(1)).thenReturn("CDATA");
        when(atts.getValue(1)).thenReturn("http://pfx");
        when(atts.getURI(1)).thenReturn("");
        when(atts.getLocalName(2)).thenReturn("attr");
        when(atts.getQName(2)).thenReturn("attr");
        when(atts.getType(2)).thenReturn("CDATA");
        when(atts.getValue(2)).thenReturn("val");
        when(atts.getURI(2)).thenReturn("");

        Attribute normalAttr = mock(Attribute.class);
        when(factory.attribute(eq("attr"), eq("val"), eq(AttributeType.CDATA), any(Namespace.class)))
                .thenReturn(normalAttr);
        Element root = mock(Element.class);
        when(factory.element(eq("root"), eq(Namespace.NO_NAMESPACE))).thenReturn(root);

        handler.startElement("", "root", "root", atts);

        verify(factory, never()).attribute(matches("xmlns|pfx"), anyString(), any(), any());
        verify(factory).attribute("attr", "val", AttributeType.CDATA, Namespace.NO_NAMESPACE);
        verify(factory).setAttribute(root, normalAttr);
    }

    @Test
    public void test_startElement_attribute_with_namespace_URI_and_no_prefix_existing_prefix_found() throws Exception {
        setField(handler, "atRoot", false);
        Element current = mock(Element.class);
        when(current.getParent()).thenReturn(mock(Document.class));
        Namespace nsExisting = Namespace.getNamespace("ns1", "http://other");
        List<Namespace> nsScope = new ArrayList<>();
        nsScope.add(nsExisting);
        when(current.getNamespacesInScope()).thenReturn(nsScope);
        setField(handler, "currentElement", current);

        when(atts.getLength()).thenReturn(1);
        when(atts.getLocalName(0)).thenReturn("attr");
        when(atts.getQName(0)).thenReturn("attr");
        when(atts.getType(0)).thenReturn("CDATA");
        when(atts.getValue(0)).thenReturn("value");
        when(atts.getURI(0)).thenReturn("http://other");

        Attribute mockAttr = mock(Attribute.class);
        when(factory.attribute(eq("attr"), eq("value"), eq(AttributeType.CDATA), eq(nsExisting)))
                .thenReturn(mockAttr);

        Element elem = mock(Element.class);
        when(factory.element(eq("elem"), eq(Namespace.NO_NAMESPACE))).thenReturn(elem);

        handler.startElement("", "elem", "elem", atts);

        verify(factory).attribute("attr", "value", AttributeType.CDATA, nsExisting);
        verify(factory, never()).attribute(eq("attr"), anyString(), any(), argThat(ns ->
                ns != null && ns.getPrefix().startsWith("attns")));
    }

    @Test
    public void test_startElement_attribute_with_namespace_URI_and_no_prefix_fallback_generated() throws Exception {
        setField(handler, "atRoot", false);
        Element current = mock(Element.class);
        when(current.getParent()).thenReturn(mock(Document.class));
        when(current.getNamespacesInScope()).thenReturn(new ArrayList<>());
        setField(handler, "currentElement", current);

        when(atts.getLength()).thenReturn(1);
        when(atts.getLocalName(0)).thenReturn("attr");
        when(atts.getQName(0)).thenReturn("attr");
        when(atts.getType(0)).thenReturn("CDATA");
        when(atts.getValue(0)).thenReturn("value");
        when(atts.getURI(0)).thenReturn("http://other");

        Namespace fallbackNs = Namespace.getNamespace("attns0", "http://other");
        Attribute mockAttr = mock(Attribute.class);
        when(factory.attribute(eq("attr"), eq("value"), eq(AttributeType.CDATA), eq(fallbackNs)))
                .thenReturn(mockAttr);

        Element elem = mock(Element.class);
        when(factory.element(eq("elem"), eq(Namespace.NO_NAMESPACE))).thenReturn(elem);

        handler.startElement("", "elem", "elem", atts);

        verify(factory).attribute("attr", "value", AttributeType.CDATA, fallbackNs);
    }

    @Test
    public void test_startElement_attribute_DTD_defaulted_specified_false() throws Exception {
        Attributes2 atts2 = mock(Attributes2.class);
        atts = atts2;
        when(atts.getLength()).thenReturn(1);
        when(atts.getLocalName(0)).thenReturn("attr");
        when(atts.getQName(0)).thenReturn("attr");
        when(atts.getType(0)).thenReturn("CDATA");
        when(atts.getValue(0)).thenReturn("defaulted");
        when(atts.getURI(0)).thenReturn("");
        when(atts2.isSpecified(0)).thenReturn(false);

        Attribute attr = mock(Attribute.class);
        when(factory.attribute(eq("attr"), eq("defaulted"), eq(AttributeType.CDATA), eq(Namespace.NO_NAMESPACE)))
                .thenReturn(attr);
        Element elem = mock(Element.class);
        when(factory.element(eq("elem"), eq(Namespace.NO_NAMESPACE))).thenReturn(elem);

        handler.startElement("", "elem", "elem", atts);

        verify(attr).setSpecified(false);
    }

    @Test
    public void test_startElement_with_locator_uses_line_column() throws Exception {
        setField(handler, "currentLocator", locator);
        when(locator.getLineNumber()).thenReturn(5);
        when(locator.getColumnNumber()).thenReturn(20);
        when(atts.getLength()).thenReturn(0);

        Element elem = mock(Element.class);
        when(factory.element(eq(5), eq(20), eq("elem"), eq(Namespace.NO_NAMESPACE))).thenReturn(elem);

        handler.startElement("", "elem", "elem", atts);

        verify(factory).element(5, 20, "elem", Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_startElement_empty_qName_no_prefix() throws Exception {
        when(atts.getLength()).thenReturn(0);
        Element elem = mock(Element.class);
        when(factory.element(eq("tag"), eq(Namespace.NO_NAMESPACE))).thenReturn(elem);

        handler.startElement("", "tag", "", atts);

        verify(factory).element("tag", Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_startElement_attribute_with_empty_qName_uses_localName() throws Exception {
        when(atts.getLength()).thenReturn(1);
        when(atts.getLocalName(0)).thenReturn("href");
        when(atts.getQName(0)).thenReturn("");
        when(atts.getType(0)).thenReturn("CDATA");
        when(atts.getValue(0)).thenReturn("http://example.com");
        when(atts.getURI(0)).thenReturn("");

        Attribute attr = mock(Attribute.class);
        when(factory.attribute(eq("href"), eq("http://example.com"), eq(AttributeType.CDATA), eq(Namespace.NO_NAMESPACE)))
                .thenReturn(attr);
        Element elem = mock(Element.class);
        when(factory.element(eq("elem"), eq(Namespace.NO_NAMESPACE))).thenReturn(elem);

        handler.startElement("", "elem", "elem", atts);

        verify(factory).attribute("href", "http://example.com", AttributeType.CDATA, Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_startElement_qname_with_colon_keeps_supplied_localName() throws Exception {
        when(atts.getLength()).thenReturn(0);
        Element elem = mock(Element.class);
        when(factory.element(eq("explicitLocal"), eq(Namespace.NO_NAMESPACE))).thenReturn(elem);

        handler.startElement("", "explicitLocal", "ns:ignored", atts);

        verify(factory).element("explicitLocal", Namespace.NO_NAMESPACE);
    }

    @Test
    public void test_startElement_with_xml_namespace() throws Exception {
        when(atts.getLength()).thenReturn(0);
        Namespace xmlNs = Namespace.getNamespace("xml", "http://www.w3.org/XML/1998/namespace");
        Element elem = mock(Element.class);
        when(factory.element(eq("lang"), eq(xmlNs))).thenReturn(elem);

        handler.startElement("http://www.w3.org/XML/1998/namespace", "lang", "xml:lang", atts);

        verify(factory).element("lang", xmlNs);
    }
}