package org.jdom2;

import static org.junit.Assert.*;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.junit.Test;

import java.util.List;

/**
 * Tests for the {@link Element#getNamespacesInScope()} method.
 */
public class ElementTest {

    @Test
    public void testGetNamespacesInScope_RootElementWithOwnNamespace() {
        // Root element with its own non-empty prefix namespace, no additional namespaces, no attributes.
        Namespace elemNamespace = Namespace.getNamespace("ns1", "http://example.com/ns1");
        Element root = new Element("root", elemNamespace);

        List<Namespace> scope = root.getNamespacesInScope();

        assertEquals("size should be 3", 3, scope.size());
        assertSame("first element is element's own namespace", elemNamespace, scope.get(0));
        assertSame("second element is XML namespace", Namespace.XML_NAMESPACE, scope.get(1));
        assertSame("third element is NO_NAMESPACE", Namespace.NO_NAMESPACE, scope.get(2));
    }

    @Test
    public void testGetNamespacesInScope_RootElementWithDefaultNamespace() {
        // Root element has its own namespace as a default namespace (empty prefix).
        Namespace defaultNs = Namespace.getNamespace("", "http://example.com/default");
        Element root = new Element("root", defaultNs);

        List<Namespace> scope = root.getNamespacesInScope();

        assertEquals("size should be 2", 2, scope.size());
        assertSame("first element is the element's default namespace", defaultNs, scope.get(0));
        assertSame("second element is XML namespace", Namespace.XML_NAMESPACE, scope.get(1));
    }

    @Test
    public void testGetNamespacesInScope_ChildInheritsFromParent() {
        // Parent setup: own namespace 'parentNs', additional 'extraParent'
        Namespace parentNs = Namespace.getNamespace("p", "http://parent.example.com");
        Namespace extraParent = Namespace.getNamespace("ep", "http://extra.parent.example.com");
        Element parent = new Element("parent", parentNs);
        parent.addNamespaceDeclaration(extraParent);

        // Child setup: own namespace 'childNs', additional 'extraChild', attribute 'attr' with namespace 'attrNs'
        Namespace childNs = Namespace.getNamespace("ch", "http://child.example.com");
        Namespace extraChild = Namespace.getNamespace("ex", "http://extra.child.example.com");
        Namespace attrNs = Namespace.getNamespace("at", "http://attr.example.com");
        Element child = new Element("child", childNs);
        child.addNamespaceDeclaration(extraChild);
        // add an attribute that uses attrNs
        child.setAttribute(new Attribute("attr1", "value", attrNs));

        // make parent-child relationship
        parent.addContent(child);

        List<Namespace> scope = child.getNamespacesInScope();

        // Expected order: childNs (first), then extraChild, attrNs, parentNs, extraParent, XML (no NO_NAMESPACE because childNs has a non-empty prefix)
        // Sorted by prefix: at, ch, ep, ex, p, xml. But after childNs (prefix "ch") the rest are sorted:
        // Sorted prefixes: at, ep, ex, p, xml. So order: childNs (ch), attrNs (at), extraParent(ep), extraChild(ex), parentNs(p), XML.
        assertEquals("list size should be 6", 6, scope.size());
        assertSame("first element is child's own namespace", childNs, scope.get(0));
        // The rest are sorted by prefix: at, ep, ex, p, xml
        assertSame("second should be attribute namespace (prefix 'at')", attrNs, scope.get(1));
        assertSame("third should be extraParent (prefix 'ep')", extraParent, scope.get(2));
        assertSame("fourth should be extraChild (prefix 'ex')", extraChild, scope.get(3));
        assertSame("fifth should be parentNs (prefix 'p')", parentNs, scope.get(4));
        assertSame("sixth should be XML namespace", Namespace.XML_NAMESPACE, scope.get(5));

        // Optionally check that the list contains exactly these
        assertTrue(scope.contains(childNs));
        assertTrue(scope.contains(extraChild));
        assertTrue(scope.contains(attrNs));
        assertTrue(scope.contains(parentNs));
        assertTrue(scope.contains(extraParent));
        assertTrue(scope.contains(Namespace.XML_NAMESPACE));
    }

    @Test
    public void testGetNamespacesInScope_AdditionalNamespacesOrder() {
        // Root element with own namespace and two additional namespace declarations with prefixes 'b' and 'a'.
        Namespace ownNs = Namespace.getNamespace("elem", "http://own.example.com");
        Namespace nsA = Namespace.getNamespace("a", "http://a.example.com");
        Namespace nsB = Namespace.getNamespace("b", "http://b.example.com");

        Element root = new Element("root", ownNs);
        root.addNamespaceDeclaration(nsB);
        root.addNamespaceDeclaration(nsA);

        List<Namespace> scope = root.getNamespacesInScope();

        // Expected order: own (prefix 'elem'), then sorted additional: a, b, xml, no-namespace
        assertEquals("size includes own, a, b, xml, and NO_NAMESPACE", 5, scope.size());
        assertSame("first is own", ownNs, scope.get(0));
        assertSame("second is prefix 'a'", nsA, scope.get(1));
        assertSame("third is prefix 'b'", nsB, scope.get(2));
        assertSame("fourth xml", Namespace.XML_NAMESPACE, scope.get(3));
        assertSame("fifth NO_NAMESPACE", Namespace.NO_NAMESPACE, scope.get(4));
    }

    @Test
    public void testGetNamespacesInScope_WithAttributeNamespaces() {
        // Element with own namespace and an attribute having a namespace. No additional namespaces.
        Namespace elemNs = Namespace.getNamespace("elem", "http://elem.example.com");
        Namespace attrNs = Namespace.getNamespace("attr", "http://attr.example.com");
        Element elem = new Element("test", elemNs);
        elem.setAttribute(new Attribute("foo", "bar", attrNs));

        List<Namespace> scope = elem.getNamespacesInScope();

        // Expected: elemNs (first), then attrNs (sorted), xml, NO_NAMESPACE
        assertEquals("size includes own, attr ns, xml, and NO_NAMESPACE", 4, scope.size());
        assertSame("first is own", elemNs, scope.get(0));
        assertSame("second is attr namespace", attrNs, scope.get(1));
        assertSame("third is XML", Namespace.XML_NAMESPACE, scope.get(2));
        assertSame("fourth is NO_NAMESPACE", Namespace.NO_NAMESPACE, scope.get(3));
        assertTrue("list contains attribute namespace", scope.contains(attrNs));
    }

    @Test
    public void testGetNamespacesInScope_ReturnUnmodifiableList() {
        Element root = new Element("root", Namespace.NO_NAMESPACE);
        List<Namespace> scope = root.getNamespacesInScope();

        try {
            scope.add(Namespace.XML_NAMESPACE);
            fail("Expected UnsupportedOperationException on list.add()");
        } catch (UnsupportedOperationException e) {
            // expected
        }

        try {
            scope.remove(0);
            fail("Expected UnsupportedOperationException on list.remove()");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    @Test
    public void testGetNamespacesInScope_NoOwnNamespaceNoParent() {
        // Element with NO_NAMESPACE as its own namespace, standalone.
        Element elem = new Element("standalone", Namespace.NO_NAMESPACE);
        List<Namespace> scope = elem.getNamespacesInScope();

        // Expected: NO_NAMESPACE (own), then XML_NAMESPACE.
        assertEquals("size is 2", 2, scope.size());
        assertSame("first is NO_NAMESPACE", Namespace.NO_NAMESPACE, scope.get(0));
        assertSame("second is XML_NAMESPACE", Namespace.XML_NAMESPACE, scope.get(1));
    }

    @Test
    public void testGetNamespacesInScope_DuplicatePrefixes() {
        // Element has own namespace with prefix 'dup'.
        Namespace ownNs = Namespace.getNamespace("dup", "http://own.example.com");
        // Additional namespace with same prefix 'dup' but different URI.
        Namespace duplicateExtra = Namespace.getNamespace("dup", "http://other.example.com");
        Element root = new Element("root", ownNs);
        // add extra with same prefix; it will be ignored because prefix 'dup' already exists from own namespace
        root.addNamespaceDeclaration(duplicateExtra); // still returns true but will be ignored in scope

        List<Namespace> scope = root.getNamespacesInScope();

        // The scope should contain ownNs, XML_NAMESPACE, NO_NAMESPACE (no duplicateExtra)
        assertTrue("own namespace should be in scope", scope.contains(ownNs));
        assertFalse("duplicate additional namespace should not be in scope", scope.contains(duplicateExtra));

        // Also test parent with same prefix: parent has own namespace 'dup' too (different URI)
        Namespace parentNs = Namespace.getNamespace("dup", "http://parent.example.com");
        Element parent = new Element("parent", parentNs);
        parent.addContent(root); // root now child; parent will be in scope via inheritance

        // Now child's scope: first add own (dup), then extra (dup) ignored, then parent scope.
        // parent scope: parentNs (dup) already present, so it's skipped.
        List<Namespace> childScope = root.getNamespacesInScope();
        assertSame("first should be element's own namespace", ownNs, childScope.get(0));
        // Check that parentNs is not in the list
        assertFalse("parent's namespace with same prefix should be ignored", childScope.contains(parentNs));
        // Verify duplicateExtra is still not present
        assertFalse("duplicate additional namespace still not present", childScope.contains(duplicateExtra));
    }
}