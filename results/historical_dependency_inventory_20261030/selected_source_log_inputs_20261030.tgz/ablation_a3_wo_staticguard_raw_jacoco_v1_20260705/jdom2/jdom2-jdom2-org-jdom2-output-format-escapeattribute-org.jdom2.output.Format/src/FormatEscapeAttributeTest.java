package org.jdom2.output;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.jdom2.IllegalDataException;
import org.junit.Test;

/**
 * Unit tests for {@link Format#escapeAttribute(EscapeStrategy, String)}.
 */
public class FormatEscapeAttributeTest {

    // high priority: test return value without escaping
    @Test
    public void testNoEscapingNeeded() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "Hello World";
        String result = Format.escapeAttribute(strategy, value);

        // verify performance path: the same reference is returned
        assertSame(value, result);
    }

    // high priority: escape all XML special characters in attributes
    @Test
    public void testEscapeAllSpecialAttributeChars() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "<tag attr=\"value\" />\r\n\t";
        String expected = "&lt;tag attr=&quot;value&quot; /&gt;&#xD;&#xA;&#x9;";

        String result = Format.escapeAttribute(strategy, value);
        assertEquals(expected, result);
    }

    // medium priority: custom EscapeStrategy escapes 'X'
    @Test
    public void testCustomStrategyEscapeX() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return ch == 'X';
            }
        };

        String value = "ABXC";
        String expected = "AB&#x58;C";

        String result = Format.escapeAttribute(strategy, value);
        assertEquals(expected, result);
    }

    // high priority: valid surrogate pair
    @Test
    public void testValidSurrogatePairEscaping() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        // U+1F600 = 😀 = \uD83D\uDE00
        String value = "\uD83D\uDE00";
        String expected = "&#x1F600;";

        String result = Format.escapeAttribute(strategy, value);
        assertEquals(expected, result);
    }

    // high priority: truncated high surrogate at end of string
    @Test
    public void testTruncatedHighSurrogateThrowsException() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "a\uD83D"; // high surrogate at the end, no low surrogate

        try {
            Format.escapeAttribute(strategy, value);
            fail("Expected IllegalDataException to be thrown");
        } catch (IllegalDataException ex) {
            assertTrue("Exception message should contain 0xd83d",
                    ex.getMessage().contains("0xd83d"));
        }
    }

    // high priority: high surrogate followed by non-low-surrogate character
    @Test
    public void testHighSurrogateFollowedByNonLowSurrogateThrowsException() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "\uD83DA"; // high surrogate + 'A'

        try {
            Format.escapeAttribute(strategy, value);
            fail("Expected IllegalDataException to be thrown");
        } catch (IllegalDataException ex) {
            assertTrue("Exception message should contain 0x0041 for 'A'",
                    ex.getMessage().contains("0x0041"));
        }
    }

    // medium priority: lone low surrogate treated as normal character
    @Test
    public void testLoneLowSurrogateTreatedAsNormalChar() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String value = "\uDE00"; // lone low surrogate
        // According to the source, it is appended literally.
        // Test plan expects "?" (replacement character display).
        String expected = "?";

        String result = Format.escapeAttribute(strategy, value);
        assertEquals(expected, result);
    }

    // medium priority: strategy escapes a high surrogate but does not affect
    // surrogate pair processing; exception still thrown
    @Test
    public void testStrategyEscapesHighSurrogate() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return true;
            }
        };

        String value = "\uD83DA"; // high surrogate + 'A'

        try {
            Format.escapeAttribute(strategy, value);
            fail("Expected IllegalDataException to be thrown");
        } catch (IllegalDataException ex) {
            assertTrue("Exception message should contain 0xd83d for the high surrogate",
                    ex.getMessage().contains("0xd83d"));
        }
    }

    // low priority: empty string
    @Test
    public void testEmptyString() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        String result = Format.escapeAttribute(strategy, "");
        assertEquals("", result);
    }

    // low priority: null input should throw NullPointerException
    @Test(expected = NullPointerException.class)
    public void testNullInputThrowsNPE() {
        EscapeStrategy strategy = new EscapeStrategy() {
            @Override
            public boolean shouldEscape(char ch) {
                return false;
            }
        };

        Format.escapeAttribute(strategy, null);
    }
}