package org.jdom2;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;
import java.util.function.Consumer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link Document#canContainContent(Content, int, boolean)}.
 * Tests all content placement rules for a Document using real ContentList
 * state instead of mocking.
 */
public class DocumentCanContainContentTest {

    private Document document;

    /**
     * Sets up a Document with a manually constructed ContentList,
     * optionally filling it with initial content via the given consumer.
     */
    private void setupDocument(Consumer<ContentList> contentFiller) throws Exception {
        document = new Document();
        Field contentField = Document.class.getDeclaredField("content");
        contentField.setAccessible(true);
        ContentList contentList = new ContentList(document);
        if (contentFiller != null) {
            contentFiller.accept(contentList);
        }
        contentField.set(document, contentList);
    }

    @BeforeEach
    public void setUp() throws Exception {
        // default empty document
        setupDocument(null);
    }

    // Factory methods for test content
    private Element createElement() {
        return new Element("test", Namespace.NO_NAMESPACE);
    }

    private DocType createDocType() {
        return new DocType("root");
    }

    private CDATA createCDATA() {
        return new CDATA("data");
    }

    private Text createText() {
        return new Text("text");
    }

    private EntityRef createEntityRef() {
        return new EntityRef("ref");
    }

    private Comment createComment() {
        return new Comment("comment");
    }

    // --------------------------------------------------------------
    // Tests for Element
    // --------------------------------------------------------------

    @Test
    public void testAddElementWhenContentIsEmpty() throws Exception {
        setupDocument(null); // ensure empty
        assertDoesNotThrow(() -> document.canContainContent(createElement(), 0, false));
    }

    @Test
    public void testAddSecondRootElementThrows() throws Exception {
        setupDocument(cl -> {
            cl.add(createElement()); // already one element at index 0
        });
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createElement(), 1, false));
        assertEquals("Cannot add a second root element, only one is allowed", ex.getMessage());
    }

    @Test
    public void testReplaceExistingRootElement() throws Exception {
        setupDocument(cl -> {
            cl.add(createElement()); // element at index 0
        });
        assertDoesNotThrow(() -> document.canContainContent(createElement(), 0, true));
    }

    @Test
    public void testRootElementBeforeDocTypeThrows() throws Exception {
        setupDocument(cl -> {
            cl.add(createDocType()); // DocType at index 0, no element yet
        });
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createElement(), 0, false));
        assertEquals("A root element cannot be added before the DocType", ex.getMessage());
    }

    @Test
    public void testRootElementAfterDocTypeSucceeds() throws Exception {
        setupDocument(cl -> {
            cl.add(createDocType()); // DocType at index 0
        });
        assertDoesNotThrow(() -> document.canContainContent(createElement(), 1, false));
    }

    @Test
    public void testReplaceRootElementAtDifferentIndexStillThrows() throws Exception {
        setupDocument(cl -> {
            cl.add(createElement()); // element at 0
        });
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createElement(), 1, true));
        assertEquals("Cannot add a second root element, only one is allowed", ex.getMessage());
    }

    // --------------------------------------------------------------
    // Tests for DocType
    // --------------------------------------------------------------

    @Test
    public void testAddDocTypeWhenContentIsEmpty() throws Exception {
        setupDocument(null);
        assertDoesNotThrow(() -> document.canContainContent(createDocType(), 0, false));
    }

    @Test
    public void testAddSecondDocTypeThrows() throws Exception {
        setupDocument(cl -> {
            cl.add(createDocType()); // one DocType at 0
        });
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createDocType(), 1, false));
        assertEquals("Cannot add a second doctype, only one is allowed", ex.getMessage());
    }

    @Test
    public void testReplaceExistingDocType() throws Exception {
        setupDocument(cl -> {
            cl.add(createDocType()); // DocType at 0
        });
        assertDoesNotThrow(() -> document.canContainContent(createDocType(), 0, true));
    }

    @Test
    public void testDocTypeAfterRootElementThrows() throws Exception {
        setupDocument(cl -> {
            cl.add(createElement()); // Element at 0, no DocType yet
        });
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createDocType(), 1, false));
        assertEquals("A DocType cannot be added after the root element", ex.getMessage());
    }

    @Test
    public void testDocTypeBeforeRootElementSucceeds() throws Exception {
        setupDocument(cl -> {
            cl.add(createElement()); // Element at 0
        });
        assertDoesNotThrow(() -> document.canContainContent(createDocType(), 0, false));
    }

    @Test
    public void testReplaceDocTypeAtDifferentIndexStillThrows() throws Exception {
        setupDocument(cl -> {
            cl.add(createDocType()); // DocType at 0
        });
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createDocType(), 2, true));
        assertEquals("Cannot add a second doctype, only one is allowed", ex.getMessage());
    }

    // --------------------------------------------------------------
    // Tests for other content types
    // --------------------------------------------------------------

    @Test
    public void testAddCommentSucceeds() throws Exception {
        setupDocument(null);
        assertDoesNotThrow(() -> document.canContainContent(createComment(), 0, false));
    }

    @Test
    public void testCDATANotAllowed() throws Exception {
        setupDocument(null);
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createCDATA(), 0, false));
        assertEquals("A CDATA is not allowed at the document root", ex.getMessage());
    }

    @Test
    public void testTextNotAllowed() throws Exception {
        setupDocument(null);
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createText(), 0, false));
        assertEquals("A Text is not allowed at the document root", ex.getMessage());
    }

    @Test
    public void testEntityRefNotAllowed() throws Exception {
        setupDocument(null);
        IllegalAddException ex = assertThrows(IllegalAddException.class,
                () -> document.canContainContent(createEntityRef(), 0, false));
        assertEquals("An EntityRef is not allowed at the document root", ex.getMessage());
    }
}