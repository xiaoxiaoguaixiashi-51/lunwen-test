package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class MetaphoneTest {

    @Test
    public void test_null_input_returns_empty_string() {
        Metaphone metaphone = new Metaphone();
        assertEquals("", metaphone.metaphone(null));
    }

    @Test
    public void test_empty_string_returns_empty_string() {
        Metaphone metaphone = new Metaphone();
        assertEquals("", metaphone.metaphone(""));
    }

    @Test
    public void test_single_character_uppercased() {
        Metaphone metaphone = new Metaphone();
        assertEquals("A", metaphone.metaphone("a"));
    }

    @Test
    public void test_basic_word_hello() {
        Metaphone metaphone = new Metaphone();
        assertEquals("HL", metaphone.metaphone("hello"));
    }

    @Test
    public void test_basic_word_world() {
        Metaphone metaphone = new Metaphone();
        assertEquals("WRLT", metaphone.metaphone("world"));
    }

    @Test
    public void test_max_code_len_truncation() {
        Metaphone metaphone = new Metaphone();
        metaphone.setMaxCodeLen(2);
        String result = metaphone.metaphone("testing");
        assertEquals("TS", result);
        assertTrue(result.length() <= 2);
    }

    @Test
    public void test_initial_kn_rule() {
        Metaphone metaphone = new Metaphone();
        assertEquals("N", metaphone.metaphone("knight"));
    }

    @Test
    public void test_initial_wr_rule() {
        Metaphone metaphone = new Metaphone();
        assertEquals("RNX", metaphone.metaphone("wrench"));
    }

    @Test
    public void test_initial_wh_rule() {
        Metaphone metaphone = new Metaphone();
        assertEquals("WT", metaphone.metaphone("what"));
    }

    @Test
    public void test_initial_x_becomes_s() {
        Metaphone metaphone = new Metaphone();
        assertEquals("SFR", metaphone.metaphone("xavier"));
    }

    @Test
    public void test_b_silent_after_m_at_end() {
        Metaphone metaphone = new Metaphone();
        assertEquals("TM", metaphone.metaphone("dumb"));
    }

    @Test
    public void test_c_following_s_and_front_vowel_dropped() {
        Metaphone metaphone = new Metaphone();
        assertEquals("SNS", metaphone.metaphone("science"));
    }

    @Test
    public void test_c_ia_to_x() {
        Metaphone metaphone = new Metaphone();
        assertEquals("SXL", metaphone.metaphone("social"));
    }

    @Test
    public void test_c_front_vowel_becomes_s() {
        Metaphone metaphone = new Metaphone();
        assertEquals("SNT", metaphone.metaphone("cent"));
    }

    @Test
    public void test_sch_becomes_k() {
        Metaphone metaphone = new Metaphone();
        assertEquals("SKL", metaphone.metaphone("school"));
    }

    @Test
    public void test_ch_becomes_x_for_vowel() {
        Metaphone metaphone = new Metaphone();
        assertEquals("XN", metaphone.metaphone("chain"));
    }

    @Test
    public void test_dge_rule() {
        Metaphone metaphone = new Metaphone();
        assertEquals("EJ", metaphone.metaphone("edge"));
    }

    @Test
    public void test_g_gh_silent_at_end() {
        Metaphone metaphone = new Metaphone();
        assertEquals("B", metaphone.metaphone("bough"));
    }

    @Test
    public void test_g_gh_silent_before_consonant() {
        Metaphone metaphone = new Metaphone();
        assertEquals("W", metaphone.metaphone("weight"));
    }

    @Test
    public void test_gn_silent() {
        Metaphone metaphone = new Metaphone();
        assertEquals("NM", metaphone.metaphone("gnome"));
    }

    @Test
    public void test_ph_rule() {
        Metaphone metaphone = new Metaphone();
        assertEquals("FN", metaphone.metaphone("phone"));
    }

    @Test
    public void test_sh_sio_sia_rule() {
        Metaphone metaphone = new Metaphone();
        assertEquals("XT", metaphone.metaphone("shout"));
    }

    @Test
    public void test_th_rule() {
        Metaphone metaphone = new Metaphone();
        assertEquals("0N", metaphone.metaphone("thin"));
    }

    @Test
    public void test_w_y_silent_if_not_followed_by_vowel() {
        Metaphone metaphone = new Metaphone();
        assertEquals("", metaphone.metaphone("why"));
    }

    @Test
    public void test_vowel_only_at_start() {
        Metaphone metaphone = new Metaphone();
        assertEquals("ELFNT", metaphone.metaphone("elephant"));
    }

    @Test
    public void test_duplicate_letters_removed_except_c() {
        Metaphone metaphone = new Metaphone();
        assertEquals("BL", metaphone.metaphone("ball"));
    }
}