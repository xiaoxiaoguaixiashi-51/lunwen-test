package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class NysiisTest {

    private Nysiis strictEncoder;
    private Nysiis nonStrictEncoder;

    @BeforeEach
    public void setUp() {
        strictEncoder = new Nysiis(true);
        nonStrictEncoder = new Nysiis(false);
    }

    @Test
    public void testNullInput() {
        assertNull(strictEncoder.nysiis(null));
        assertNull(nonStrictEncoder.nysiis(null));
    }

    @Test
    public void testEmptyStringAfterCleaning() {
        assertEquals("", strictEncoder.nysiis("   "));
        assertEquals("", nonStrictEncoder.nysiis("   "));
    }

    @Test
    public void testSingleCharacter() {
        assertEquals("A", strictEncoder.nysiis("A"));
        assertEquals("A", nonStrictEncoder.nysiis("A"));
    }

    @Test
    public void testMacPrefixStrict() {
        assertEquals("MCDANA", strictEncoder.nysiis("MacDonald"));
    }

    @Test
    public void testMacPrefixNonStrict() {
        assertEquals("MCDANALD", nonStrictEncoder.nysiis("MacDonald"));
    }

    @Test
    public void testKnPrefix() {
        assertEquals("NAT", strictEncoder.nysiis("Knuth"));
        assertEquals("NAT", nonStrictEncoder.nysiis("Knuth"));
    }

    @Test
    public void testKPrefix() {
        assertEquals("CALAL", strictEncoder.nysiis("Khalil"));
        assertEquals("CALAL", nonStrictEncoder.nysiis("Khalil"));
    }

    @Test
    public void testPhPfPrefix() {
        assertEquals("FAP", strictEncoder.nysiis("Phipps"));
        assertEquals("FAP", nonStrictEncoder.nysiis("Phipps"));
    }

    @Test
    public void testSchPrefix() {
        assertEquals("SALT", strictEncoder.nysiis("Schultz"));
        assertEquals("SALT", nonStrictEncoder.nysiis("Schultz"));
    }

    @Test
    public void testEeIeEnding() {
        assertEquals("MARY", strictEncoder.nysiis("Marie"));
        assertEquals("MARY", nonStrictEncoder.nysiis("Marie"));
    }

    @Test
    public void testDtEtcEnding() {
        assertEquals("ED", strictEncoder.nysiis("End"));
        assertEquals("ED", nonStrictEncoder.nysiis("End"));
    }

    @Test
    public void testLastCharacterSRule() {
        assertEquals("ADAN", strictEncoder.nysiis("Adams"));
        assertEquals("ADAN", nonStrictEncoder.nysiis("Adams"));
    }

    @Test
    public void testLastCharactersAYRule() {
        assertEquals("BY", strictEncoder.nysiis("Bay"));
        assertEquals("BY", nonStrictEncoder.nysiis("Bay"));
    }

    @Test
    public void testLastCharacterARule() {
        assertEquals("AN", strictEncoder.nysiis("Anna"));
        assertEquals("AN", nonStrictEncoder.nysiis("Anna"));
    }

    @Test
    public void testTranscodeRemaining_EVtoAF() {
        assertEquals("SAFAN", strictEncoder.nysiis("Sevan"));
        assertEquals("SAFAN", nonStrictEncoder.nysiis("Sevan"));
    }

    @Test
    public void testTranscodeRemaining_H_SurroundingVowel() {
        assertEquals("AH", strictEncoder.nysiis("Aha"));
        assertEquals("AH", nonStrictEncoder.nysiis("Aha"));
    }

    @Test
    public void testTranscodeRemaining_H_NonVowelPrev() {
        assertEquals("BO", strictEncoder.nysiis("Boh"));
        assertEquals("BO", nonStrictEncoder.nysiis("Boh"));
    }

    @Test
    public void testTranscodeRemaining_W_VowelPrev() {
        assertEquals("SA", strictEncoder.nysiis("Saw"));
        assertEquals("SA", nonStrictEncoder.nysiis("Saw"));
    }

    @Test
    public void testTranscodeRemaining_W_NonVowelPrev() {
        assertEquals("SWAN", strictEncoder.nysiis("Swan"));
        assertEquals("SWAN", nonStrictEncoder.nysiis("Swan"));
    }

    @Test
    public void testDuplicateCharacterRemoval() {
        assertEquals("ABAT", strictEncoder.nysiis("Abbott"));
        assertEquals("ABAT", nonStrictEncoder.nysiis("Abbott"));
    }

    @Test
    public void testStrictModeTruncation() {
        assertEquals("ABCDEF", strictEncoder.nysiis("abcdefghij"));
    }

    @Test
    public void testNonStrictModeNoTruncation() {
        assertEquals("WASANGTAN", nonStrictEncoder.nysiis("Washington"));
    }
}