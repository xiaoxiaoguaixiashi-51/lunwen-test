package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MatchRatingApproachEncoderIsEncodeEqualsTest {

    private MatchRatingApproachEncoder encoder;

    @BeforeEach
    void setUp() {
        encoder = new MatchRatingApproachEncoder();
    }

    @Test
    void testIsEncodeEquals_FirstArgumentNull_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals(null, "John"));
    }

    @Test
    void testIsEncodeEquals_SecondArgumentNull_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("John", null));
    }

    @Test
    void testIsEncodeEquals_EmptyFirstArgument_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("", "John"));
    }

    @Test
    void testIsEncodeEquals_EmptySecondArgument_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("John", ""));
    }

    @Test
    void testIsEncodeEquals_SpaceAsFirstArgument_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("   ", "John"));
    }

    @Test
    void testIsEncodeEquals_SpaceAsSecondArgument_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("John", "   "));
    }

    @Test
    void testIsEncodeEquals_SingleCharacterFirstArgument_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("A", "John"));
    }

    @Test
    void testIsEncodeEquals_SingleCharacterSecondArgument_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("John", "B"));
    }

    @Test
    void testIsEncodeEquals_BothArgumentsEmpty_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("", ""));
    }

    @Test
    void testIsEncodeEquals_BothArgumentsBlank_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("   ", "   "));
    }

    @Test
    void testIsEncodeEquals_IdenticalNamesIgnoreCase_ReturnsTrue() {
        assertTrue(encoder.isEncodeEquals("John", "JOHN"));
    }

    @Test
    void testIsEncodeEquals_EncodedLengthDifferenceThreeOrMore_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("Christopher", "Chris"));
    }

    @Test
    void testIsEncodeEquals_SimilarNamesMraMatch_ReturnsTrue() {
        assertTrue(encoder.isEncodeEquals("Stephen", "Steven"));
    }

    @Test
    void testIsEncodeEquals_AccentedVsNonAccented_ReturnsTrue() {
        assertTrue(encoder.isEncodeEquals("André", "Andre"));
    }

    @Test
    void testIsEncodeEquals_DissimilarNames_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("John", "Smith"));
    }

    @Test
    void testIsEncodeEquals_CleanNameProducesEmpty_ThrowsException() {
        assertThrows(StringIndexOutOfBoundsException.class, () -> encoder.isEncodeEquals("&&&", "&"));
    }

    @Test
    void testIsEncodeEquals_WhitespaceVariations_ReturnsTrueWhenEquivalent() {
        assertTrue(encoder.isEncodeEquals(" John ", "John"));
    }

    @Test
    void testIsEncodeEquals_NamesWithPunctuation_ReturnsCorrectly() {
        assertTrue(encoder.isEncodeEquals("O'Brien", "OBrien"));
    }

    @Test
    void testIsEncodeEquals_EncodedLengthDifferenceTwoButSimilarityInsufficient_ReturnsFalse() {
        assertFalse(encoder.isEncodeEquals("ABC", "CDE"));
    }

    @Test
    void testIsEncodeEquals_EncodedLengthDifferenceTwoButSimilaritySufficient_ReturnsTrue() {
        assertFalse(encoder.isEncodeEquals("AB", "ABCD"));
    }

    @Test
    void testIsEncodeEquals_EmptyAfterCleanName_PathControlled() {
        assertThrows(StringIndexOutOfBoundsException.class, () -> encoder.isEncodeEquals("\\-", "[,]"));
    }
}