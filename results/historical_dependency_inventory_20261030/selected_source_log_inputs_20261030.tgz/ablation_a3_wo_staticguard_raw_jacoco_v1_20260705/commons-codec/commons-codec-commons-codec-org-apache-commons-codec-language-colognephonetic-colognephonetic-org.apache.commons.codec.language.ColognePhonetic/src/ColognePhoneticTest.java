package org.apache.commons.codec.language;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

public class ColognePhoneticTest {

    private final ColognePhonetic colognePhonetic = new ColognePhonetic();

    @Test
    public void test_null_input() {
        assertNull(colognePhonetic.colognePhonetic(null));
    }

    @Test
    public void test_empty_string() {
        assertEquals("", colognePhonetic.colognePhonetic(""));
    }

    @Test
    public void test_only_non_alpha_characters() {
        assertEquals("", colognePhonetic.colognePhonetic("1234-!?"));
    }

    @Test
    public void test_single_vowel() {
        assertEquals("0", colognePhonetic.colognePhonetic("A"));
    }

    @Test
    public void test_multiple_vowels_only() {
        assertEquals("0", colognePhonetic.colognePhonetic("AEIOU"));
    }

    @Test
    public void test_consecutive_duplicate_merge() {
        assertEquals("1", colognePhonetic.colognePhonetic("BB"));
    }

    @Test
    public void test_zero_removal_except_start() {
        assertEquals("01", colognePhonetic.colognePhonetic("AB"));
    }

    @Test
    public void test_complex_known_name() {
        assertEquals("65752682", colognePhonetic.colognePhonetic("Müller-Lüdenscheidt"));
    }

    @Test
    public void test_special_letter_H() {
        assertEquals("3", colognePhonetic.colognePhonetic("PH"));
    }

    @Test
    public void test_letter_P_not_before_H() {
        assertEquals("1", colognePhonetic.colognePhonetic("PA"));
    }

    @Test
    public void test_special_c_start_with_AHKLOQRUX() {
        assertEquals("4", colognePhonetic.colognePhonetic("CA"));
    }

    @Test
    public void test_special_c_start_not_AHKLOQRUX() {
        assertEquals("8", colognePhonetic.colognePhonetic("CB"));
    }

    @Test
    public void test_special_c_after_SZ() {
        assertEquals("8", colognePhonetic.colognePhonetic("SC"));
    }

    @Test
    public void test_special_c_middle_with_AHKOQUX() {
        assertEquals("04", colognePhonetic.colognePhonetic("ACO"));
    }

    @Test
    public void test_special_c_middle_without_AHKOQUX() {
        assertEquals("08", colognePhonetic.colognePhonetic("ACB"));
    }

    @Test
    public void test_X_not_after_CKQ() {
        assertEquals("48", colognePhonetic.colognePhonetic("AX"));
    }

    @Test
    public void test_X_after_C() {
        assertEquals("48", colognePhonetic.colognePhonetic("CX"));
    }

    @Test
    public void test_D_not_before_CSZ() {
        assertEquals("2", colognePhonetic.colognePhonetic("DA"));
    }

    @Test
    public void test_D_before_C() {
        assertEquals("8", colognePhonetic.colognePhonetic("DC"));
    }

    @Test
    public void test_T_before_Z() {
        assertEquals("8", colognePhonetic.colognePhonetic("TZ"));
    }

    @Test
    public void test_preprocess_german_umlaut_A() {
        assertEquals("0", colognePhonetic.colognePhonetic("Ä"));
    }

    @Test
    public void test_preprocess_eszett() {
        assertEquals("8", colognePhonetic.colognePhonetic("ß"));
    }

    @Test
    public void test_consonant_with_diacritics_and_space() {
        assertEquals("657", colognePhonetic.colognePhonetic("Mü ller"));
    }
}