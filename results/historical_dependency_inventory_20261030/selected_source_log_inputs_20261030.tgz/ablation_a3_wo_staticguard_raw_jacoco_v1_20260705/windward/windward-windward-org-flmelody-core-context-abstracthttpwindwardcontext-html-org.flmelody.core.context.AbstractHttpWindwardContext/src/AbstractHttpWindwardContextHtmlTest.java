package org.flmelody.core.context;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import org.flmelody.core.HttpStatus;
import org.flmelody.core.MediaType;
import org.flmelody.core.Windward;
import org.flmelody.core.WindwardRequest;
import org.flmelody.core.WindwardResponse;
import org.flmelody.core.exception.WindwardException;
import org.flmelody.core.plugin.json.JsonPlugin;
import org.flmelody.core.plugin.view.AbstractViewPlugin;
import org.junit.Test;
import org.mockito.MockedStatic;

class AbstractHttpWindwardContextHtmlTest {

  private final WindwardRequest windwardRequest = mock(WindwardRequest.class);
  private final WindwardResponse windwardResponse = mock(WindwardResponse.class);

  private AbstractHttpWindwardContext createContext() {
    return new AbstractHttpWindwardContext(windwardRequest, windwardResponse) {};
  }

  @Test
  public void test_html_null_viewUrl_throwsException() {
    AbstractHttpWindwardContext context = createContext();
    WindwardException exception =
        assertThrows(WindwardException.class, () -> context.html(null, new Object()));
    assertEquals("View name is empty!", exception.getMessage());
  }

  @Test
  public void test_html_empty_viewUrl_throwsException() {
    AbstractHttpWindwardContext context = createContext();
    WindwardException exception =
        assertThrows(WindwardException.class, () -> context.html("", new Object()));
    assertEquals("View name is empty!", exception.getMessage());
  }

  @Test
  public void test_html_no_extension_throwsException() {
    AbstractHttpWindwardContext context = createContext();
    WindwardException exception =
        assertThrows(WindwardException.class, () -> context.html("noext", new Object()));
    assertEquals("Unknown View extension!", exception.getMessage());
  }

  @Test
  public void test_html_unsupported_extension_throwsException() {
    try (MockedStatic<Windward> mockedWindward = mockStatic(Windward.class)) {
      AbstractViewPlugin mockPlugin1 = mock(AbstractViewPlugin.class);
      AbstractViewPlugin mockPlugin2 = mock(AbstractViewPlugin.class);
      when(mockPlugin1.supportedExtension("xyz")).thenReturn(false);
      when(mockPlugin2.supportedExtension("xyz")).thenReturn(false);

      mockedWindward
          .when(() -> Windward.plugins(AbstractViewPlugin.class))
          .thenReturn(Arrays.asList(mockPlugin1, mockPlugin2));

      AbstractHttpWindwardContext context = createContext();
      WindwardException exception =
          assertThrows(WindwardException.class, () -> context.html("page.xyz", new Object()));
      assertEquals("Unsupported View extension!", exception.getMessage());
    }
  }

  @Test
  public void test_html_success_path() throws Exception {
    try (MockedStatic<Windward> mockedWindward = mockStatic(Windward.class)) {
      AbstractViewPlugin supportingPlugin = mock(AbstractViewPlugin.class);
      when(supportingPlugin.supportedExtension("html")).thenReturn(true);
      doReturn("<html>rendered</html>")
          .when(supportingPlugin)
          .resolveView(eq("index.html"), any(HashMap.class));

      JsonPlugin mockJsonPlugin = mock(JsonPlugin.class);
      when(mockJsonPlugin.toObject(any(), eq(HashMap.class))).thenReturn(new HashMap<>());

      mockedWindward
          .when(() -> Windward.plugins(AbstractViewPlugin.class))
          .thenReturn(Collections.singletonList(supportingPlugin));
      mockedWindward.when(() -> Windward.plugin(JsonPlugin.class)).thenReturn(mockJsonPlugin);

      AbstractHttpWindwardContext context = createContext();
      context.html("index.html", "{ 'key': 'value' }");

      verify(windwardResponse)
          .write(
              eq(HttpStatus.OK.value()),
              eq(MediaType.TEXT_HTML_VALUE.value),
              eq(Collections.emptyMap()),
              eq("<html>rendered</html>"));
    }
  }

  @Test
  public void test_html_resolveView_throwsException_wrapsInRuntimeException() throws Exception {
    try (MockedStatic<Windward> mockedWindward = mockStatic(Windward.class)) {
      AbstractViewPlugin supportingPlugin = mock(AbstractViewPlugin.class);
      when(supportingPlugin.supportedExtension("html")).thenReturn(true);
      doThrow(new IllegalArgumentException("rendering failure"))
          .when(supportingPlugin)
          .resolveView(eq("index.html"), any(HashMap.class));

      JsonPlugin mockJsonPlugin = mock(JsonPlugin.class);
      when(mockJsonPlugin.toObject(any(), eq(HashMap.class))).thenReturn(new HashMap<>());

      mockedWindward
          .when(() -> Windward.plugins(AbstractViewPlugin.class))
          .thenReturn(Collections.singletonList(supportingPlugin));
      mockedWindward.when(() -> Windward.plugin(JsonPlugin.class)).thenReturn(mockJsonPlugin);

      AbstractHttpWindwardContext context = createContext();
      RuntimeException exception =
          assertThrows(RuntimeException.class, () -> context.html("index.html", new Object()));

      assertNotNull(exception.getCause());
      assertEquals(IllegalArgumentException.class, exception.getCause().getClass());
      assertEquals("rendering failure", exception.getCause().getMessage());
    }
  }

  @Test
  public void test_html_jsonPlugin_toObject_throwsException_wrapsInRuntimeException() {
    try (MockedStatic<Windward> mockedWindward = mockStatic(Windward.class)) {
      AbstractViewPlugin supportingPlugin = mock(AbstractViewPlugin.class);
      when(supportingPlugin.supportedExtension("html")).thenReturn(true);

      JsonPlugin mockJsonPlugin = mock(JsonPlugin.class);
      when(mockJsonPlugin.toObject(any(), eq(HashMap.class)))
          .thenThrow(new JsonProcessingException("serialization error") {});

      mockedWindward
          .when(() -> Windward.plugins(AbstractViewPlugin.class))
          .thenReturn(Collections.singletonList(supportingPlugin));
      mockedWindward.when(() -> Windward.plugin(JsonPlugin.class)).thenReturn(mockJsonPlugin);

      AbstractHttpWindwardContext context = createContext();
      RuntimeException exception =
          assertThrows(
              RuntimeException.class, () -> context.html("index.html", "invalidModel"));

      assertNotNull(exception.getCause());
      assertEquals(JsonProcessingException.class, exception.getCause().getClass());
      assertEquals("serialization error", exception.getCause().getMessage());
    }
  }

  @Test
  public void test_html_viewUrl_ends_with_dot_unsupported_extension() {
    try (MockedStatic<Windward> mockedWindward = mockStatic(Windward.class)) {
      AbstractViewPlugin mockPlugin = mock(AbstractViewPlugin.class);
      when(mockPlugin.supportedExtension("")).thenReturn(false);

      mockedWindward
          .when(() -> Windward.plugins(AbstractViewPlugin.class))
          .thenReturn(Collections.singletonList(mockPlugin));

      AbstractHttpWindwardContext context = createContext();
      WindwardException exception =
          assertThrows(WindwardException.class, () -> context.html("index.", new Object()));
      assertEquals("Unsupported View extension!", exception.getMessage());
    }
  }
}