package org.flmelody.core.netty;

import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.cors.CorsHandler;
import io.netty.handler.stream.ChunkedWriteHandler;
import java.lang.reflect.Field;
import org.flmelody.core.exception.ServerException;
import org.flmelody.core.netty.handler.HttpEventHandler;
import org.flmelody.core.netty.handler.HttpServerHandler;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.spi.LoggingEventBuilder;

@RunWith(MockitoJUnitRunner.class)
class NettyHttpServerTest {

    private NettyHttpServer server;
    private Logger mockLogger;
    private LoggingEventBuilder mockLoggingEventBuilder;
    private Field loggerField;

    @Before
    public void setUp() throws Exception {
        server = new NettyHttpServer(8080);
        // Prepare static logger replacement to verify log messages easily
        mockLogger = mock(Logger.class);
        mockLoggingEventBuilder = mock(LoggingEventBuilder.class);
        when(mockLogger.atInfo()).thenReturn(mockLoggingEventBuilder);

        loggerField = NettyHttpServer.class.getDeclaredField("logger");
        loggerField.setAccessible(true);
        loggerField.set(null, mockLogger);
    }

    @After
    public void tearDown() throws Exception {
        // Reset the logger to its original state (if necessary)
        loggerField.set(null, null); // or restore original via LoggerFactory if needed
        loggerField.setAccessible(false);
    }

    @Test
    public void shouldStartAndShutdownSuccessfully() throws Exception {
        try (MockedConstruction<NioEventLoopGroup> mockedConstruction = mockConstruction(NioEventLoopGroup.class);
             MockedStatic<LoggerFactory> mockedLoggerFactory = mockStatic(LoggerFactory.class)) {

            // Configure the mocked EventLoopGroups (boss and worker)
            EventLoopGroup bossGroup = mockedConstruction.constructed().get(0);
            EventLoopGroup workerGroup = mockedConstruction.constructed().get(1);

            // ServerBootstrap and its fluent chain
            ServerBootstrap bootstrap = mock(ServerBootstrap.class);
            when(bootstrap.group(bossGroup, workerGroup)).thenReturn(bootstrap);
            when(bootstrap.channel(NioServerSocketChannel.class)).thenReturn(bootstrap);
            when(bootstrap.childHandler(any(ChannelInitializer.class))).thenReturn(bootstrap);

            ChannelFuture bindFuture = mock(ChannelFuture.class);
            Channel mockChannel = mock(Channel.class);
            ChannelFuture closeFuture = mock(ChannelFuture.class);

            when(bindFuture.sync()).thenReturn(bindFuture);
            when(bindFuture.channel()).thenReturn(mockChannel);
            when(mockChannel.closeFuture()).thenReturn(closeFuture);
            when(closeFuture.sync()).thenReturn(closeFuture);

            when(bootstrap.bind(eq(8080))).thenReturn(bindFuture);

            // Call the method under test
            server.run();

            // Verify resource cleanup
            verify(bossGroup, times(1)).shutdownGracefully();
            verify(workerGroup, times(1)).shutdownGracefully();

            // Verify log messages
            verify(mockLoggingEventBuilder, times(1)).log("Server started success on port {}", 8080);
            verify(mockLoggingEventBuilder, times(1)).log("Server shutdown");
        }
    }

    @Test
    public void shouldThrowServerExceptionWhenBindInterrupted() throws Exception {
        try (MockedConstruction<NioEventLoopGroup> mockedConstruction = mockConstruction(NioEventLoopGroup.class);
             MockedStatic<LoggerFactory> mockedLoggerFactory = mockStatic(LoggerFactory.class)) {

            EventLoopGroup bossGroup = mockedConstruction.constructed().get(0);
            EventLoopGroup workerGroup = mockedConstruction.constructed().get(1);

            ServerBootstrap bootstrap = mock(ServerBootstrap.class);
            when(bootstrap.group(bossGroup, workerGroup)).thenReturn(bootstrap);
            when(bootstrap.channel(NioServerSocketChannel.class)).thenReturn(bootstrap);
            when(bootstrap.childHandler(any(ChannelInitializer.class))).thenReturn(bootstrap);

            ChannelFuture bindFuture = mock(ChannelFuture.class);
            when(bindFuture.sync()).thenThrow(new InterruptedException());

            when(bootstrap.bind(eq(8080))).thenReturn(bindFuture);

            // Execute and expect exception
            assertThrows(ServerException.class, () -> server.run());

            // The interrupted flag should be set
            assertTrue(Thread.currentThread().isInterrupted());

            // Clean up resources in finally block
            verify(bossGroup, times(1)).shutdownGracefully();
            verify(workerGroup, times(1)).shutdownGracefully();

            // Logs: error first, then shutdown
            verify(mockLoggingEventBuilder, times(1)).log("Server run error", any(InterruptedException.class));
            verify(mockLoggingEventBuilder, times(1)).log("Server shutdown");
        }
    }

    @Test
    public void shouldThrowServerExceptionWhenCloseFutureInterrupted() throws Exception {
        try (MockedConstruction<NioEventLoopGroup> mockedConstruction = mockConstruction(NioEventLoopGroup.class);
             MockedStatic<LoggerFactory> mockedLoggerFactory = mockStatic(LoggerFactory.class)) {

            EventLoopGroup bossGroup = mockedConstruction.constructed().get(0);
            EventLoopGroup workerGroup = mockedConstruction.constructed().get(1);

            ServerBootstrap bootstrap = mock(ServerBootstrap.class);
            when(bootstrap.group(bossGroup, workerGroup)).thenReturn(bootstrap);
            when(bootstrap.channel(NioServerSocketChannel.class)).thenReturn(bootstrap);
            when(bootstrap.childHandler(any(ChannelInitializer.class))).thenReturn(bootstrap);

            ChannelFuture bindFuture = mock(ChannelFuture.class);
            Channel mockChannel = mock(Channel.class);
            ChannelFuture closeFuture = mock(ChannelFuture.class);

            when(bindFuture.sync()).thenReturn(bindFuture);
            when(bindFuture.channel()).thenReturn(mockChannel);
            when(mockChannel.closeFuture()).thenReturn(closeFuture);
            when(closeFuture.sync()).thenThrow(new InterruptedException());

            when(bootstrap.bind(eq(8080))).thenReturn(bindFuture);

            assertThrows(ServerException.class, () -> server.run());

            assertTrue(Thread.currentThread().isInterrupted());

            verify(bossGroup, times(1)).shutdownGracefully();
            verify(workerGroup, times(1)).shutdownGracefully();

            verify(mockLoggingEventBuilder, times(1)).log("Server run error", any(InterruptedException.class));
            verify(mockLoggingEventBuilder, times(1)).log("Server shutdown");
        }
    }

    @Test
    public void shouldConfigurePipelineWithCorrectHandlers() throws Exception {
        try (MockedConstruction<NioEventLoopGroup> mockedConstruction = mockConstruction(NioEventLoopGroup.class);
             MockedStatic<LoggerFactory> mockedLoggerFactory = mockStatic(LoggerFactory.class)) {

            // Setup mocks to avoid side effects
            ServerBootstrap bootstrap = mock(ServerBootstrap.class);
            when(bootstrap.group(any(), any())).thenReturn(bootstrap);
            when(bootstrap.channel(NioServerSocketChannel.class)).thenReturn(bootstrap);

            // Capture the ChannelInitializer
            ArgumentCaptor<ChannelInitializer<SocketChannel>> captor =
                    ArgumentCaptor.forClass(ChannelInitializer.class);
            when(bootstrap.childHandler(captor.capture())).thenReturn(bootstrap);

            ChannelFuture bindFuture = mock(ChannelFuture.class);
            Channel mockChannel = mock(Channel.class);
            ChannelFuture closeFuture = mock(ChannelFuture.class);
            when(bindFuture.sync()).thenReturn(bindFuture);
            when(bindFuture.channel()).thenReturn(mockChannel);
            when(mockChannel.closeFuture()).thenReturn(closeFuture);
            when(closeFuture.sync()).thenReturn(closeFuture);
            when(bootstrap.bind(eq(8080))).thenReturn(bindFuture);

            server.run();

            // Now test the captured initializer's initChannel
            SocketChannel mockSocketChannel = mock(SocketChannel.class);
            ChannelPipeline mockPipeline = mock(ChannelPipeline.class);
            when(mockSocketChannel.pipeline()).thenReturn(mockPipeline);

            captor.getValue().initChannel(mockSocketChannel);

            // Verify handlers added in correct order
            inOrder(mockPipeline).verify(mockPipeline).addLast(any(HttpServerCodec.class));
            inOrder(mockPipeline).verify(mockPipeline).addLast(any(CorsHandler.class));
            inOrder(mockPipeline).verify(mockPipeline).addLast(any(HttpObjectAggregator.class));
            inOrder(mockPipeline).verify(mockPipeline).addLast(any(ChunkedWriteHandler.class));
            inOrder(mockPipeline).verify(mockPipeline).addLast(any(HttpServerHandler.class));
            inOrder(mockPipeline).verify(mockPipeline).addLast(any(HttpEventHandler.class));
        }
    }

    @Test
    public void shouldBindToGivenPort() throws Exception {
        try (MockedConstruction<NioEventLoopGroup> mockedConstruction = mockConstruction(NioEventLoopGroup.class);
             MockedStatic<LoggerFactory> mockedLoggerFactory = mockStatic(LoggerFactory.class)) {

            ServerBootstrap bootstrap = mock(ServerBootstrap.class);
            when(bootstrap.group(any(), any())).thenReturn(bootstrap);
            when(bootstrap.channel(NioServerSocketChannel.class)).thenReturn(bootstrap);
            when(bootstrap.childHandler(any(ChannelInitializer.class))).thenReturn(bootstrap);

            ChannelFuture bindFuture = mock(ChannelFuture.class);
            Channel mockChannel = mock(Channel.class);
            ChannelFuture closeFuture = mock(ChannelFuture.class);
            when(bindFuture.sync()).thenReturn(bindFuture);
            when(bindFuture.channel()).thenReturn(mockChannel);
            when(mockChannel.closeFuture()).thenReturn(closeFuture);
            when(closeFuture.sync()).thenReturn(closeFuture);
            when(bootstrap.bind(eq(8080))).thenReturn(bindFuture);

            server.run();

            // Verify the exact port is used in bind
            verify(bootstrap).bind(eq(8080));

            // Verify startup log contains the port
            verify(mockLoggingEventBuilder).log("Server started success on port {}", 8080);
        }
    }
}