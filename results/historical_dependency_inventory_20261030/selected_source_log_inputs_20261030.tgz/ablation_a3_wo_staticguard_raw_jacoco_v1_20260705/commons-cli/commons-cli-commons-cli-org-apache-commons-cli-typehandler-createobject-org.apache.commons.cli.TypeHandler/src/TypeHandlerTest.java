package org.apache.commons.cli;

import static org.junit.Assert.*;

import org.junit.Test;

public class TypeHandlerTest {

    // A helper class that throws a RuntimeException in its constructor for testing
    public static class FaultyClass {
        public FaultyClass() {
            throw new NullPointerException();
        }
    }

    @Test
    public void testCreateObjectWithValidClass() throws Exception {
        Object result = TypeHandler.createObject("java.lang.Object");
        assertNotNull(result);
        assertEquals(Object.class, result.getClass());
    }

    @Test
    public void testCreateObjectWithClassNotFound() {
        try {
            TypeHandler.createObject("com.nonexistent.Class");
            fail("Expected ParseException was not thrown.");
        } catch (ParseException e) {
            assertTrue(e.getMessage().contains("Unable to find the class: com.nonexistent.Class"));
        }
    }

    @Test
    public void testCreateObjectWithInstantiationException() {
        try {
            TypeHandler.createObject("java.lang.Integer");
            fail("Expected ParseException was not thrown.");
        } catch (ParseException e) {
            assertTrue(e.getMessage().startsWith(
                    "java.lang.InstantiationException; Unable to create an instance of: java.lang.Integer"));
        }
    }

    @Test
    public void testCreateObjectWithRuntimeExceptionInConstructor() {
        try {
            TypeHandler.createObject("org.apache.commons.cli.TypeHandlerTest$FaultyClass");
            fail("Expected ParseException was not thrown.");
        } catch (ParseException e) {
            assertTrue(e.getMessage().startsWith(
                    "java.lang.NullPointerException; Unable to create an instance of: org.apache.commons.cli.TypeHandlerTest$FaultyClass"));
        }
    }

    @Test(expected = NullPointerException.class)
    public void testCreateObjectWithNullClassname() throws ParseException {
        TypeHandler.createObject(null);
    }
}