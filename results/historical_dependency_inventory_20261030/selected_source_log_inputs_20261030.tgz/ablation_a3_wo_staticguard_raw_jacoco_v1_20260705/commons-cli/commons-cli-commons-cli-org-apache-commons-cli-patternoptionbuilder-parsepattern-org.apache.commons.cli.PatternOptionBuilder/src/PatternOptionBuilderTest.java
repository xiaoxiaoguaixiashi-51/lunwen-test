package org.apache.commons.cli;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.Date;

import org.junit.Test;

/**
 * Tests for {@link PatternOptionBuilder#parsePattern(String)}.
 */
public class PatternOptionBuilderTest {

    @Test
    public void testParsePattern_NullInput_ThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> PatternOptionBuilder.parsePattern(null));
    }

    @Test
    public void testParsePattern_EmptyString_ReturnsEmptyOptions() {
        final Options options = PatternOptionBuilder.parsePattern("");
        assertNotNull(options);
        assertEquals(0, options.getOptions().size());
    }

    @Test
    public void testParsePattern_SingleOptionNoModifier() {
        final Options options = PatternOptionBuilder.parsePattern("v");
        assertNotNull(options);
        assertEquals(1, options.getOptions().size());
        final Option option = options.getOption("v");
        assertNotNull(option);
        assertEquals("v", option.getOpt());
        assertFalse(option.hasArg());
        assertFalse(option.isRequired());
        assertNull(option.getType());
    }

    @Test
    public void testParsePattern_OptionWithStringType() {
        final Options options = PatternOptionBuilder.parsePattern("f/");
        assertEquals(1, options.getOptions().size());
        final Option option = options.getOption("f");
        assertNotNull(option);
        assertTrue(option.hasArg());
        assertFalse(option.isRequired());
        assertEquals(URL.class, option.getType());
    }

    @Test
    public void testParsePattern_RequiredOnlyOption() {
        final Options options = PatternOptionBuilder.parsePattern("!d");
        assertEquals(1, options.getOptions().size());
        final Option option = options.getOption("d");
        assertNotNull(option);
        assertTrue(option.isRequired());
        assertFalse(option.hasArg());
        assertNull(option.getType());
    }

    @Test
    public void testParsePattern_RequiredWithType() {
        final Options options = PatternOptionBuilder.parsePattern("!d+");
        assertEquals(1, options.getOptions().size());
        final Option option = options.getOption("d");
        assertNotNull(option);
        assertTrue(option.isRequired());
        assertTrue(option.hasArg());
        assertEquals(Class.class, option.getType());
    }

    @Test
    public void testParsePattern_MultipleOptionsCombination() {
        final Options options = PatternOptionBuilder.parsePattern("vp:!f/");
        assertEquals(3, options.getOptions().size());

        // option v
        final Option v = options.getOption("v");
        assertNotNull(v);
        assertFalse(v.hasArg());
        assertFalse(v.isRequired());
        assertNull(v.getType());

        // option p
        final Option p = options.getOption("p");
        assertNotNull(p);
        assertTrue(p.hasArg());
        assertFalse(p.isRequired());
        assertEquals(String.class, p.getType());

        // option f
        final Option f = options.getOption("f");
        assertNotNull(f);
        assertTrue(f.hasArg());
        assertTrue(f.isRequired());
        assertEquals(URL.class, f.getType());
    }

    @Test
    public void testParsePattern_OnlyExclamationMark_ReturnsEmptyOptions() {
        final Options options = PatternOptionBuilder.parsePattern("!");
        assertNotNull(options);
        assertEquals(0, options.getOptions().size());
    }

    @Test
    public void testParsePattern_ValueCodeBeforeAnyOption() {
        final Options options = PatternOptionBuilder.parsePattern("@a");
        assertEquals(1, options.getOptions().size());
        final Option option = options.getOption("a");
        assertNotNull(option);
        assertTrue(option.hasArg());
        assertEquals(Object.class, option.getType());
    }

    @Test
    public void testParsePattern_AllSupportedTypeCodes() {
        // pattern alternates option characters and value codes
        final Options options = PatternOptionBuilder.parsePattern("a@b:c%d+e#f<g>h*i/");
        assertEquals(9, options.getOptions().size());

        // verify presence and type of each option
        final Option a = options.getOption("a");
        assertNotNull(a);
        assertTrue(a.hasArg());
        assertEquals(Object.class, a.getType());

        final Option b = options.getOption("b");
        assertNotNull(b);
        assertTrue(b.hasArg());
        assertEquals(String.class, b.getType());

        final Option c = options.getOption("c");
        assertNotNull(c);
        assertTrue(c.hasArg());
        assertEquals(Number.class, c.getType());

        final Option d = options.getOption("d");
        assertNotNull(d);
        assertTrue(d.hasArg());
        assertEquals(Class.class, d.getType());

        final Option e = options.getOption("e");
        assertNotNull(e);
        assertTrue(e.hasArg());
        assertEquals(Date.class, e.getType());

        final Option f = options.getOption("f");
        assertNotNull(f);
        assertTrue(f.hasArg());
        assertEquals(FileInputStream.class, f.getType());

        final Option g = options.getOption("g");
        assertNotNull(g);
        assertTrue(g.hasArg());
        assertEquals(File.class, g.getType());

        final Option h = options.getOption("h");
        assertNotNull(h);
        assertTrue(h.hasArg());
        assertEquals(File[].class, h.getType());

        final Option i = options.getOption("i");
        assertNotNull(i);
        assertTrue(i.hasArg());
        assertEquals(URL.class, i.getType());
    }

    @Test
    public void testParsePattern_SpaceInPattern() {
        final Options options = PatternOptionBuilder.parsePattern("a b");
        assertEquals(2, options.getOptions().size());
        // option 'a'
        assertTrue(options.hasOption("a"));
        // option ' ' (space character)
        assertTrue(options.hasOption(" "));
    }

    @Test
    public void testParsePattern_ConsecutiveValueCodesWithNoOption() {
        final Options options = PatternOptionBuilder.parsePattern("!@:%");
        assertNotNull(options);
        assertEquals(0, options.getOptions().size());
    }
}