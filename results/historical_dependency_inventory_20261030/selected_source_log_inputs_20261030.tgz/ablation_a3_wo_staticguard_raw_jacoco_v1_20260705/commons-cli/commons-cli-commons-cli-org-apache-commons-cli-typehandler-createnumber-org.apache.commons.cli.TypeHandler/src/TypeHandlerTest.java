package org.apache.commons.cli;

import static org.junit.Assert.*;

import org.junit.Test;

public class TypeHandlerTest {

    @Test
    public void testCreateNumber_IntegerString_ReturnsLong() throws ParseException {
        Number result = TypeHandler.createNumber("12345");
        assertEquals(Long.valueOf(12345L), result);
        assertTrue(result instanceof Long);
    }

    @Test
    public void testCreateNumber_DecimalString_ReturnsDouble() throws ParseException {
        Number result = TypeHandler.createNumber("123.45");
        assertEquals(Double.valueOf(123.45), result);
        assertTrue(result instanceof Double);
    }

    @Test
    public void testCreateNumber_NegativeInteger_ReturnsLong() throws ParseException {
        Number result = TypeHandler.createNumber("-100");
        assertEquals(Long.valueOf(-100L), result);
        assertTrue(result instanceof Long);
    }

    @Test
    public void testCreateNumber_NegativeDecimal_ReturnsDouble() throws ParseException {
        Number result = TypeHandler.createNumber("-3.14");
        assertEquals(Double.valueOf(-3.14), result);
        assertTrue(result instanceof Double);
    }

    @Test
    public void testCreateNumber_ScientificNotation_ReturnsDouble() throws ParseException {
        Number result = TypeHandler.createNumber("1.5e10");
        assertEquals(Double.valueOf(1.5e10), result);
        assertTrue(result instanceof Double);
    }

    @Test
    public void testCreateNumber_ZeroInteger_ReturnsLongZero() throws ParseException {
        Number result = TypeHandler.createNumber("0");
        assertEquals(Long.valueOf(0L), result);
        assertTrue(result instanceof Long);
    }

    @Test
    public void testCreateNumber_ZeroDecimal_ReturnsDoubleZero() throws ParseException {
        Number result = TypeHandler.createNumber("0.0");
        assertEquals(Double.valueOf(0.0), result);
        assertTrue(result instanceof Double);
    }

    @Test
    public void testCreateNumber_MaxLongBoundary_ReturnsLong() throws ParseException {
        Number result = TypeHandler.createNumber("9223372036854775807");
        assertEquals(Long.valueOf(Long.MAX_VALUE), result);
    }

    @Test
    public void testCreateNumber_TooLargeNumber_ThrowsParseException() {
        try {
            TypeHandler.createNumber("99999999999999999999");
            fail("Expected ParseException to be thrown");
        } catch (ParseException e) {
            // expected
        }
    }

    @Test
    public void testCreateNumber_InvalidString_ThrowsParseException() {
        try {
            TypeHandler.createNumber("abc");
            fail("Expected ParseException to be thrown");
        } catch (ParseException e) {
            // expected
        }
    }

    @Test
    public void testCreateNumber_EmptyString_ThrowsParseException() {
        try {
            TypeHandler.createNumber("");
            fail("Expected ParseException to be thrown");
        } catch (ParseException e) {
            // expected
        }
    }

    @Test
    public void testCreateNumber_DotOnly_ThrowsParseException() {
        try {
            TypeHandler.createNumber(".");
            fail("Expected ParseException to be thrown");
        } catch (ParseException e) {
            // expected
        }
    }

    @Test
    public void testCreateNumber_TrailingSpace_ThrowsParseException() {
        try {
            TypeHandler.createNumber("123 ");
            fail("Expected ParseException to be thrown");
        } catch (ParseException e) {
            // expected
        }
    }

    @Test
    public void testCreateNumber_NullString_ThrowsNullPointerException() throws ParseException {
        try {
            TypeHandler.createNumber(null);
            fail("Expected NullPointerException to be thrown");
        } catch (NullPointerException e) {
            // expected
        }
    }
}