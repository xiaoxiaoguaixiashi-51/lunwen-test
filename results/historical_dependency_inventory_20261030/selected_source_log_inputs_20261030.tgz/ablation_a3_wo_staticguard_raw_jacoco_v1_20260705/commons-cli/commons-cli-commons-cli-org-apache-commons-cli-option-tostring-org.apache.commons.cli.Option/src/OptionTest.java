package org.apache.commons.cli;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Unit tests for {@link Option#toString()}.
 */
public class OptionTest {

    @Test
    public void testToString_OnlyShortOptionAndDescription() {
        // Given: only short option "a", description "test desc", no long option, no argument, type null
        final Option option = Option.builder("a")
                .desc("test desc")
                .type(null)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: a  :: test desc ]", result);
    }

    @Test
    public void testToString_WithLongOptionAndRequiredArg() {
        // Given: short option "f", long option "file", required argument (hasArg), description "output file", type null
        final Option option = Option.builder("f")
                .longOpt("file")
                .desc("output file")
                .hasArg()
                .type(null)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: f file  [ARG] :: output file ]", result);
    }

    @Test
    public void testToString_WithUnlimitedArgsAndType() {
        // Given: option "D", unlimited arguments (hasArgs), type String, description "properties"
        final Option option = Option.builder("D")
                .desc("properties")
                .hasArgs()
                .type(String.class)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: D [ARG...] :: properties :: class java.lang.String ]", result);
    }

    @Test
    public void testToString_WithLongOptionNoArgAndType() {
        // Given: short option "n", long option "number", no argument, type Integer
        final Option option = Option.builder("n")
                .longOpt("number")
                .desc("value")
                .type(Integer.class)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: n number  :: value :: class java.lang.Integer ]", result);
    }

    @Test
    public void testToString_WithTypeAndNoArgument() {
        // Given: short option "t", no long option, no argument, type Float
        final Option option = Option.builder("t")
                .desc("time")
                .type(Float.class)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: t  :: time :: class java.lang.Float ]", result);
    }

    @Test
    public void testToString_ArgCountZero() {
        // Given: short option "x", argCount 0 (no argument), type null
        final Option option = Option.builder("x")
                .desc("zero args")
                .numberOfArgs(0)
                .type(null)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: x  :: zero args ]", result);
    }

    @Test
    public void testToString_MultipleArgsNoType() {
        // Given: short option "y", argCount 2 (hasArgs), no long option, type null
        final Option option = Option.builder("y")
                .desc("multiple")
                .numberOfArgs(2)
                .type(null)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: y [ARG...] :: multiple ]", result);
    }

    @Test
    public void testToString_DescriptionNull() {
        // Given: short option "z", description null, no argument, type null
        final Option option = Option.builder("z")
                .desc(null)
                .type(null)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: z  :: null ]", result);
    }

    @Test
    public void testToString_TypeNull() {
        // Given: short option "a", description "desc", type explicitly null
        final Option option = Option.builder("a")
                .desc("desc")
                .type(null)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: a  :: desc ]", result);
    }

    @Test
    public void testToString_AllFeatures() {
        // Given: short option "f", long option "file", unlimited arguments, type Double, description "output"
        final Option option = Option.builder("f")
                .longOpt("file")
                .desc("output")
                .hasArgs()
                .type(Double.class)
                .build();

        // When
        final String result = option.toString();

        // Then
        assertEquals("[ option: f file [ARG...] :: output :: class java.lang.Double ]", result);
    }
}