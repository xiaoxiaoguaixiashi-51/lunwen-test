package org.apache.commons.cli;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class OptionGroupToStringTest {

    @Test
    public void testToString_EmptyGroup() {
        final OptionGroup group = new OptionGroup();
        assertEquals("[]", group.toString());
    }

    @Test
    public void testToString_SingleOptionShortOptWithDescription() {
        final OptionGroup group = new OptionGroup();
        final Option option = new Option("a", "alpha");
        group.addOption(option);
        assertEquals("[-a alpha]", group.toString());
    }

    @Test
    public void testToString_SingleOptionShortOptNullDescription() {
        final OptionGroup group = new OptionGroup();
        final Option option = new Option("b", (String) null);
        group.addOption(option);
        assertEquals("[-b]", group.toString());
    }

    @Test
    public void testToString_SingleOptionShortOptEmptyDescription() {
        final OptionGroup group = new OptionGroup();
        final Option option = new Option("c", "");
        group.addOption(option);
        assertEquals("[-c ]", group.toString());
    }

    @Test
    public void testToString_SingleOptionLongOptWithDescription() {
        final OptionGroup group = new OptionGroup();
        final Option option = new Option(null, "verbose", false, "详细输出");
        group.addOption(option);
        assertEquals("[--verbose 详细输出]", group.toString());
    }

    @Test
    public void testToString_MultipleOptionsMixed() {
        final OptionGroup group = new OptionGroup();

        final Option optionA = new Option("x", "alpha");
        final Option optionB = new Option(null, "verbose", false, null);
        final Option optionC = new Option("y", "");

        group.addOption(optionA);
        group.addOption(optionB);
        group.addOption(optionC);

        assertEquals("[-x alpha, --verbose, -y ]", group.toString());
    }

    @Test
    public void testToString_MultipleOptionsWithEmptyDescription() {
        final OptionGroup group = new OptionGroup();

        final Option optionD = new Option("p", (String) null);
        final Option optionE = new Option("q", "quiet");

        group.addOption(optionD);
        group.addOption(optionE);

        assertEquals("[-p, -q quiet]", group.toString());
    }
}