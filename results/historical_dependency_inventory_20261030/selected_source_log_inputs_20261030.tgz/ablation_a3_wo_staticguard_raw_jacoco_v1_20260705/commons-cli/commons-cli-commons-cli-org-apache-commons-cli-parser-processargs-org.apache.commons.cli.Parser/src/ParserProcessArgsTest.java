package org.apache.commons.cli;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@link Parser#processArgs(Option, ListIterator)} without using Mockito.
 */
public class ParserProcessArgsTest {

    // A concrete subclass of Parser that exposes setOptions and provides a dummy flatten implementation.
    private static class TestParser extends Parser {
        @Override
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
            return new String[0]; // not used in processArgs tests
        }

        public void setOptionsPublic(Options options) {
            super.setOptions(options);
        }

        public Options getOptionsPublic() {
            return super.getOptions();
        }
    }

    // A ListIterator wrapper that counts calls to previous() (and optionally other methods).
    private static class CountingListIterator implements ListIterator<String> {
        private final ListIterator<String> delegate;
        private int previousCount = 0;

        CountingListIterator(ListIterator<String> delegate) {
            this.delegate = delegate;
        }

        @Override
        public boolean hasNext() {
            return delegate.hasNext();
        }

        @Override
        public String next() {
            return delegate.next();
        }

        @Override
        public boolean hasPrevious() {
            return delegate.hasPrevious();
        }

        @Override
        public String previous() {
            previousCount++;
            return delegate.previous();
        }

        @Override
        public int nextIndex() {
            return delegate.nextIndex();
        }

        @Override
        public int previousIndex() {
            return delegate.previousIndex();
        }

        @Override
        public void remove() {
            delegate.remove();
        }

        @Override
        public void set(String e) {
            delegate.set(e);
        }

        @Override
        public void add(String e) {
            delegate.add(e);
        }

        public int getPreviousCount() {
            return previousCount;
        }
    }

    // A Option subclass that throws a RuntimeException when addValueForProcessing is called.
    private static class OptionThrowingOnAdd extends Option {
        private final RuntimeException exception;

        public OptionThrowingOnAdd(String opt, String description, RuntimeException exception) {
            super(opt, description);
            this.exception = exception;
        }

        @Override
        public void addValueForProcessing(String value) {
            throw exception;
        }
    }

    private TestParser parser;

    @Before
    public void setUp() {
        parser = new TestParser();
    }

    /**
     * Configure the parser with given Options.
     */
    private void setOptions(Options options) {
        parser.setOptionsPublic(options);
    }

    /**
     * Create an Options instance containing the given option strings.
     */
    private Options optionsWith(String... opts) {
        Options options = new Options();
        for (String opt : opts) {
            options.addOption(new Option(opt, ""));
        }
        return options;
    }

    // High priority: normal argument processing with a value token followed by an option token.
    @Test
    public void testProcessValueThenOptionToken() throws ParseException {
        // arrange
        List<String> tokens = new ArrayList<>();
        tokens.add("value1");
        tokens.add("-x");
        CountingListIterator iter = new CountingListIterator(tokens.listIterator());

        // Setup Options: hasOption("-x") returns true, hasOption("value1") false
        Options opts = new Options();
        opts.addOption(new Option("x", ""));
        setOptions(opts);

        // Create option that takes an argument, no optional arg, initially no values
        Option opt = new Option("x", true, "");
        opt.setOptionalArg(false); // hasOptionalArg() == false
        // getValues() is null until a value is added

        // act
        parser.processArgs(opt, iter);

        // assert
        // opt should have the value "value1"
        String[] values = opt.getValues();
        assertEquals(1, values.length);
        assertEquals("value1", values[0]);
        // previous() should have been called once (when "-x" was encountered)
        assertEquals(1, iter.getPreviousCount());
        // Process ends, so hasNext() is called at least once inside while. Iter has been advanced.
        // We don't check exact count but we know iteration stopped.
    }

    // High priority: addValueForProcessing throws RuntimeException; token is pushed back.
    @Test
    public void testAddValueForProcessingThrowsRuntimeException() throws ParseException {
        // arrange
        List<String> tokens = new ArrayList<>();
        tokens.add("badValue");
        tokens.add("-y");
        CountingListIterator iter = new CountingListIterator(tokens.listIterator());

        Options opts = new Options();
        opts.addOption(new Option("y", ""));
        setOptions(opts);

        // An option that throws RuntimeException on addValueForProcessing
        Option opt = new OptionThrowingOnAdd("y", "test",
                new RuntimeException("addValueForProcessing failed"));
        // hasOptionalArg() should be false to not throw MissingArgumentException if getValues() is null
        opt.setOptionalArg(false);
        // Ensure getValues() returns null; after exception, values stay null, but that triggers later check?
        // processArgs: after catching RuntimeException, it breaks and then checks opt.getValues() == null && !opt.hasOptionalArg().
        // If getValues() is null and hasOptionalArg() is false -> MissingArgumentException. To avoid that, we either need
        // getValues() to be non-null or hasOptionalArg() true. In original mock, getValues() was stubbed to return new String[0],
        // so it was non-null. So we need to make getValues() return non-null initially.
        // Option's getValues() returns null unless values have been added. We need to work around that without mock.
        // We can create a Option subclass that overrides getValues() to return a non-null array.
        // Let's create a Option with initial value or override.
        // Simple approach: create a regular option and add a dummy value before using as the option in processArgs.
        // However, addValueForProcessing will throw. We can do: Option opt = new Option("y", true, "") {
        //     @Override public String[] getValues() { return new String[0]; }
        // };
        opt = new Option("y", true, "") {
            @Override
            public String[] getValues() {
                // Override to never return null after instantiation, to avoid MissingArgumentException
                return new String[0];
            }
        };
        // The above override ensures getValues() never returns null.
        // But we also need addValueForProcessing to throw. We'll use the throwing subclass but it doesn't override getValues.
        // Let's create a dedicated subclass that throws on add and returns non-null on getValues.
        opt = new OptionThrowingOnAddWithValues();
        // hasOptionalArg false is fine now.

        // act
        parser.processArgs(opt, iter);

        // assert
        assertEquals(1, iter.getPreviousCount()); // previous called once
        // getValues() should be empty (no value added because of exception)
        assertEquals(0, opt.getValues().length);
    }

    // A helper Option subclass that throws RuntimeException on addValueForProcessing and ensures getValues() never returns null.
    private static class OptionThrowingOnAddWithValues extends Option {
        public OptionThrowingOnAddWithValues() {
            super("y", true, "");
        }

        @Override
        public void addValueForProcessing(String value) {
            throw new RuntimeException("addValueForProcessing failed");
        }

        @Override
        public String[] getValues() {
            // Override to return empty array, so that the final check does not throw MissingArgumentException
            return new String[0];
        }
    }

    // High priority: no token available and option is not optional → MissingArgumentException
    @Test(expected = MissingArgumentException.class)
    public void testNoArgumentAndOptionNotOptional() throws ParseException {
        // arrange
        List<String> tokens = new ArrayList<>(); // empty
        CountingListIterator iter = new CountingListIterator(tokens.listIterator());

        Options opts = new Options();
        setOptions(opts); // no particular options needed

        Option opt = new Option("a", "desc");
        opt.setOptionalArg(false); // not optional
        // getValues() is null as no value added

        // act
        parser.processArgs(opt, iter);

        // assert: MissingArgumentException expected
    }

    // Medium priority: option has optional argument and no value supplied → no exception
    @Test
    public void testOptionalArgumentNoValueSupplied() throws ParseException {
        // arrange
        List<String> tokens = new ArrayList<>(); // empty
        CountingListIterator iter = new CountingListIterator(tokens.listIterator());

        Options opts = new Options();
        setOptions(opts);

        Option opt = new Option("b", "desc");
        opt.setOptionalArg(true); // hasOptionalArg() == true
        // getValues() is null

        // act
        parser.processArgs(opt, iter);

        // assert
        // No exception; opt should still have null values
        assertEquals(null, opt.getValues());
    }

    // Medium priority: multiple values consumed until an unrecognised option token
    @Test
    public void testMultipleValuesUntilUnrecognizedOptionToken() throws ParseException {
        // arrange
        List<String> tokens = new ArrayList<>();
        tokens.add("val1");
        tokens.add("val2");
        tokens.add("--unknown");
        CountingListIterator iter = new CountingListIterator(tokens.listIterator());

        Options opts = new Options();
        // No option should be recognized, so hasOption always false
        setOptions(opts);

        Option opt = new Option("c", true, "");
        opt.setOptionalArg(false);
        // getValues() initially null

        // act
        parser.processArgs(opt, iter);

        // assert
        String[] values = opt.getValues();
        assertEquals(3, values.length);
        assertEquals("val1", values[0]);
        assertEquals("val2", values[1]);
        assertEquals("--unknown", values[2]);
        // No previous called because we never hit an option token
        assertEquals(0, iter.getPreviousCount());
    }

    // Medium priority: a token starting with '-' but not a recognised option becomes a value.
    @Test
    public void testValueStartingWithDashButNotOptionBecomesValue() throws ParseException {
        // arrange
        List<String> tokens = new ArrayList<>();
        tokens.add("-unknown");
        CountingListIterator iter = new CountingListIterator(tokens.listIterator());

        Options opts = new Options();
        setOptions(opts); // no options

        Option opt = new Option("d", true, "");
        opt.setOptionalArg(false);

        // act
        parser.processArgs(opt, iter);

        // assert
        String[] values = opt.getValues();
        assertEquals(1, values.length);
        assertEquals("-unknown", values[0]);
        assertEquals(0, iter.getPreviousCount());
    }

    // Low priority: iterator is empty but the option already has values → no exception.
    @Test
    public void testIteratorAlreadyHasValuesAndOptional() throws ParseException {
        // arrange
        List<String> tokens = new ArrayList<>(); // empty
        CountingListIterator iter = new CountingListIterator(tokens.listIterator());

        Options opts = new Options();
        setOptions(opts);

        Option opt = new Option("e", true, "");
        opt.setOptionalArg(false);
        // Simulate already having a value by adding one directly (but we want getValues() to return non-null)
        // Since Option's values list is private, we can use addValueForProcessing if we can call it.
        // We can call opt.addValueForProcessing("existing") directly.
        opt.addValue("existing"); // Option has addValue method? Let's check API.
        // In Option class, there is addValue(String) method? It might be private or not exist.
        // Option has addValueForProcessing which is public, and also add(String) which is deprecated? Actually Option has addValue(String) method?
        // Let's examine Option class: it has public boolean addValue(String value) which adds a value.
        // So we can do opt.addValue("existing").
        opt.addValue("existing"); // This method exists in Option and adds a value.
        // Now getValues() will return array containing "existing".

        // act
        parser.processArgs(opt, iter);

        // assert
        // No exception; values unchanged
        assertArrayEquals(new String[]{"existing"}, opt.getValues());
    }
}