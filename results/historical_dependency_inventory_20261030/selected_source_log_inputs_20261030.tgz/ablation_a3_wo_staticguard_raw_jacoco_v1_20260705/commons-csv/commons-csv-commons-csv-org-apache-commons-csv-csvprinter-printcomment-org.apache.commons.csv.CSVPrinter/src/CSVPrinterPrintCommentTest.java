package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyChar;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

/**
 * Test class for {@link CSVPrinter#printComment(String)} method.
 */
class CSVPrinterPrintCommentTest {

    @Mock
    private Appendable mockAppendable;

    @Mock
    private CSVFormat format;

    @BeforeEach
    void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);
        // Common stubs used by all tests
        when(format.copy()).thenReturn(format);
        when(format.getHeaderComments()).thenReturn(null);
        when(format.getHeader()).thenReturn(null);
    }

    /**
     * Test case: testPrintComment_NullComment_ReturnsImmediately.
     * When comment is null, the method should return immediately without any interaction with the appendable
     * and without calling println, regardless of the comment marker state.
     */
    @Test
    void testPrintComment_NullComment_ReturnsImmediately() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment(null);

        // Assertions
        verifyNoInteractions(mockAppendable);
    }

    /**
     * Test case: testPrintComment_MarkerNotSet_ReturnsImmediately.
     * When comment marker is not set, the method should return immediately without any output even if comment is non-null.
     */
    @Test
    void testPrintComment_MarkerNotSet_ReturnsImmediately() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(false);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment("Some text");

        // Assertions
        verifyNoInteractions(mockAppendable);
    }

    /**
     * Test case: testPrintComment_NewRecordTrue_SimpleText.
     * Normal case: comment marker is set, newRecord is true (default), simple text.
     * Should output marker, space, characters, and a final println.
     */
    @Test
    void testPrintComment_NewRecordTrue_SimpleText() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment("Hello");

        // Assertions
        InOrder inOrder = inOrder(format, mockAppendable);

        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        for (char c : "Hello".toCharArray()) {
            inOrder.verify(mockAppendable).append(eq(c));
        }
        inOrder.verify(format).println(mockAppendable);

        verify(format).println(mockAppendable); // ensure exactly one println call
    }

    /**
     * Test case: testPrintComment_NewRecordFalse_PrintsLeadNewline.
     * If newRecord is false, the method first calls println() to start a new record before printing the comment.
     * This test simulates newRecord = false by calling printer.print("x") prior to the comment.
     */
    @Test
    void testPrintComment_NewRecordFalse_PrintsLeadNewline() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);
        doNothing().when(format).print(any(), any(), anyBoolean());

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);
        printer.print("x"); // this sets newRecord to false

        // Execute
        printer.printComment("Note");

        // Assertions
        InOrder inOrder = inOrder(format, mockAppendable);

        inOrder.verify(format).println(mockAppendable); // leading newline because newRecord was false
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        for (char c : "Note".toCharArray()) {
            inOrder.verify(mockAppendable).append(eq(c));
        }
        inOrder.verify(format).println(mockAppendable); // final println

        verify(format, org.mockito.Mockito.times(2)).println(mockAppendable);
    }

    /**
     * Test case: testPrintComment_CommentWithLF_InsertsRecordSeparator.
     * Comment contains LF character: should break the line, call println,
     * then restart a new comment line with marker and space.
     */
    @Test
    void testPrintComment_CommentWithLF_InsertsRecordSeparator() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment("line1\nline2");

        // Assertions
        InOrder inOrder = inOrder(format, mockAppendable);

        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('l'));
        inOrder.verify(mockAppendable).append(eq('i'));
        inOrder.verify(mockAppendable).append(eq('n'));
        inOrder.verify(mockAppendable).append(eq('e'));
        inOrder.verify(mockAppendable).append(eq('1'));
        inOrder.verify(format).println(mockAppendable); // break at LF
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('l'));
        inOrder.verify(mockAppendable).append(eq('i'));
        inOrder.verify(mockAppendable).append(eq('n'));
        inOrder.verify(mockAppendable).append(eq('e'));
        inOrder.verify(mockAppendable).append(eq('2'));
        inOrder.verify(format).println(mockAppendable); // final println

        verify(format, org.mockito.Mockito.times(2)).println(mockAppendable);
    }

    /**
     * Test case: testPrintComment_CommentWithCR_InsertsRecordSeparator.
     * Comment contains CR character: similar to LF, should break line and restart comment marker.
     */
    @Test
    void testPrintComment_CommentWithCR_InsertsRecordSeparator() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment("line1\rline2");

        // Assertions
        InOrder inOrder = inOrder(format, mockAppendable);

        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('l'));
        inOrder.verify(mockAppendable).append(eq('i'));
        inOrder.verify(mockAppendable).append(eq('n'));
        inOrder.verify(mockAppendable).append(eq('e'));
        inOrder.verify(mockAppendable).append(eq('1'));
        inOrder.verify(format).println(mockAppendable); // break at CR
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('l'));
        inOrder.verify(mockAppendable).append(eq('i'));
        inOrder.verify(mockAppendable).append(eq('n'));
        inOrder.verify(mockAppendable).append(eq('e'));
        inOrder.verify(mockAppendable).append(eq('2'));
        inOrder.verify(format).println(mockAppendable); // final println

        verify(format, org.mockito.Mockito.times(2)).println(mockAppendable);
    }

    /**
     * Test case: testPrintComment_CommentWithCRLF_PairHandled.
     * Comment contains CRLF pair: should be treated as a single line break (skip the LF),
     * then restart comment marker.
     */
    @Test
    void testPrintComment_CommentWithCRLF_PairHandled() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment("line1\r\nline2");

        // Assertions
        InOrder inOrder = inOrder(format, mockAppendable);

        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('l'));
        inOrder.verify(mockAppendable).append(eq('i'));
        inOrder.verify(mockAppendable).append(eq('n'));
        inOrder.verify(mockAppendable).append(eq('e'));
        inOrder.verify(mockAppendable).append(eq('1'));
        inOrder.verify(format).println(mockAppendable); // break for \r\n pair
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('l'));
        inOrder.verify(mockAppendable).append(eq('i'));
        inOrder.verify(mockAppendable).append(eq('n'));
        inOrder.verify(mockAppendable).append(eq('e'));
        inOrder.verify(mockAppendable).append(eq('2'));
        inOrder.verify(format).println(mockAppendable); // final println

        verify(format, org.mockito.Mockito.times(2)).println(mockAppendable);
    }

    /**
     * Test case: testPrintComment_CommentWithMixedLineBreaks.
     * Comment contains a mix of LF, CR, and CRLF. Each line break should trigger a new comment line.
     */
    @Test
    void testPrintComment_CommentWithMixedLineBreaks() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment("A\nB\rC\r\nD");

        // Assertions
        InOrder inOrder = inOrder(format, mockAppendable);

        // segment A
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('A'));
        inOrder.verify(format).println(mockAppendable);

        // segment B
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('B'));
        inOrder.verify(format).println(mockAppendable);

        // segment C
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('C'));
        inOrder.verify(format).println(mockAppendable);

        // segment D
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('D'));
        inOrder.verify(format).println(mockAppendable); // final println

        verify(format, org.mockito.Mockito.times(4)).println(mockAppendable);
    }

    /**
     * Test case: testPrintComment_CommentEndsWithLineBreak.
     * Comment ends with a line break (e.g., LF). Should print an empty comment line after the break,
     * then final println.
     */
    @Test
    void testPrintComment_CommentEndsWithLineBreak() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment("text\n");

        // Assertions
        InOrder inOrder = inOrder(format, mockAppendable);

        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(mockAppendable).append(eq('t'));
        inOrder.verify(mockAppendable).append(eq('e'));
        inOrder.verify(mockAppendable).append(eq('x'));
        inOrder.verify(mockAppendable).append(eq('t'));
        inOrder.verify(format).println(mockAppendable); // break after text

        // empty comment line after break
        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(format).println(mockAppendable); // final println

        verify(format, org.mockito.Mockito.times(2)).println(mockAppendable);
    }

    /**
     * Test case: testPrintComment_EmptyCommentString.
     * Comment is an empty string (non-null, length 0). Should output only the marker, space, and a single println.
     */
    @Test
    void testPrintComment_EmptyCommentString() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute
        printer.printComment("");

        // Assertions
        InOrder inOrder = inOrder(format, mockAppendable);

        inOrder.verify(mockAppendable).append(eq('#'));
        inOrder.verify(mockAppendable).append(eq(' '));
        inOrder.verify(format).println(mockAppendable);

        verify(format, org.mockito.Mockito.times(1)).println(mockAppendable);
    }

    /**
     * Test case: testPrintComment_IOExceptionFromAppend_Propagates.
     * When appending a character throws an IOException, the exception should propagate out of printComment.
     */
    @Test
    void testPrintComment_IOExceptionFromAppend_Propagates() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doNothing().when(format).println(mockAppendable);
        when(mockAppendable.append(anyChar())).thenThrow(new IOException());

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute & Assert
        assertThrows(IOException.class, () -> printer.printComment("x"));
    }

    /**
     * Test case: testPrintComment_IOExceptionFromPrintln_Propagates.
     * If println() throws an IOException, the exception should propagate.
     */
    @Test
    void testPrintComment_IOExceptionFromPrintln_Propagates() throws IOException {
        // Setup
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));
        doThrow(new IOException()).when(format).println(mockAppendable); // final println throws

        CSVPrinter printer = new CSVPrinter(mockAppendable, format);

        // Execute & Assert
        assertThrows(IOException.class, () -> printer.printComment("ok"));
    }
}