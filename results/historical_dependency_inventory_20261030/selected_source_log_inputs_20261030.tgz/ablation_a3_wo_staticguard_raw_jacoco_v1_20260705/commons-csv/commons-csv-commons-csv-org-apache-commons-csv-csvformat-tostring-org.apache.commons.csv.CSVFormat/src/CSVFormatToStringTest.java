package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CSVFormatToStringTest {

    @Test
    public void testDefaultFormatToString() {
        CSVFormat format = CSVFormat.DEFAULT;
        String expected = "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r\n> EmptyLines:ignored SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }

    @Test
    public void testFullFeatureFormatToString() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setDelimiter('\t')
                .setEscape('\\')
                .setQuote('"')
                .setQuoteMode(QuoteMode.ALL_NON_NULL)
                .setCommentMarker('#')
                .setNullString("NULL")
                .setRecordSeparator("\n")
                .setIgnoreEmptyLines(true)
                .setIgnoreSurroundingSpaces(true)
                .setIgnoreHeaderCase(true)
                .setSkipHeaderRecord(true)
                .setHeader("col1", "col2")
                .setHeaderComments("comment1", "comment2")
                .build();
        String expected = "Delimiter=<\t> Escape=<\\> QuoteChar=<\"> QuoteMode=<ALL_NON_NULL> CommentStart=<#> NullString=<NULL> RecordSeparator=<\n> EmptyLines:ignored SurroundingSpaces:ignored IgnoreHeaderCase:ignored SkipHeaderRecord:true HeaderComments:[comment1, comment2] Header:[col1, col2]";
        assertEquals(expected, format.toString());
    }

    @Test
    public void testMinimalFormatToString() {
        CSVFormat format = CSVFormat.DEFAULT.builder().build();
        // DEFAULT already has many settings; we need one with only delimiter and no other optional features set.
        // Using newFormat with minimal settings: only delimiter set, everything else null/false.
        CSVFormat minimal = CSVFormat.newFormat(',');
        // newFormat sets delimiter, quoteChar=null, quoteMode=null, commentStart=null, escape=null,
        // ignoreSurroundingSpaces=false, ignoreEmptyLines=false, recordSeparator=null,
        // nullString=null, headerComments=null, headers=null, skipHeaderRecord=false, etc.
        String expected = "Delimiter=<,> SkipHeaderRecord:false";
        assertEquals(expected, minimal.toString());
    }

    @Test
    public void testNullQuoteCharacterAbsent() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setQuote(null)       // quote disabled
                .setEscape('\\')
                .setQuoteMode(QuoteMode.MINIMAL)
                .setRecordSeparator("\n")
                .setIgnoreEmptyLines(false) // ensure ignoreEmptyLines is false to avoid its output
                .build();
        String expected = "Delimiter=<,> Escape=<\\> QuoteMode=<MINIMAL> RecordSeparator=<\n> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }

    @Test
    public void testNullStringSetToEmpty() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setNullString("")
                .build();
        String expected = "Delimiter=<,> NullString=<> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }

    @Test
    public void testEmptyHeadersArray() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader(new String[0])
                .build();
        String expected = "Delimiter=<,> SkipHeaderRecord:false Header:[]";
        assertEquals(expected, format.toString());
    }

    @Test
    public void testEmptyHeaderCommentsArray() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeaderComments(new String[0])
                .build();
        String expected = "Delimiter=<,> SkipHeaderRecord:false HeaderComments:[]";
        assertEquals(expected, format.toString());
    }

    @Test
    public void testRecordSeparatorSpecialCharacter() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setRecordSeparator("\n")
                .build();
        String expected = "Delimiter=<,> RecordSeparator=<\n> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }

    @Test
    public void testMultiCharDelimiter() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setDelimiter("||")
                .build();
        String expected = "Delimiter=<||> SkipHeaderRecord:false";
        assertEquals(expected, format.toString());
    }
}