package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;

/**
 * Test class for {@link CSVFormat#format(Object...)}.
 */
public class CSVFormatTest {

    private CSVFormat formatWithSep;
    private CSVFormat formatNullSep;
    private CSVFormat formatNullStr;
    private CSVFormat formatDefault;
    private CSVFormat formatExcel;
    private CSVFormat formatRFC4180;
    private CSVFormat formatMultiCharSep;

    @BeforeEach
    public void setUp() {
        formatWithSep = CSVFormat.DEFAULT.withRecordSeparator("\n");
        formatNullSep = CSVFormat.DEFAULT.withRecordSeparator(null);
        formatNullStr = CSVFormat.DEFAULT.withNullString("NULL").withRecordSeparator("\n");
        formatDefault = CSVFormat.DEFAULT;
        formatExcel = CSVFormat.EXCEL;
        formatRFC4180 = CSVFormat.RFC4180;
        formatMultiCharSep = CSVFormat.RFC4180.withRecordSeparator("\r\n");
    }

    @Test
    public void testFormat_basicRecordWithSeparator() {
        final String result = formatWithSep.format("a", "b");
        assertEquals("a,b", result);
    }

    @Test
    public void testFormat_nullRecordSeparator() {
        final String result = formatNullSep.format("x");
        assertEquals("x", result);
    }

    @Test
    public void testFormat_emptyArray() {
        final String result = formatDefault.format();
        assertEquals("", result);
    }

    @Test
    public void testFormat_nullValueWithDefaultNullString() {
        final String result = formatWithSep.format((Object) null);
        assertEquals("", result);
    }

    @Test
    public void testFormat_nullValueWithCustomNullString() {
        final String result = formatNullStr.format(null, "b");
        assertEquals("NULL,b", result);
    }

    @Test
    public void testFormat_valueWithEmbeddedDelimiter() {
        final String result = formatWithSep.format("a,b");
        assertEquals("\"a,b\"", result);
    }

    @Test
    public void testFormat_valueWithEmbeddedQuotes() {
        final String result = formatWithSep.format("he said \"hi\"");
        assertEquals("\"he said \"\"hi\"\"\"", result);
    }

    @Test
    public void testFormat_multiCharacterRecordSeparator() {
        final String result = formatMultiCharSep.format("a", "b");
        assertEquals("a,b", result);
    }

    @Test
    public void testFormat_csvPrinterThrowsIOException() {
        /* This test uses Mockito's mockConstruction to simulate an IOException
         * being thrown by the CSVPrinter constructor. It requires mockito-inline
         * to be available in the test classpath. If not present, the test can be
         * ignored or adapted to use PowerMock. */
        try (MockedConstruction<CSVPrinter> mocked = Mockito.mockConstruction(
                CSVPrinter.class,
                (mock, context) -> { throw new IOException("simulated"); })) {
            assertThrows(IllegalStateException.class, () -> formatDefault.format("any"));
        }
    }
}