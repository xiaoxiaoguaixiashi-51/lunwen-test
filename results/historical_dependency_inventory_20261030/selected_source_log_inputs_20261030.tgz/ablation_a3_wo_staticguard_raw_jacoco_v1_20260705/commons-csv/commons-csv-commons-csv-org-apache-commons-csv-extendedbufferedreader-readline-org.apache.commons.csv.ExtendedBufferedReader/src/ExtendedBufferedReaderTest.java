package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.END_OF_STREAM;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link ExtendedBufferedReader#readLine()}.
 */
class ExtendedBufferedReaderTest {

    @Test
    @DisplayName("testReadLine_LF: Normal line ending with LF")
    void testReadLine_LF() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello\n"));
        String line = reader.readLine();

        assertEquals("hello", line, "line content");
        assertEquals(6, reader.getPosition(), "position after read");
        assertEquals(LF, reader.getLastChar(), "lastChar should be LF");
        assertEquals(1, reader.getCurrentLineNumber(), "line number should be 1");
    }

    @Test
    @DisplayName("testReadLine_CR: Line ending with CR only")
    void testReadLine_CR() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("world\r"));
        String line = reader.readLine();

        assertEquals("world", line, "line content");
        assertEquals(6, reader.getPosition(), "position after read");
        assertEquals(CR, reader.getLastChar(), "lastChar should be CR");
        assertEquals(1, reader.getCurrentLineNumber(), "line number should be 1");
    }

    @Test
    @DisplayName("testReadLine_CRLF: Line ending with CRLF sequence")
    void testReadLine_CRLF() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line\r\n"));
        String line = reader.readLine();

        assertEquals("line", line, "line content");
        assertEquals(6, reader.getPosition(), "position after read (CR+LF consumed)");
        assertEquals(LF, reader.getLastChar(), "lastChar should be LF (last read of CRLF)");
        assertEquals(1, reader.getCurrentLineNumber(), "line number should incremented once for CRLF");
    }

    @Test
    @DisplayName("testReadLine_CRNotFollowedByLF: CR not followed by LF, line ends at CR")
    void testReadLine_CRNotFollowedByLF() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("text\rnext"));
        String firstLine = reader.readLine();

        assertEquals("text", firstLine, "first line content");
        assertEquals(5, reader.getPosition(), "position after first read");
        assertEquals(CR, reader.getLastChar(), "lastChar after first line");
        assertEquals(1, reader.getCurrentLineNumber(), "line number after first line");

        String secondLine = reader.readLine();
        assertEquals("next", secondLine, "subsequent readLine returns remaining content");
    }

    @Test
    @DisplayName("testReadLine_EmptyLine_LF: Empty line with LF only")
    void testReadLine_EmptyLine_LF() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\n"));
        String line = reader.readLine();

        assertEquals("", line, "line content is empty string");
        assertEquals(1, reader.getPosition(), "position after reading LF");
        assertEquals(LF, reader.getLastChar(), "lastChar is LF");
        assertEquals(1, reader.getCurrentLineNumber(), "line number incremented");
    }

    @Test
    @DisplayName("testReadLine_EOF_NoTerminator: Last line without line terminator, file ends")
    void testReadLine_EOF_NoTerminator() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("end"));
        String line = reader.readLine();

        assertEquals("end", line, "line content returns the last characters");
        assertEquals(3, reader.getPosition(), "position after reading 'end'");
        assertEquals(END_OF_STREAM, reader.getLastChar(), "lastChar set to END_OF_STREAM");
        assertEquals(1, reader.getCurrentLineNumber(), "line number increases at EOF");
    }

    @Test
    @DisplayName("testReadLine_EmptyFile: Immediate EOF, empty file")
    void testReadLine_EmptyFile() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        String line = reader.readLine();

        assertNull(line, "readLine returns null for empty file");
        assertEquals(0, reader.getPosition(), "position remains 0");
        assertEquals(UNDEFINED, reader.getLastChar(), "lastChar remains UNDEFINED");
        assertEquals(0, reader.getCurrentLineNumber(), "line number reports 0");
    }

    @Test
    @DisplayName("testReadLine_IOException: Underlying Reader throws IOException")
    void testReadLine_IOException() throws IOException {
        Reader mockReader = mock(Reader.class);
        when(mockReader.read()).thenThrow(new IOException("mock IO error"));
        when(mockReader.read(any(char[].class), anyInt(), anyInt())).thenThrow(new IOException("mock IO error"));

        ExtendedBufferedReader reader = new ExtendedBufferedReader(mockReader);
        assertThrows(IOException.class, reader::readLine, "IOException propagates");
    }
}