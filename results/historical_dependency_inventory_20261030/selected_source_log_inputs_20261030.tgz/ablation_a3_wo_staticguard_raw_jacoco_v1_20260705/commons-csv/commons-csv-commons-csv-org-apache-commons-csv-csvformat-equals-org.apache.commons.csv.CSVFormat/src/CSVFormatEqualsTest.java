package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link CSVFormat#equals(Object)} method.
 */
public class CSVFormatEqualsTest {

    @Test
    public void test_identity_same_object_returns_true() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    public void test_null_object_returns_false() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
    }

    @Test
    public void test_different_class_returns_false() {
        assertFalse(CSVFormat.DEFAULT.equals(new Object()));
    }

    @Test
    public void test_all_fields_identical_returns_true() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setDelimiter(';')
                .setHeader("a", "b")
                .build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setDelimiter(';')
                .setHeader("a", "b")
                .build();

        assertTrue(format1.equals(format2));
        assertTrue(format2.equals(format1));
    }

    @Test
    public void test_boolean_field_mismatch_returns_false() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setAllowMissingColumnNames(true)
                .build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setAllowMissingColumnNames(false)
                .build();

        assertFalse(format1.equals(format2));
    }

    @Test
    public void test_string_field_mismatch_returns_false() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setDelimiter(',')
                .build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setDelimiter(';')
                .build();

        assertFalse(format1.equals(format2));
    }

    @Test
    public void test_array_field_mismatch_returns_false() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setHeader("A", "B")
                .build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setHeader("A", "C")
                .build();

        assertFalse(format1.equals(format2));
    }

    @Test
    public void test_character_field_null_vs_non_null_returns_false() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setCommentMarker(null)
                .build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .build();

        assertFalse(format1.equals(format2));
    }

    @Test
    public void test_enum_field_mismatch_returns_false() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
                .build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY)
                .build();

        assertFalse(format1.equals(format2));
    }

    @Test
    public void test_array_headers_null_vs_non_null_returns_false() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setHeader((String[]) null)
                .build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setHeader("a")
                .build();

        assertFalse(format1.equals(format2));
    }

    @Test
    public void test_derived_field_quotedNullString_consistency() {
        CSVFormat format1 = CSVFormat.DEFAULT.builder()
                .setNullString("NA")
                .build();
        CSVFormat format2 = CSVFormat.DEFAULT.builder()
                .setNullString("NULL")
                .build();

        assertFalse(format1.equals(format2));
    }
}