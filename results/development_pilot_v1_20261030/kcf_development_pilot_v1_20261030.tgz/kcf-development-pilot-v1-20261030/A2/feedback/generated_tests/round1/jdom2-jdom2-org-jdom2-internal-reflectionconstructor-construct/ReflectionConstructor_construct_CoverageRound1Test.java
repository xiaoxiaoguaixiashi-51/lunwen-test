package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class ReflectionConstructor_construct_CoverageRound1Test {

    public static class PublicNoArg {
        public PublicNoArg() {
        }
    }

    public static class PublicNoArgSub extends PublicNoArg {
        public PublicNoArgSub() {
        }
    }

    public static class NoDefaultConstructor {
        public NoDefaultConstructor(String s) {
        }
    }

    public static class PrivateConstructor {
        private PrivateConstructor() {
        }
    }

    public static class ThrowingConstructor {
        public ThrowingConstructor() {
            throw new RuntimeException("boom");
        }
    }

    public static abstract class AbstractClass {
        public AbstractClass() {
        }
    }

    public interface SomeInterface {
    }

    @Test
    public void testConstructSuccess() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructSuccessSubclass() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArgSub.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArgSub);
    }

    @Test
    public void testConstructExactType() {
        PublicNoArgSub result = ReflectionConstructor.construct(
                PublicNoArgSub.class.getName(), PublicNoArgSub.class);
        assertNotNull(result);
        assertEquals(PublicNoArgSub.class, result.getClass());
    }

    @Test
    public void testConstructClassNotFound() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.DoesNotExistClassXYZ", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void testConstructNotAssignable() {
        try {
            ReflectionConstructor.construct(
                    PublicNoArg.class.getName(), SomeInterface.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    @Test
    public void testConstructNoDefaultConstructor() {
        try {
            ReflectionConstructor.construct(
                    NoDefaultConstructor.class.getName(), NoDefaultConstructor.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructPrivateConstructor() {
        try {
            ReflectionConstructor.construct(
                    PrivateConstructor.class.getName(), PrivateConstructor.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructAbstractClass() {
        try {
            ReflectionConstructor.construct(
                    AbstractClass.class.getName(), AbstractClass.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    @Test
    public void testConstructThrowingConstructor() {
        try {
            ReflectionConstructor.construct(
                    ThrowingConstructor.class.getName(), ThrowingConstructor.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof java.lang.reflect.InvocationTargetException);
        }
    }

    @Test
    public void testConstructInterface() {
        try {
            ReflectionConstructor.construct(
                    SomeInterface.class.getName(), SomeInterface.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructSameInstanceType() {
        Object o = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), Object.class);
        assertNotNull(o);
        assertSame(PublicNoArg.class, o.getClass());
    }
}
