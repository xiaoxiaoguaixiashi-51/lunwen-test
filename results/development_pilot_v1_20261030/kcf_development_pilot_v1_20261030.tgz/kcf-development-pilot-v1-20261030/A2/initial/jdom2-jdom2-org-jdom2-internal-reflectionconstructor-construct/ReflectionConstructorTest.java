package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

public class ReflectionConstructorTest {

    public static class PublicNoArgClass {
        public boolean initialized = false;

        public PublicNoArgClass() {
            this.initialized = true;
        }
    }

    public static class PublicNoArgSubClass extends PublicNoArgClass {
        public PublicNoArgSubClass() {
            super();
        }
    }

    public static class OnlyArgsClass {
        public OnlyArgsClass(String arg) {
        }
    }

    public static class PrivateCtorClass {
        private PrivateCtorClass() {
        }
    }

    public static class ThrowingCtorClass {
        public ThrowingCtorClass() {
            throw new RuntimeException("boom");
        }
    }

    public abstract static class AbstractNoArgClass {
        public AbstractNoArgClass() {
        }
    }

    @Test
    public void test_construct_success_jdk_class() {
        StringBuilder result = ReflectionConstructor.construct("java.lang.StringBuilder", StringBuilder.class);
        assertNotNull(result);
        assertTrue(result instanceof StringBuilder);
        assertEquals("", result.toString());
    }

    @Test
    public void test_construct_success_custom_class() {
        PublicNoArgClass result = ReflectionConstructor.construct(
                "org.jdom2.internal.ReflectionConstructorTest$PublicNoArgClass",
                PublicNoArgClass.class);
        assertNotNull(result);
        assertSame(PublicNoArgClass.class, result.getClass());
        assertTrue(result.initialized);
    }

    @Test
    public void test_construct_success_subclass_assignable() {
        PublicNoArgClass result = ReflectionConstructor.construct(
                "org.jdom2.internal.ReflectionConstructorTest$PublicNoArgSubClass",
                PublicNoArgClass.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArgSubClass);
        assertTrue(result instanceof PublicNoArgClass);
    }

    @Test
    public void test_construct_class_not_found() {
        try {
            ReflectionConstructor.construct("com.example.NotExistClass", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("Unable to locate class 'com.example.NotExistClass'"));
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void test_construct_type_incompatible() {
        try {
            ReflectionConstructor.construct("java.lang.Integer", String.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            assertTrue(e.getMessage().contains("Class 'java.lang.Integer' is not assignable to 'java.lang.String'"));
        }
    }

    @Test
    public void test_construct_no_noarg_constructor() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.ReflectionConstructorTest$OnlyArgsClass",
                    OnlyArgsClass.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("Unable to locate class no-arg constructor"));
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void test_construct_private_constructor_only() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.ReflectionConstructorTest$PrivateCtorClass",
                    PrivateCtorClass.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void test_construct_constructor_throws_exception() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.ReflectionConstructorTest$ThrowingCtorClass",
                    ThrowingCtorClass.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("Unable to call class constructor"));
            assertTrue(e.getCause() instanceof InvocationTargetException);
            Throwable inner = e.getCause().getCause();
            assertTrue(inner instanceof RuntimeException);
            assertEquals("boom", inner.getMessage());
        }
    }

    @Test
    public void test_construct_abstract_class() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.ReflectionConstructorTest$AbstractNoArgClass",
                    AbstractNoArgClass.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("Unable to instantiate class"));
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    @Test
    public void test_construct_interface() {
        try {
            ReflectionConstructor.construct("java.lang.Runnable", Runnable.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    @Test
    public void test_construct_null_classname() {
        try {
            ReflectionConstructor.construct(null, Object.class);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void test_construct_null_targetclass() {
        try {
            ReflectionConstructor.construct("java.lang.StringBuilder", null);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            assertNotNull(e);
        }
    }

    @Test
    public void test_construct_security_exception_optional() {
        // SecurityException branch cannot be reliably triggered without a SecurityManager
        // (deprecated in JDK 17+) or static mocking (not allowed here). This test verifies
        // the normal path remains functional and documents the optional scenario.
        StringBuilder result = ReflectionConstructor.construct("java.lang.StringBuilder", StringBuilder.class);
        assertNotNull(result);
        assertTrue(result instanceof StringBuilder);
    }
}