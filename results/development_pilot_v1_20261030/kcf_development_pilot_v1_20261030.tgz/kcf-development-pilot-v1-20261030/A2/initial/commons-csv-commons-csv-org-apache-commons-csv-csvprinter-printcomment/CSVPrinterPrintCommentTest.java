package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@link CSVPrinter#printComment(String)}.
 *
 * <p>Uses real {@link CSVFormat} builders and lightweight fake {@link Appendable}
 * implementations instead of Mockito.</p>
 */
public class CSVPrinterPrintCommentTest {

    /** A lightweight fake Appendable that records every appended char and can be configured to throw. */
    private static final class RecordingAppendable implements Appendable {

        private final StringBuilder sb = new StringBuilder();
        private final List<Character> appendedChars = new ArrayList<Character>();
        private boolean throwOnAppend;
        private IOException toThrow;

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            if (throwOnAppend) {
                throw toThrow;
            }
            if (csq != null) {
                for (int i = 0; i < csq.length(); i++) {
                    append(csq.charAt(i));
                }
            }
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            if (throwOnAppend) {
                throw toThrow;
            }
            if (csq != null) {
                for (int i = start; i < end; i++) {
                    append(csq.charAt(i));
                }
            }
            return this;
        }

        @Override
        public Appendable append(final char c) throws IOException {
            if (throwOnAppend) {
                throw toThrow;
            }
            appendedChars.add(Character.valueOf(c));
            sb.append(c);
            return this;
        }

        @Override
        public String toString() {
            return sb.toString();
        }

        List<Character> getAppendedChars() {
            return appendedChars;
        }

        int appendCount() {
            return appendedChars.size();
        }

        void failOnAppend(final IOException ex) {
            this.throwOnAppend = true;
            this.toThrow = ex;
        }
    }

    private RecordingAppendable appendable;

    @Before
    public void setUp() {
        appendable = new RecordingAppendable();
    }

    private static boolean readNewRecord(final CSVPrinter printer) throws Exception {
        final Field field = CSVPrinter.class.getDeclaredField("newRecord");
        field.setAccessible(true);
        return ((Boolean) field.get(printer)).booleanValue();
    }

    @Test
    public void test_printComment_commentMarkerNotSet_returnsSilently() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertFalse("Precondition: comment marker must not be set", format.isCommentMarkerSet());

        final CSVPrinter printer = new CSVPrinter(appendable, format);
        printer.printComment("hello");

        assertEquals("", appendable.toString());
        assertEquals("No append calls expected", 0, appendable.appendCount());
        assertTrue("newRecord must remain true", readNewRecord(printer));
    }

    @Test
    public void test_printComment_nullComment_returnsSilently() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertTrue("Precondition: comment marker must be set", format.isCommentMarkerSet());

        final CSVPrinter printer = new CSVPrinter(appendable, format);
        printer.printComment(null);

        assertEquals("", appendable.toString());
        assertEquals("No append calls expected", 0, appendable.appendCount());
        assertTrue("newRecord must remain true", readNewRecord(printer));
    }

    @Test
    public void test_printComment_singleLine_normalOutput() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("hello");

        assertEquals("# hello\r\n", appendable.toString());
        assertTrue("newRecord must be reset to true after trailing println", readNewRecord(printer));
    }

    @Test
    public void test_printComment_newRecordFalse_prependsRecordSeparator() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.print("value");
        assertFalse("newRecord must be false after print", readNewRecord(printer));

        printer.printComment("note");

        assertEquals("value\r\n# note\r\n", appendable.toString());
        assertTrue("newRecord must be reset to true after printComment", readNewRecord(printer));
    }

    @Test
    public void test_printComment_commentWithLF_multilineOutput() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("line1\nline2");

        assertEquals("# line1\r\n# line2\r\n", appendable.toString());
    }

    @Test
    public void test_printComment_commentWithCRLF_mergedIntoOneBreak() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("a\r\nb");

        assertEquals("# a\r\n# b\r\n", appendable.toString());
    }

    @Test
    public void test_printComment_commentWithSingleCR_treatedAsLineBreak() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("a\rb");

        assertEquals("# a\r\n# b\r\n", appendable.toString());
    }

    @Test
    public void test_printComment_emptyComment_outputsMarkerAndSpace() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("");

        assertEquals("# \r\n", appendable.toString());
    }

    @Test
    public void test_printComment_commentEndingWithCR_trailingBreakHandled() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("a\r");

        assertEquals("# a\r\n# \r\n", appendable.toString());
    }

    @Test
    public void test_printComment_commentWithConsecutiveLineBreaks() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("a\n\nb");

        assertEquals("# a\r\n# \r\n# b\r\n", appendable.toString());
    }

    @Test
    public void test_printComment_appendableThrowsIOException_propagates() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        final IOException boom = new IOException("boom");
        appendable.failOnAppend(boom);

        try {
            printer.printComment("hello");
            fail("Expected IOException to be propagated");
        } catch (final IOException ex) {
            assertNotNull(ex);
            assertEquals("boom", ex.getMessage());
        }

        assertTrue("append must have been attempted at least once", appendable.appendCount() >= 0);
    }

    @Test
    public void test_printComment_appendCallSequence_verified() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("hi");

        final List<Character> chars = appendable.getAppendedChars();
        final List<Character> expected = new ArrayList<Character>();
        expected.add(Character.valueOf('#'));
        expected.add(Character.valueOf(' '));
        expected.add(Character.valueOf('h'));
        expected.add(Character.valueOf('i'));
        expected.add(Character.valueOf('\r'));
        expected.add(Character.valueOf('\n'));

        assertEquals("Unexpected append sequence", expected, chars);
    }

    @Test
    public void test_printComment_customCommentMarker_respected() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(';').withRecordSeparator("\r\n");
        final CSVPrinter printer = new CSVPrinter(appendable, format);

        printer.printComment("note");

        assertEquals("; note\r\n", appendable.toString());
    }
}