| fqcn | id | output | output_dir | project_id | source_dir | status | test_class | xml_file |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| org.apache.commons.csv.CSVPrinter | commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment | JUnit version 4.13.2
.............
Time: 0.017

OK (13 tests)

 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A2/initial_execution/commons-csv/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment-org.apache.commons.csv.CSVPrinter | commons-csv | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A2/initial/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment | ok | org.apache.commons.csv.CSVPrinterPrintCommentTest | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A2/initial_execution/commons-csv/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment-org.apache.commons.csv.CSVPrinter/xml/jacoco.xml |
| org.jdom2.internal.ReflectionConstructor | jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct | JUnit version 4.13.2
........E.....
Time: 0.009
There was 1 failure:
1) test_construct_interface(org.jdom2.internal.ReflectionConstructorTest)
java.lang.IllegalArgumentException: Unable to locate class no-arg constructor 'java.lang.Runnable'.
	at org.jdom2.internal.ReflectionConstructor.construct(ReflectionConstructor.java:91)
	at org.jdom2.internal.ReflectionConstructorTest.test_construct_interface(ReflectionConstructorTest.java:156)
	... 32 trimmed
Caused by: java.lang.NoSuchMethodException: java.lang.Runnable.<init>()
	at java.lang.Class.getConstructor0(Class.java:3082)
	at java.lang.Class.getConstructor(Class.java:1825)
	at org.jdom2.internal.ReflectionConstructor.construct(ReflectionConstructor.java:85)
	... 34 more

FAILURES!!!
Tests run: 13,  Failures: 1

 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A2/initial_execution/jdom2/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct-org.jdom2.internal.ReflectionConstructor | jdom2 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A2/initial/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct | test_failed | org.jdom2.internal.ReflectionConstructorTest | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A2/initial_execution/jdom2/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct-org.jdom2.internal.ReflectionConstructor/xml/jacoco.xml |
