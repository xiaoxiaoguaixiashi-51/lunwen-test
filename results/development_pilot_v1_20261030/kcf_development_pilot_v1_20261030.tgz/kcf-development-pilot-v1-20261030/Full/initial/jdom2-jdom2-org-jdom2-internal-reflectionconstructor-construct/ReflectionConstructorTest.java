package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

public class ReflectionConstructorTest {

    public static class PublicNoArgClass {
        public PublicNoArgClass() {
        }
    }

    public static class NoNoArgClass {
        public NoNoArgClass(String s) {
        }
    }

    public static class PrivateCtorClass {
        private PrivateCtorClass() {
        }
    }

    public static abstract class AbstractClass {
        public AbstractClass() {
        }
    }

    public static class ThrowingCtorClass {
        public ThrowingCtorClass() {
            throw new RuntimeException("boom");
        }
    }

    public interface MarkerInterface {
    }

    public static class ImplClass implements MarkerInterface {
        public ImplClass() {
        }
    }

    private static final String PUBLIC_NO_ARG_CLASS_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$PublicNoArgClass";
    private static final String NO_NO_ARG_CLASS_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$NoNoArgClass";
    private static final String PRIVATE_CTOR_CLASS_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$PrivateCtorClass";
    private static final String ABSTRACT_CLASS_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$AbstractClass";
    private static final String THROWING_CTOR_CLASS_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$ThrowingCtorClass";
    private static final String IMPL_CLASS_NAME =
            "org.jdom2.internal.ReflectionConstructorTest$ImplClass";
    private static final String NOT_EXIST_CLASS_NAME = "org.jdom2.internal.NotExistClass";

    @Test
    public void test_construct_success_public_no_arg() {
        PublicNoArgClass first = ReflectionConstructor.construct(
                PUBLIC_NO_ARG_CLASS_NAME, PublicNoArgClass.class);
        assertNotNull("First constructed instance should not be null", first);
        assertTrue("Instance should be a PublicNoArgClass",
                first instanceof PublicNoArgClass);

        PublicNoArgClass second = ReflectionConstructor.construct(
                PUBLIC_NO_ARG_CLASS_NAME, PublicNoArgClass.class);
        assertNotNull("Second constructed instance should not be null", second);
        assertNotSame("Each call should create a new instance", first, second);
    }

    @Test
    public void test_construct_success_interface_target() {
        MarkerInterface instance = ReflectionConstructor.construct(
                IMPL_CLASS_NAME, MarkerInterface.class);
        assertNotNull("Constructed instance should not be null", instance);
        assertTrue("Instance should be a MarkerInterface",
                instance instanceof MarkerInterface);
        assertTrue("Instance should be an ImplClass",
                instance instanceof ImplClass);
    }

    @Test
    public void test_construct_class_not_found() {
        try {
            ReflectionConstructor.construct(NOT_EXIST_CLASS_NAME, Object.class);
            fail("Expected IllegalArgumentException for non-existent class");
        } catch (IllegalArgumentException e) {
            assertTrue("Message should contain the class name",
                    e.getMessage() != null && e.getMessage().contains(NOT_EXIST_CLASS_NAME));
            assertTrue("Cause should be ClassNotFoundException",
                    e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void test_construct_type_incompatible() {
        try {
            ReflectionConstructor.construct(IMPL_CLASS_NAME, String.class);
            fail("Expected ClassCastException for incompatible target type");
        } catch (ClassCastException e) {
            assertTrue("Message should contain the class name",
                    e.getMessage() != null && e.getMessage().contains(IMPL_CLASS_NAME));
            assertTrue("Message should contain the target class name",
                    e.getMessage() != null && e.getMessage().contains(String.class.getName()));
            assertNull("ClassCastException should not be wrapped", e.getCause());
        }
    }

    @Test
    public void test_construct_no_no_arg_constructor() {
        try {
            ReflectionConstructor.construct(NO_NO_ARG_CLASS_NAME, NoNoArgClass.class);
            fail("Expected IllegalArgumentException for missing no-arg constructor");
        } catch (IllegalArgumentException e) {
            assertTrue("Cause should be NoSuchMethodException",
                    e.getCause() instanceof NoSuchMethodException);
            assertTrue("Message should contain the class name",
                    e.getMessage() != null && e.getMessage().contains(NO_NO_ARG_CLASS_NAME));
        }
    }

    @Test
    public void test_construct_private_constructor() {
        try {
            ReflectionConstructor.construct(PRIVATE_CTOR_CLASS_NAME, PrivateCtorClass.class);
            fail("Expected IllegalArgumentException for private constructor");
        } catch (IllegalArgumentException e) {
            assertTrue("Cause should be NoSuchMethodException",
                    e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void test_construct_abstract_class() {
        try {
            ReflectionConstructor.construct(ABSTRACT_CLASS_NAME, AbstractClass.class);
            fail("Expected IllegalStateException for abstract class");
        } catch (IllegalStateException e) {
            assertTrue("Cause should be InstantiationException",
                    e.getCause() instanceof InstantiationException);
            assertTrue("Message should contain the class name",
                    e.getMessage() != null && e.getMessage().contains(ABSTRACT_CLASS_NAME));
        }
    }

    @Test
    public void test_construct_constructor_throws_exception() {
        try {
            ReflectionConstructor.construct(THROWING_CTOR_CLASS_NAME, ThrowingCtorClass.class);
            fail("Expected IllegalStateException when constructor throws");
        } catch (IllegalStateException e) {
            assertTrue("Cause should be InvocationTargetException",
                    e.getCause() instanceof InvocationTargetException);
            InvocationTargetException ite = (InvocationTargetException) e.getCause();
            assertTrue("Target exception should be RuntimeException",
                    ite.getTargetException() instanceof RuntimeException);
            assertEquals("Target exception message should be 'boom'",
                    "boom", ite.getTargetException().getMessage());
        }
    }

    @Test
    public void test_construct_null_classname() {
        try {
            ReflectionConstructor.construct(null, Object.class);
            fail("Expected NullPointerException for null classname");
        } catch (NullPointerException e) {
            // expected
        }
    }

    @Test
    public void test_construct_null_targetclass() {
        try {
            ReflectionConstructor.construct(PUBLIC_NO_ARG_CLASS_NAME, null);
            fail("Expected NullPointerException for null targetclass");
        } catch (NullPointerException e) {
            // expected
        }
    }

    @Test
    public void test_construct_empty_classname() {
        try {
            ReflectionConstructor.construct("", Object.class);
            fail("Expected IllegalArgumentException for empty classname");
        } catch (IllegalArgumentException e) {
            assertTrue("Cause should be ClassNotFoundException",
                    e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void test_construct_jdk_class_success() {
        java.util.List<?> instance = ReflectionConstructor.construct(
                "java.util.ArrayList", java.util.List.class);
        assertNotNull("Constructed instance should not be null", instance);
        assertTrue("Instance should be a java.util.List",
                instance instanceof java.util.List);
        assertTrue("Instance should be a java.util.ArrayList",
                instance instanceof java.util.ArrayList);
    }
}