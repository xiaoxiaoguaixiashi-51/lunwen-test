package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVPrinterPrintCommentTest {

    private static final char CR = '\r';
    private static final char LF = '\n';
    private static final char SP = ' ';
    private static final char COMMENT_MARKER = '#';

    private static CSVFormat formatWithComment() {
        return CSVFormat.DEFAULT.builder().setCommentMarker(COMMENT_MARKER).build();
    }

    private static CSVFormat formatWithoutComment() {
        return CSVFormat.DEFAULT;
    }

    private static int countOccurrences(final String text, final char c) {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == c) {
                count++;
            }
        }
        return count;
    }

    @Test
    public void test_printComment_commentMarkerNotSet_doesNothing() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithoutComment());

        printer.printComment("hello");

        assertEquals("", out.toString());
    }

    @Test
    public void test_printComment_nullComment_doesNothing() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment(null);

        assertEquals("", out.toString());
    }

    @Test
    public void test_printComment_singleLine_newRecordTrue() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment("hello");

        assertEquals("# hello" + CSVFormat.DEFAULT.getRecordSeparator(), out.toString());
        assertTrue("newRecord should remain true after printing a comment", printerIsNewRecord(printer));
    }

    @Test
    public void test_printComment_notNewRecord_printsLeadingNewline() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.print("value");
        printer.printComment("note");

        final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("value" + recordSeparator + "# note" + recordSeparator, out.toString());
        assertEquals("record separator should appear exactly twice", 2, countOccurrences(out.toString(), recordSeparator.charAt(0)));
    }

    @Test
    public void test_printComment_emptyString_printsMarkerOnly() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment("");

        assertEquals("# " + CSVFormat.DEFAULT.getRecordSeparator(), out.toString());
    }

    @Test
    public void test_printComment_containsLF_insertsMarkerOnEachLine() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment("a\nb");

        final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# a" + recordSeparator + "# b" + recordSeparator, out.toString());
        assertEquals("comment marker should appear twice", 2, countOccurrences(out.toString(), COMMENT_MARKER));
    }

    @Test
    public void test_printComment_containsCR_insertsMarkerOnEachLine() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment("a\rb");

        final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# a" + recordSeparator + "# b" + recordSeparator, out.toString());
        assertEquals("comment marker should appear twice", 2, countOccurrences(out.toString(), COMMENT_MARKER));
    }

    @Test
    public void test_printComment_containsCRLF_treatedAsSingleNewline() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment("a\r\nb");

        final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# a" + recordSeparator + "# b" + recordSeparator, out.toString());
        assertEquals("comment marker should appear twice, not three times", 2, countOccurrences(out.toString(), COMMENT_MARKER));
    }

    @Test
    public void test_printComment_mixedLineBreaks() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment("a\rb\nc\r\nd");

        final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# a" + recordSeparator + "# b" + recordSeparator + "# c" + recordSeparator + "# d" + recordSeparator, out.toString());
        assertEquals("comment marker should appear four times", 4, countOccurrences(out.toString(), COMMENT_MARKER));
    }

    @Test
    public void test_printComment_trailingLineBreak() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment("a\n");

        final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# a" + recordSeparator + "# " + recordSeparator, out.toString());
    }

    @Test
    public void test_printComment_commentMarkerSetButEmpty_throwsNoSuchElementException() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        try {
            printer.printComment("x");
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException expected) {
            assertNotNull(expected);
        }
    }

    @Test
    public void test_printComment_appendableThrowsIOException_propagates() throws IOException {
        final Appendable failingAppendable = new Appendable() {
            @Override
            public Appendable append(final CharSequence csq) throws IOException {
                throw new IOException("boom");
            }

            @Override
            public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
                throw new IOException("boom");
            }

            @Override
            public Appendable append(final char c) throws IOException {
                throw new IOException("boom");
            }
        };
        final CSVPrinter printer = new CSVPrinter(failingAppendable, formatWithComment());

        try {
            printer.printComment("x");
            fail("Expected IOException");
        } catch (final IOException expected) {
            assertEquals("boom", expected.getMessage());
        }
    }

    @Test
    public void test_printComment_verifyAppendInteractionSequence() throws IOException {
        final RecordingAppendable recording = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(recording, formatWithComment());

        printer.printComment("hi");

        final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();
        final String expected = "# hi" + recordSeparator;
        assertEquals(expected, recording.toString());
        assertEquals("first appended char should be the comment marker", COMMENT_MARKER, recording.charAtAt(0));
        assertEquals("second appended char should be a space", SP, recording.charAtAt(1));
        assertEquals("third appended char should be 'h'", 'h', recording.charAtAt(2));
        assertEquals("fourth appended char should be 'i'", 'i', recording.charAtAt(3));
    }

    @Test
    public void test_printComment_spyIsolatesPrintln() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(out, formatWithComment());

        printer.printComment("hi");
        final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# hi" + recordSeparator, out.toString());

        final StringBuilder out2 = new StringBuilder();
        final CSVPrinter printer2 = new CSVPrinter(out2, formatWithComment());
        printer2.print("value");
        printer2.printComment("hi");
        assertEquals("value" + recordSeparator + "# hi" + recordSeparator, out2.toString());
    }

    private static boolean printerIsNewRecord(final CSVPrinter printer) {
        try {
            final java.lang.reflect.Field field = CSVPrinter.class.getDeclaredField("newRecord");
            field.setAccessible(true);
            return field.getBoolean(printer);
        } catch (final ReflectiveOperationException e) {
            throw new AssertionError("Unable to read newRecord field", e);
        }
    }

    private static final class RecordingAppendable implements Appendable {

        private final StringBuilder delegate = new StringBuilder();

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            delegate.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            delegate.append(csq, start, end);
            return this;
        }

        @Override
        public Appendable append(final char c) throws IOException {
            delegate.append(c);
            return this;
        }

        char charAtAt(final int index) {
            return delegate.charAt(index);
        }

        @Override
        public String toString() {
            return delegate.toString();
        }
    }
}