package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.Test;

public class CSVPrinter_printComment_CoverageRound1Test {

    private static final String RECORD_SEPARATOR = "\r\n";

    private CSVFormat formatWithCommentMarker() {
        return CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setRecordSeparator(RECORD_SEPARATOR)
                .build();
    }

    @Test
    public void testNullCommentDoesNothing() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment(null);
        assertEquals("", sw.toString());
    }

    @Test
    public void testCommentMarkerNotSetDoesNothing() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setRecordSeparator(RECORD_SEPARATOR)
                .build();
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("ignored");
        assertEquals("", sw.toString());
    }

    @Test
    public void testSimpleComment() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("hello");
        assertEquals("# hello" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testEmptyComment() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("");
        assertEquals("# " + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentAfterRecordStartsNewLine() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.print("value");
        printer.printComment("note");
        assertEquals("value" + RECORD_SEPARATOR + "# note" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentWithLfInside() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\nline2");
        assertEquals("# line1" + RECORD_SEPARATOR + "# line2" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentWithCrInside() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\rline2");
        assertEquals("# line1" + RECORD_SEPARATOR + "# line2" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentWithCrLfInside() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\r\nline2");
        assertEquals("# line1" + RECORD_SEPARATOR + "# line2" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentEndingWithCr() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\r");
        assertEquals("# line1" + RECORD_SEPARATOR + "# " + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentEndingWithLf() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\n");
        assertEquals("# line1" + RECORD_SEPARATOR + "# " + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentWithMultipleLineBreaks() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("a\nb\r\nc\rd");
        assertEquals("# a" + RECORD_SEPARATOR
                + "# b" + RECORD_SEPARATOR
                + "# c" + RECORD_SEPARATOR
                + "# d" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentWithCustomMarker() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('!')
                .setRecordSeparator(RECORD_SEPARATOR)
                .build();
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("note");
        assertEquals("! note" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentWithCustomMarkerAndLineBreak() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('!')
                .setRecordSeparator(RECORD_SEPARATOR)
                .build();
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("a\nb");
        assertEquals("! a" + RECORD_SEPARATOR + "! b" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentWithSpecialCharacters() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("a,b\"c");
        assertEquals("# a,b\"c" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testMultipleComments() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("first");
        printer.printComment("second");
        assertEquals("# first" + RECORD_SEPARATOR + "# second" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCommentThenRecord() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("note");
        printer.printRecord("a", "b");
        assertEquals("# note" + RECORD_SEPARATOR + "a,b" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testGetOutReturnsAppendable() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        assertNotNull(printer.getOut());
        assertEquals(sw, printer.getOut());
    }
}
