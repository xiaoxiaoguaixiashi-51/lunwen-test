package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class ReflectionConstructor_construct_CoverageRound1Test {

    public static class PublicNoArg {
        public PublicNoArg() {
        }
    }

    public static class PublicWithArg {
        public PublicWithArg(String s) {
        }
    }

    public static class ThrowingConstructor {
        public ThrowingConstructor() {
            throw new RuntimeException("boom");
        }
    }

    public static abstract class AbstractClass {
        public AbstractClass() {
        }
    }

    public interface SomeInterface {
    }

    public static class PrivateConstructor {
        private PrivateConstructor() {
        }
    }

    @Test
    public void testConstructPublicNoArg() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructAssignableSubtype() {
        Object result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), Object.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructClassNotFound() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.DoesNotExistClassXYZ", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void testConstructNotAssignable() {
        try {
            ReflectionConstructor.construct(
                    PublicNoArg.class.getName(), String.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    @Test
    public void testConstructNoNoArgConstructor() {
        try {
            ReflectionConstructor.construct(
                    PublicWithArg.class.getName(), PublicWithArg.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructInvocationTargetException() {
        try {
            ReflectionConstructor.construct(
                    ThrowingConstructor.class.getName(), ThrowingConstructor.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof java.lang.reflect.InvocationTargetException);
        }
    }

    @Test
    public void testConstructInstantiationException() {
        try {
            ReflectionConstructor.construct(
                    AbstractClass.class.getName(), AbstractClass.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    @Test
    public void testConstructPrivateConstructor() {
        try {
            ReflectionConstructor.construct(
                    PrivateConstructor.class.getName(), PrivateConstructor.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructInterface() {
        try {
            ReflectionConstructor.construct(
                    SomeInterface.class.getName(), SomeInterface.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructReturnsSameType() {
        PublicNoArg a = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        PublicNoArg b = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(a);
        assertNotNull(b);
        assertTrue(a != b);
        assertEquals(PublicNoArg.class, a.getClass());
    }
}
