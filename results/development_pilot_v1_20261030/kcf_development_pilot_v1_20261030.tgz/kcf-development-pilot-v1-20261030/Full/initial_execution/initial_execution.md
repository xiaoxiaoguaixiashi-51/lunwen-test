| fqcn | id | output | output_dir | project_id | source_dir | status | test_class | xml_file |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| org.apache.commons.csv.CSVPrinter | commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment | JUnit version 4.13.2
.........E.....
Time: 0.012
There was 1 failure:
1) test_printComment_commentMarkerSetButEmpty_throwsNoSuchElementException(org.apache.commons.csv.CSVPrinterPrintCommentTest)
java.lang.AssertionError: Expected NoSuchElementException
	at org.junit.Assert.fail(Assert.java:89)
	at org.apache.commons.csv.CSVPrinterPrintCommentTest.test_printComment_commentMarkerSetButEmpty_throwsNoSuchElementException(CSVPrinterPrintCommentTest.java:158)

FAILURES!!!
Tests run: 14,  Failures: 1

 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/Full/initial_execution/commons-csv/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment-org.apache.commons.csv.CSVPrinter | commons-csv | /root/autodl-tmp/kcf-development-pilot-v1-20261030/Full/initial/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment | test_failed | org.apache.commons.csv.CSVPrinterPrintCommentTest | /root/autodl-tmp/kcf-development-pilot-v1-20261030/Full/initial_execution/commons-csv/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment-org.apache.commons.csv.CSVPrinter/xml/jacoco.xml |
| org.jdom2.internal.ReflectionConstructor | jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct | JUnit version 4.13.2
............
Time: 0.009

OK (12 tests)

 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/Full/initial_execution/jdom2/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct-org.jdom2.internal.ReflectionConstructor | jdom2 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/Full/initial/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct | ok | org.jdom2.internal.ReflectionConstructorTest | /root/autodl-tmp/kcf-development-pilot-v1-20261030/Full/initial_execution/jdom2/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct-org.jdom2.internal.ReflectionConstructor/xml/jacoco.xml |
