package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.Test;

public class CSVPrinter_printComment_CoverageRound1Test {

    private static CSVFormat formatWithCommentMarker() {
        return CSVFormat.DEFAULT.withCommentMarker('#');
    }

    @Test
    public void testNullCommentDoesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment(null);
        assertEquals("", sw.toString());
    }

    @Test
    public void testNoCommentMarkerDoesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("hello");
        assertEquals("", sw.toString());
    }

    @Test
    public void testSimpleComment() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("hello");
        assertEquals("# hello" + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
    }

    @Test
    public void testEmptyComment() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("");
        assertEquals("# " + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
    }

    @Test
    public void testCommentAfterRecordStartsNewLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printRecord("a", "b");
        printer.printComment("note");
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("a,b" + sep + "# note" + sep, sw.toString());
    }

    @Test
    public void testCommentWithLF() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\nline2");
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + sep + "# line2" + sep, sw.toString());
    }

    @Test
    public void testCommentWithCR() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\rline2");
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + sep + "# line2" + sep, sw.toString());
    }

    @Test
    public void testCommentWithCRLF() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\r\nline2");
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + sep + "# line2" + sep, sw.toString());
    }

    @Test
    public void testCommentTrailingCR() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("abc\r");
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# abc" + sep + "# " + sep, sw.toString());
    }

    @Test
    public void testCommentTrailingLF() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("abc\n");
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# abc" + sep + "# " + sep, sw.toString());
    }

    @Test
    public void testCommentWithMultipleLineBreaks() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("a\nb\r\nc\rd");
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# a" + sep + "# b" + sep + "# c" + sep + "# d" + sep, sw.toString());
    }

    @Test
    public void testCommentWithCustomMarker() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('!');
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hi");
        assertEquals("! hi" + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
    }

    @Test
    public void testCommentWithCustomRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withRecordSeparator("|");
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("a\nb");
        assertEquals("# a|# b|", sw.toString());
    }

    @Test
    public void testCommentWithSpecialChars() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("a,b\"c");
        assertEquals("# a,b\"c" + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
    }

    @Test
    public void testMultipleComments() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("first");
        printer.printComment("second");
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# first" + sep + "# second" + sep, sw.toString());
    }

    @Test
    public void testPrinterNotNull() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        assertNotNull(printer);
        assertNotNull(printer.getOut());
    }
}
