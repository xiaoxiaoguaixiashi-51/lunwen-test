package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class ReflectionConstructor_construct_CoverageRound1Test {

    public static class PublicNoArg {
        public PublicNoArg() {
        }
    }

    public static class PublicNoArgWithValue {
        private final String value;

        public PublicNoArgWithValue() {
            this.value = "constructed";
        }

        public String getValue() {
            return value;
        }
    }

    public static class NoDefaultConstructor {
        public NoDefaultConstructor(String arg) {
        }
    }

    public static class ThrowingConstructor {
        public ThrowingConstructor() {
            throw new RuntimeException("boom");
        }
    }

    public static class PrivateConstructor {
        private PrivateConstructor() {
        }
    }

    public abstract static class AbstractClass {
        public AbstractClass() {
        }
    }

    public interface SomeInterface {
    }

    @Test
    public void testConstructPublicNoArg() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(result);
    }

    @Test
    public void testConstructReturnsCastInstance() {
        PublicNoArgWithValue result = ReflectionConstructor.construct(
                PublicNoArgWithValue.class.getName(), PublicNoArgWithValue.class);
        assertNotNull(result);
        assertEquals("constructed", result.getValue());
    }

    @Test
    public void testConstructAssignableSupertype() {
        Object result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), Object.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructClassNotFound() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.DoesNotExistClassXYZ", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void testConstructNotAssignable() {
        try {
            ReflectionConstructor.construct(
                    PublicNoArg.class.getName(), String.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testConstructNoDefaultConstructor() {
        try {
            ReflectionConstructor.construct(
                    NoDefaultConstructor.class.getName(), NoDefaultConstructor.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructInvocationTargetException() {
        try {
            ReflectionConstructor.construct(
                    ThrowingConstructor.class.getName(), ThrowingConstructor.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof java.lang.reflect.InvocationTargetException);
        }
    }

    @Test
    public void testConstructPrivateConstructor() {
        try {
            ReflectionConstructor.construct(
                    PrivateConstructor.class.getName(), PrivateConstructor.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructAbstractClass() {
        try {
            ReflectionConstructor.construct(
                    AbstractClass.class.getName(), AbstractClass.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    @Test
    public void testConstructInterface() {
        try {
            ReflectionConstructor.construct(
                    SomeInterface.class.getName(), SomeInterface.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructSameInstanceType() {
        PublicNoArg a = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        PublicNoArg b = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(a);
        assertNotNull(b);
        assertTrue(a != b);
        assertSame(PublicNoArg.class, a.getClass());
    }
}
