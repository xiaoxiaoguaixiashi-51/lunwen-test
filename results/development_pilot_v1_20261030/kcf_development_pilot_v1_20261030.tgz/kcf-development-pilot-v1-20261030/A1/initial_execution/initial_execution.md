| fqcn | id | output | output_dir | project_id | source_dir | status | test_class | xml_file |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| org.apache.commons.csv.CSVPrinter | commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment |  |  | commons-csv |  | generation_budget_blocked |  |  |
| org.jdom2.internal.ReflectionConstructor | jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct | JUnit version 4.13.2
.............
Time: 0.008

OK (13 tests)

 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A1/initial_execution/jdom2/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct-org.jdom2.internal.ReflectionConstructor | jdom2 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A1/initial/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct | ok | org.jdom2.internal.ReflectionConstructorTest | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A1/initial_execution/jdom2/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct-org.jdom2.internal.ReflectionConstructor/xml/jacoco.xml |
