package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

public class ReflectionConstructorTest {

    public static class BaseType {
        public BaseType() {
        }
    }

    public static class SubType extends BaseType {
        public SubType() {
        }
    }

    public static class PublicNoArgClass {
        public PublicNoArgClass() {
        }
    }

    public static class OnlyArgConstructor {
        public OnlyArgConstructor(String value) {
        }
    }

    public static class PrivateConstructorClass {
        private PrivateConstructorClass() {
        }
    }

    public static class ThrowingConstructorClass {
        public ThrowingConstructorClass() {
            throw new RuntimeException("boom");
        }
    }

    public abstract static class AbstractClass {
        public AbstractClass() {
        }
    }

    public interface InterfaceType {
    }

    @Test
    public void test_construct_success_with_public_no_arg_constructor() {
        StringBuilder first = ReflectionConstructor.construct("java.lang.StringBuilder", StringBuilder.class);
        assertNotNull(first);
        assertTrue(first instanceof StringBuilder);
        assertEquals(StringBuilder.class, first.getClass());

        StringBuilder second = ReflectionConstructor.construct("java.lang.StringBuilder", StringBuilder.class);
        assertNotNull(second);
        assertNotSame(first, second);
    }

    @Test
    public void test_construct_success_with_subtype_assignable_to_supertype() {
        BaseType instance = ReflectionConstructor.construct(
                "org.jdom2.internal.ReflectionConstructorTest$SubType", BaseType.class);
        assertNotNull(instance);
        assertTrue(instance instanceof BaseType);
        assertEquals(SubType.class, instance.getClass());
    }

    @Test
    public void test_construct_class_not_found() {
        String classname = "com.example.NotExistClass";
        try {
            ReflectionConstructor.construct(classname, Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("Unable to locate class"));
            assertTrue(e.getMessage().contains(classname));
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void test_construct_type_not_assignable() {
        String classname = "java.lang.String";
        try {
            ReflectionConstructor.construct(classname, Integer.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            assertTrue(e.getMessage().contains(classname));
            assertTrue(e.getMessage().contains(Integer.class.getName()));
            assertNull(e.getCause());
        }
    }

    @Test
    public void test_construct_no_no_arg_constructor() {
        String classname = "org.jdom2.internal.ReflectionConstructorTest$OnlyArgConstructor";
        try {
            ReflectionConstructor.construct(classname, Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("no-arg constructor"));
            assertTrue(e.getMessage().contains(classname));
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void test_construct_private_constructor_not_accessible() {
        String classname = "org.jdom2.internal.ReflectionConstructorTest$PrivateConstructorClass";
        try {
            ReflectionConstructor.construct(classname, Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("no-arg constructor"));
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void test_construct_abstract_class_instantiation_fails() {
        String classname = "java.lang.Number";
        try {
            ReflectionConstructor.construct(classname, Number.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("Unable to instantiate class"));
            assertTrue(e.getMessage().contains(classname));
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    @Test
    public void test_construct_interface_instantiation_fails() {
        String classname = "org.jdom2.internal.ReflectionConstructorTest$InterfaceType";
        try {
            ReflectionConstructor.construct(classname, Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void test_construct_constructor_throws_exception() {
        String classname = "org.jdom2.internal.ReflectionConstructorTest$ThrowingConstructorClass";
        try {
            ReflectionConstructor.construct(classname, Object.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("Unable to call class constructor"));
            assertTrue(e.getMessage().contains(classname));
            assertTrue(e.getCause() instanceof InvocationTargetException);
            Throwable original = e.getCause().getCause();
            assertTrue(original instanceof RuntimeException);
            assertEquals("boom", original.getMessage());
        }
    }

    @Test
    public void test_construct_null_classname() {
        try {
            ReflectionConstructor.construct(null, Object.class);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected: Class.forName(null) throws NullPointerException, not wrapped
        }
    }

    @Test
    public void test_construct_null_targetclass() {
        try {
            ReflectionConstructor.construct("java.lang.StringBuilder", null);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected: targetclass.isAssignableFrom throws NullPointerException, not wrapped
        }
    }

    @Test
    public void test_construct_empty_classname() {
        try {
            ReflectionConstructor.construct("", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void test_construct_security_exception_branch() {
        // SecurityException branch cannot be reliably triggered on modern JDKs
        // without a SecurityManager or static mocking; skipped by design.
        assertTrue(true);
    }
}