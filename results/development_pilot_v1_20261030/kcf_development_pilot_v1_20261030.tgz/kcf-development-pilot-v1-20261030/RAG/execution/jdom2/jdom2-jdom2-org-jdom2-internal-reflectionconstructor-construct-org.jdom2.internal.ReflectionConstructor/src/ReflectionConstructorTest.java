package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class ReflectionConstructorTest {

    public static class PublicNoArg {
        public PublicNoArg() {
        }
    }

    public static class PublicWithArg {
        public PublicWithArg(String s) {
        }
    }

    public static class PrivateNoArg {
        private PrivateNoArg() {
        }
    }

    public static class ThrowingNoArg {
        public ThrowingNoArg() {
            throw new RuntimeException("boom");
        }
    }

    public static class SubPublicNoArg extends PublicNoArg {
        public SubPublicNoArg() {
        }
    }

    public interface Marker {
    }

    public static class MarkerImpl implements Marker {
        public MarkerImpl() {
        }
    }

    @Test
    public void testConstructPublicNoArg() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructReturnsExactInstance() {
        Object result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), Object.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructAssignableSubclass() {
        PublicNoArg result = ReflectionConstructor.construct(
                SubPublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof SubPublicNoArg);
    }

    @Test
    public void testConstructInterfaceTarget() {
        Marker result = ReflectionConstructor.construct(
                MarkerImpl.class.getName(), Marker.class);
        assertNotNull(result);
        assertTrue(result instanceof MarkerImpl);
    }

    @Test
    public void testConstructWithArrayList() {
        List<?> result = ReflectionConstructor.construct(
                ArrayList.class.getName(), List.class);
        assertNotNull(result);
        assertTrue(result instanceof ArrayList);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testConstructWithString() {
        String result = ReflectionConstructor.construct(
                String.class.getName(), String.class);
        assertNotNull(result);
        assertEquals("", result);
    }

    @Test
    public void testConstructClassNotFound() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.DoesNotExistClass", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void testConstructNotAssignable() {
        try {
            ReflectionConstructor.construct(
                    PublicNoArg.class.getName(), String.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    @Test
    public void testConstructNoNoArgConstructor() {
        try {
            ReflectionConstructor.construct(
                    PublicWithArg.class.getName(), PublicWithArg.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructPrivateConstructor() {
        try {
            ReflectionConstructor.construct(
                    PrivateNoArg.class.getName(), PrivateNoArg.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    public void testConstructThrowingConstructor() {
        try {
            ReflectionConstructor.construct(
                    ThrowingNoArg.class.getName(), ThrowingNoArg.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof java.lang.reflect.InvocationTargetException);
        }
    }

    @Test
    public void testConstructNullClassname() {
        try {
            ReflectionConstructor.construct(null, Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertNotNull(e.getCause());
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void testConstructNullTargetClass() {
        try {
            ReflectionConstructor.construct(PublicNoArg.class.getName(), null);
            fail("Expected exception");
        } catch (NullPointerException e) {
            // expected
        }
    }

    @Test
    public void testConstructMultipleInstancesAreDistinct() {
        PublicNoArg first = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        PublicNoArg second = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(first);
        assertNotNull(second);
        assertTrue(first != second);
    }

    @Test
    public void testConstructSameClassTarget() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertSame(PublicNoArg.class, result.getClass());
    }
}