package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.Test;

public class CSVPrinterPrintCommentTest {

    private static final String RECORD_SEPARATOR = "\r\n";

    private CSVFormat formatWithCommentMarker() {
        return CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setRecordSeparator(RECORD_SEPARATOR)
                .build();
    }

    @Test
    public void testPrintCommentNullDoesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment(null);
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentNoCommentMarkerDoesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setRecordSeparator(RECORD_SEPARATOR)
                .build();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("comment");
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentSimple() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("hello");
        assertEquals("# hello" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentEmptyString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("");
        assertEquals("# " + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentWithLf() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\nline2");
        assertEquals("# line1" + RECORD_SEPARATOR + "# line2" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentWithCr() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\rline2");
        assertEquals("# line1" + RECORD_SEPARATOR + "# line2" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentWithCrLf() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line1\r\nline2");
        assertEquals("# line1" + RECORD_SEPARATOR + "# line2" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentMultipleLineBreaks() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("a\nb\nc");
        assertEquals("# a" + RECORD_SEPARATOR + "# b" + RECORD_SEPARATOR + "# c" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentAfterRecordStartsNewLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.print("value");
        printer.printComment("comment");
        assertEquals("value" + RECORD_SEPARATOR + "# comment" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentAfterPrintlnDoesNotAddExtraLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.print("value");
        printer.println();
        printer.printComment("comment");
        assertEquals("value" + RECORD_SEPARATOR + "# comment" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentTwice() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("first");
        printer.printComment("second");
        assertEquals("# first" + RECORD_SEPARATOR + "# second" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentCustomMarker() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('!')
                .setRecordSeparator(RECORD_SEPARATOR)
                .build();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("note");
        assertEquals("! note" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentCustomRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setRecordSeparator("\n")
                .build();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("a\nb");
        assertEquals("# a\n# b\n", sw.toString());
    }

    @Test
    public void testPrintCommentTrailingLineBreak() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("line\n");
        assertEquals("# line" + RECORD_SEPARATOR + "# " + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentLeadingLineBreak() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("\nline");
        assertEquals("# " + RECORD_SEPARATOR + "# line" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentReturnsPrinterOutput() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, formatWithCommentMarker());
        printer.printComment("x");
        assertNotNull(printer.getOut());
        assertEquals(sw, printer.getOut());
    }
}