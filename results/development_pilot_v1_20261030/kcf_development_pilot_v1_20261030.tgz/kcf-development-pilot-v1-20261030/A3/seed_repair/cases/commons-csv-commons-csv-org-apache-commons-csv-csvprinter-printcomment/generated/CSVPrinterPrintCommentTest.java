package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyChar;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

public class CSVPrinterPrintCommentTest {

    private CSVFormat format;
    private Appendable appendable;
    private CSVPrinter printer;

    @BeforeEach
    void setUp() throws IOException {
        format = mock(CSVFormat.class);
        appendable = mock(Appendable.class);

        // Avoid constructor side effects
        when(format.getHeaderComments()).thenReturn(null);
        when(format.getHeader()).thenReturn(null);
        when(format.copy()).thenReturn(format);

        printer = new CSVPrinter(appendable, format);
    }

    @Test
    void test_printComment_commentMarkerNotSet_returnsWithoutOutput() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(false);

        printer.printComment("hello");

        verify(appendable, never()).append(anyChar());
        verify(format, never()).println(any(Appendable.class));
        verify(format, never()).getCommentMarker();
    }

    @Test
    void test_printComment_nullComment_returnsWithoutOutput() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        printer.printComment(null);

        verify(appendable, never()).append(anyChar());
        verify(format, never()).println(any(Appendable.class));
    }

    @Test
    void test_printComment_singleLine_newRecordTrue_outputsMarkerSpaceAndText() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        printer.printComment("hello");

        final InOrder inOrder = inOrder(appendable);
        inOrder.verify(appendable).append('#');
        inOrder.verify(appendable).append(' ');
        inOrder.verify(appendable).append('h');
        inOrder.verify(appendable).append('e');
        inOrder.verify(appendable).append('l');
        inOrder.verify(appendable).append('l');
        inOrder.verify(appendable).append('o');

        verify(format, times(1)).println(appendable);
        verify(appendable, times(7)).append(anyChar());
    }

    @Test
    void test_printComment_newRecordFalse_printsNewlineBeforeComment() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        // Make newRecord false by printing a value
        printer.print("x");

        printer.printComment("hi");

        verify(format, times(2)).println(appendable);

        final InOrder inOrder = inOrder(format, appendable);
        inOrder.verify(format).println(appendable);
        inOrder.verify(appendable).append('#');
        inOrder.verify(appendable).append(' ');
        inOrder.verify(appendable).append('h');
        inOrder.verify(appendable).append('i');
    }

    @Test
    void test_printComment_commentWithLF_reinsertsMarkerAfterNewline() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        printer.printComment("a\nb");

        final InOrder inOrder = inOrder(appendable, format);
        inOrder.verify(appendable).append('#');
        inOrder.verify(appendable).append(' ');
        inOrder.verify(appendable).append('a');
        inOrder.verify(format).println(appendable);
        inOrder.verify(appendable).append('#');
        inOrder.verify(appendable).append(' ');
        inOrder.verify(appendable).append('b');

        verify(format, times(2)).println(appendable);
        verify(appendable, times(2)).append('#');
    }

    @Test
    void test_printComment_commentWithCRLF_skipsLFAndPrintsSingleNewline() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        printer.printComment("a\r\nb");

        verify(format, times(2)).println(appendable);
        verify(appendable, times(2)).append('#');

        final InOrder inOrder = inOrder(appendable, format);
        inOrder.verify(appendable).append('a');
        inOrder.verify(format).println(appendable);
        inOrder.verify(appendable).append('#');
        inOrder.verify(appendable).append(' ');
        inOrder.verify(appendable).append('b');
    }

    @Test
    void test_printComment_commentWithLoneCR_treatedAsNewline() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        printer.printComment("a\rb");

        verify(format, times(2)).println(appendable);
        verify(appendable, times(2)).append('#');

        final InOrder inOrder = inOrder(appendable, format);
        inOrder.verify(appendable).append('a');
        inOrder.verify(format).println(appendable);
        inOrder.verify(appendable).append('#');
        inOrder.verify(appendable).append(' ');
        inOrder.verify(appendable).append('b');
    }

    @Test
    void test_printComment_commentEndingWithCR_doesNotThrowAndPrintsNewline() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        printer.printComment("a\r");

        verify(format, times(2)).println(appendable);
        verify(appendable, times(2)).append('#');
    }

    @Test
    void test_printComment_emptyComment_outputsMarkerSpaceAndNewline() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        printer.printComment("");

        final InOrder inOrder = inOrder(appendable, format);
        inOrder.verify(appendable).append('#');
        inOrder.verify(appendable).append(' ');
        inOrder.verify(format).println(appendable);

        verify(appendable, times(2)).append(anyChar());
        verify(format, times(1)).println(appendable);
    }

    @Test
    void test_printComment_appendableThrowsIOException_propagates() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(Character.valueOf('#'));

        doThrow(new IOException("write failed")).when(appendable).append(anyChar());

        final IOException ex = assertThrows(IOException.class, () -> printer.printComment("hi"));
        assertEquals("write failed", ex.getMessage());

        verify(format, never()).println(any(Appendable.class));
    }

    @Test
    void test_printComment_commentMarkerNull_throwsNullPointerException() throws IOException {
        when(format.isCommentMarkerSet()).thenReturn(true);
        when(format.getCommentMarker()).thenReturn(null);

        assertThrows(NullPointerException.class, () -> printer.printComment("hi"));

        verify(appendable, never()).append(anyChar());
    }

    @Test
    void test_printComment_withRealStringBuilder_verifiesExactOutput() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat realFormat = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setRecordSeparator('\n')
                .build();
        final CSVPrinter realPrinter = new CSVPrinter(sb, realFormat);

        realPrinter.printComment("a\nb");

        assertEquals("# a\n# b\n", sb.toString());
    }
}
