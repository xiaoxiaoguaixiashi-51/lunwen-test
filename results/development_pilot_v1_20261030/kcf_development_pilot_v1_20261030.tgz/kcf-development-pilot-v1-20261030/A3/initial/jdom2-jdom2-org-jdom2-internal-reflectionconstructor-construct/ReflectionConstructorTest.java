package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

public class ReflectionConstructorTest {

    public interface TestTarget {
    }

    public static class ValidImpl implements TestTarget {
        public ValidImpl() {
        }
    }

    public static class NoDefaultCtor implements TestTarget {
        public NoDefaultCtor(String s) {
        }
    }

    public static class ThrowingCtor implements TestTarget {
        public ThrowingCtor() {
            throw new RuntimeException("boom");
        }
    }

    public static abstract class AbstractImpl implements TestTarget {
        public AbstractImpl() {
        }
    }

    public static class PrivateCtor implements TestTarget {
        private PrivateCtor() {
        }
    }

    public static class NotAssignable {
        public NotAssignable() {
        }
    }

    private static final String VALID_IMPL = "org.jdom2.internal.ReflectionConstructorTest$ValidImpl";
    private static final String NO_DEFAULT_CTOR = "org.jdom2.internal.ReflectionConstructorTest$NoDefaultCtor";
    private static final String THROWING_CTOR = "org.jdom2.internal.ReflectionConstructorTest$ThrowingCtor";
    private static final String ABSTRACT_IMPL = "org.jdom2.internal.ReflectionConstructorTest$AbstractImpl";
    private static final String PRIVATE_CTOR = "org.jdom2.internal.ReflectionConstructorTest$PrivateCtor";
    private static final String NOT_ASSIGNABLE = "org.jdom2.internal.ReflectionConstructorTest$NotAssignable";
    private static final String DOES_NOT_EXIST = "org.jdom2.internal.DoesNotExistClass";

    @Test
    public void test_construct_success() {
        TestTarget result = ReflectionConstructor.construct(VALID_IMPL, TestTarget.class);
        assertNotNull(result);
        assertTrue(TestTarget.class.isInstance(result));
        assertEquals(ValidImpl.class, result.getClass());
    }

    @Test
    public void test_construct_class_not_found() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> ReflectionConstructor.construct(DOES_NOT_EXIST, TestTarget.class));
        assertTrue(ex.getMessage().contains("Unable to locate class"));
        assertTrue(ex.getMessage().contains(DOES_NOT_EXIST));
        assertTrue(ex.getCause() instanceof ClassNotFoundException);
    }

    @Test
    public void test_construct_not_assignable() {
        ClassCastException ex = assertThrows(ClassCastException.class,
                () -> ReflectionConstructor.construct(NOT_ASSIGNABLE, TestTarget.class));
        assertTrue(ex.getMessage().contains("is not assignable to"));
    }

    @Test
    public void test_construct_no_default_constructor() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> ReflectionConstructor.construct(NO_DEFAULT_CTOR, TestTarget.class));
        assertTrue(ex.getMessage().contains("no-arg constructor"));
        assertTrue(ex.getCause() instanceof NoSuchMethodException);
    }

    @Test
    public void test_construct_constructor_throws() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> ReflectionConstructor.construct(THROWING_CTOR, TestTarget.class));
        assertTrue(ex.getMessage().contains("Unable to call class constructor"));
        assertTrue(ex.getCause() instanceof InvocationTargetException);
        Throwable inner = ex.getCause().getCause();
        assertTrue(inner instanceof RuntimeException);
        assertEquals("boom", inner.getMessage());
    }

    @Test
    public void test_construct_abstract_class() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> ReflectionConstructor.construct(ABSTRACT_IMPL, TestTarget.class));
        assertTrue(ex.getMessage().contains("Unable to instantiate class"));
        assertTrue(ex.getCause() instanceof InstantiationException);
    }

    @Test
    public void test_construct_private_constructor() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> ReflectionConstructor.construct(PRIVATE_CTOR, TestTarget.class));
        assertTrue(ex.getMessage().contains("Unable to access class constructor"));
        assertTrue(ex.getCause() instanceof IllegalAccessException);
    }

    @Test
    public void test_construct_null_classname() {
        assertThrows(NullPointerException.class,
                () -> ReflectionConstructor.construct(null, TestTarget.class));
    }

    @Test
    public void test_construct_null_targetclass() {
        assertThrows(NullPointerException.class,
                () -> ReflectionConstructor.construct(VALID_IMPL, null));
    }

    @Test
    public void test_construct_empty_classname() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> ReflectionConstructor.construct("", TestTarget.class));
        assertTrue(ex.getCause() instanceof ClassNotFoundException);
    }

    @Test
    public void test_construct_interface_target() {
        TestTarget result = ReflectionConstructor.construct(VALID_IMPL, TestTarget.class);
        assertTrue(result instanceof TestTarget);
        assertTrue(TestTarget.class.isInstance(result));
    }
}