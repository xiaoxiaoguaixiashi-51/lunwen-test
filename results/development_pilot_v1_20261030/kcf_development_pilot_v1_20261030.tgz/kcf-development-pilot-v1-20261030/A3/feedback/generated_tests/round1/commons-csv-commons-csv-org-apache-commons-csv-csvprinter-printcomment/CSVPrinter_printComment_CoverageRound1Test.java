package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

public class CSVPrinterPrintCommentTest {

    private static final char COMMENT_MARKER = '#';

    private CSVFormat formatWithComment() {
        return CSVFormat.DEFAULT.builder().setCommentMarker(COMMENT_MARKER).build();
    }

    @Test
    public void testPrintCommentNull() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment(null);
        }
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentNoMarker() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT)) {
            printer.printComment("hello");
        }
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentSimple() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment("hello");
        }
        assertEquals("# hello" + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
    }

    @Test
    public void testPrintCommentEmpty() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment("");
        }
        assertEquals("# " + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
    }

    @Test
    public void testPrintCommentAfterRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printRecord("a", "b");
            printer.printComment("note");
        }
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("a,b" + rs + "# note" + rs, sw.toString());
    }

    @Test
    public void testPrintCommentWithLf() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment("line1\nline2");
        }
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# line2" + rs, sw.toString());
    }

    @Test
    public void testPrintCommentWithCr() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment("line1\rline2");
        }
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# line2" + rs, sw.toString());
    }

    @Test
    public void testPrintCommentWithCrLf() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment("line1\r\nline2");
        }
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# line2" + rs, sw.toString());
    }

    @Test
    public void testPrintCommentWithTrailingCr() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment("line1\r");
        }
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# " + rs, sw.toString());
    }

    @Test
    public void testPrintCommentWithTrailingLf() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment("line1\n");
        }
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# line1" + rs + "# " + rs, sw.toString());
    }

    @Test
    public void testPrintCommentMultipleLines() throws IOException {
        final StringWriter sw = new StringWriter();
        try (CSVPrinter printer = new CSVPrinter(sw, formatWithComment())) {
            printer.printComment("a\nb\r\nc\rd");
        }
        final String rs = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("# a" + rs + "# b" + rs + "# c" + rs + "# d" + rs, sw.toString());
    }

    @Test
    public void testPrintCommentIOException() {
        final Appendable failing = new Appendable() {
            @Override
            public Appendable append(final CharSequence csq) throws IOException {
                throw new IOException("boom");
            }

            @Override
            public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
                throw new IOException("boom");
            }

            @Override
            public Appendable append(final char c) throws IOException {
                throw new IOException("boom");
            }
        };
        assertThrows(IOException.class, () -> {
            try (CSVPrinter printer = new CSVPrinter(failing, formatWithComment())) {
                printer.printComment("hello");
            }
        });
    }
}
