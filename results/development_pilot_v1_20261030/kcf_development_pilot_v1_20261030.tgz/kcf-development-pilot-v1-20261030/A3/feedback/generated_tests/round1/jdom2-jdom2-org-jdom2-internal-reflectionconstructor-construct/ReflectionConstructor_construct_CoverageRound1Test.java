package org.jdom2.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class ReflectionConstructorTest {

    public static class PublicNoArg {
        public PublicNoArg() {
        }
    }

    public static class PublicNoArgSub extends PublicNoArg {
        public PublicNoArgSub() {
        }
    }

    public static class NoDefaultConstructor {
        public NoDefaultConstructor(String s) {
        }
    }

    public static class PrivateConstructor {
        private PrivateConstructor() {
        }
    }

    public static class ThrowingConstructor {
        public ThrowingConstructor() {
            throw new RuntimeException("boom");
        }
    }

    public static abstract class AbstractClass {
        public AbstractClass() {
        }
    }

    @Test
    public void testConstructSuccess() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArg.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArg);
    }

    @Test
    public void testConstructAssignableSubclass() {
        PublicNoArg result = ReflectionConstructor.construct(
                PublicNoArgSub.class.getName(), PublicNoArg.class);
        assertNotNull(result);
        assertTrue(result instanceof PublicNoArgSub);
    }

    @Test
    public void testConstructSameType() {
        PublicNoArgSub result = ReflectionConstructor.construct(
                PublicNoArgSub.class.getName(), PublicNoArgSub.class);
        assertNotNull(result);
        assertSame(PublicNoArgSub.class, result.getClass());
    }

    @Test
    public void testConstructClassNotFound() {
        try {
            ReflectionConstructor.construct(
                    "org.jdom2.internal.DoesNotExistClass", Object.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("Unable to locate class"));
        }
    }

    @Test
    public void testConstructNotAssignable() {
        try {
            ReflectionConstructor.construct(
                    PublicNoArg.class.getName(), String.class);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            assertTrue(e.getMessage().contains("not assignable"));
        }
    }

    @Test
    public void testConstructNoDefaultConstructor() {
        try {
            ReflectionConstructor.construct(
                    NoDefaultConstructor.class.getName(), NoDefaultConstructor.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("no-arg constructor"));
        }
    }

    @Test
    public void testConstructPrivateConstructor() {
        try {
            ReflectionConstructor.construct(
                    PrivateConstructor.class.getName(), PrivateConstructor.class);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("no-arg constructor"));
        }
    }

    @Test
    public void testConstructAbstractClass() {
        try {
            ReflectionConstructor.construct(
                    AbstractClass.class.getName(), AbstractClass.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("Unable to instantiate class"));
        }
    }

    @Test
    public void testConstructThrowingConstructor() {
        try {
            ReflectionConstructor.construct(
                    ThrowingConstructor.class.getName(), ThrowingConstructor.class);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("Unable to call class constructor"));
        }
    }

    @Test
    public void testConstructString() {
        String result = ReflectionConstructor.construct(
                String.class.getName(), String.class);
        assertNotNull(result);
        assertEquals("", result);
    }
}
