| fqcn | id | output | output_dir | project_id | source_dir | status | test_class | xml_file |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| org.apache.commons.csv.CSVPrinter | commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment | JUnit version 4.13.2
.E
Time: 0.004
There was 1 failure:
1) initializationError(org.apache.commons.csv.CSVPrinterPrintCommentTest)
org.junit.runners.model.InvalidTestClassError: Invalid test class 'org.apache.commons.csv.CSVPrinterPrintCommentTest':
  1. The class org.apache.commons.csv.CSVPrinterPrintCommentTest is not public.
  2. Test class should have exactly one public constructor
  3. No runnable methods
	at org.junit.runners.ParentRunner.validate(ParentRunner.java:525)
	at org.junit.runners.ParentRunner.<init>(ParentRunner.java:102)
	at org.junit.runners.BlockJUnit4ClassRunner.<init>(BlockJUnit4ClassRunner.java:84)
	at org.junit.runners.JUnit4.<init>(JUnit4.java:23)
	at org.junit.internal.builders.JUnit4Builder.runnerForClass(JUnit4Builder.java:10)
	at org.junit.runners.model.RunnerBuilder.safeRunnerForClass(RunnerBuilder.java:70)
	at org.junit.internal.builders.AllDefaultPossibilitiesBuilder.runnerForClass(AllDefaultPossibilitiesBuilder.java:37)
	at org.junit.runner.Computer.getRunner(Computer.java:50)
	at org.junit.runner.Computer$1.runnerForClass(Computer.java:31)
	at org.junit.runners.model.RunnerBuilder.safeRunnerForClass(RunnerBuilder.java:70)
	at org.junit.runners.model.RunnerBuilder.runners(RunnerBuilder.java:125)
	at org.junit.runners.model.RunnerBuilder.runners(RunnerBuilder.java:111)
	at org.junit.runners.Suite.<init>(Suite.java:81)
	at org.junit.runner.Computer$2.<init>(Computer.java:33)
	at org.junit.runner.Computer.getSuite(Computer.java:28)
	at org.junit.runner.Request.classes(Request.java:77)
	at org.junit.runner.JUnitCommandLineParseResult.createRequest(JUnitCommandLineParseResult.java:116)
	at org.junit.runner.JUnitCore.runMain(JUnitCore.java:77)
	at org.junit.runner.JUnitCore.main(JUnitCore.java:36)

FAILURES!!!
Tests run: 1,  Failures: 1

 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A3/initial_execution/commons-csv/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment-org.apache.commons.csv.CSVPrinter | commons-csv | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A3/initial/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment | test_failed | org.apache.commons.csv.CSVPrinterPrintCommentTest | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A3/initial_execution/commons-csv/commons-csv-commons-csv-org-apache-commons-csv-csvprinter-printcomment-org.apache.commons.csv.CSVPrinter/xml/jacoco.xml |
| org.jdom2.internal.ReflectionConstructor | jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct | JUnit version 4.13.2
..........E.
Time: 0.034
There was 1 failure:
1) test_construct_private_constructor(org.jdom2.internal.ReflectionConstructorTest)
java.lang.AssertionError: unexpected exception type thrown; expected:<java.lang.IllegalStateException> but was:<java.lang.IllegalArgumentException>
	at org.junit.Assert.assertThrows(Assert.java:1020)
	at org.junit.Assert.assertThrows(Assert.java:981)
	at org.jdom2.internal.ReflectionConstructorTest.test_construct_private_constructor(ReflectionConstructorTest.java:109)
	... 32 trimmed
Caused by: java.lang.IllegalArgumentException: Unable to locate class no-arg constructor 'org.jdom2.internal.ReflectionConstructorTest$PrivateCtor'.
	at org.jdom2.internal.ReflectionConstructor.construct(ReflectionConstructor.java:91)
	at org.jdom2.internal.ReflectionConstructorTest.lambda$test_construct_private_constructor$5(ReflectionConstructorTest.java:110)
	at org.junit.Assert.assertThrows(Assert.java:1001)
	... 35 more
Caused by: java.lang.NoSuchMethodException: org.jdom2.internal.ReflectionConstructorTest$PrivateCtor.<init>()
	at java.lang.Class.getConstructor0(Class.java:3082)
	at java.lang.Class.getConstructor(Class.java:1825)
	at org.jdom2.internal.ReflectionConstructor.construct(ReflectionConstructor.java:85)
	... 37 more

FAILURES!!!
Tests run: 11,  Failures: 1

 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A3/initial_execution/jdom2/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct-org.jdom2.internal.ReflectionConstructor | jdom2 | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A3/initial/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct | test_failed | org.jdom2.internal.ReflectionConstructorTest | /root/autodl-tmp/kcf-development-pilot-v1-20261030/A3/initial_execution/jdom2/jdom2-jdom2-org-jdom2-internal-reflectionconstructor-construct-org.jdom2.internal.ReflectionConstructor/xml/jacoco.xml |
